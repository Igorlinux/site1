function readFile(file, onLoadCallback){
    var reader = new FileReader();
    reader.onload = onLoadCallback;
    reader.readAsDataURL(file);
}

var _EMPRE = [ [], [], [] ];
var _TRAB = [ [], [], [] ];
var _ESTUDE = [ [], [], [] ];

var player = {
	qtdTelas: document.getElementsByClassName('tela').length,
	qtdTelasVistas: 0,
	telasVistas: ['tela1'],
	ultimaTelaVista: 'tela1',
	blocodenotas: '',
	excel: '',
	exercicios: {},
	progresso: function() {
		return Math.round((this.qtdTelasVistas * 100 / this.qtdTelas)) + '%';
	},
	guardarInformacoes: function() {
		var lesson_location = {};
		var comments = {};
		var exercicios_data = {};

		//ID DA TELA
		lesson_location['ultimaTelaVista'] = this.ultimaTelaVista;
		lesson_location['telasVistas'] = this.telasVistas;
		/*comments['blocodenotas'] = this.blocodenotas;
		comments['excel'] = this.excel;*/
		exercicios_data['exercicios'] = this.exercicios;
		alert(JSON.stringify(exercicios_data));
		alert(JSON.stringify(exercicios_data).length);
		doLMSSetValue('cmi.core.lesson_location', JSON.stringify(lesson_location));
		doLMSSetValue('cmi.comments', JSON.stringify(comments));
		doLMSSetValue('cmi.suspend_data', JSON.stringify(exercicios_data));
	},
	recuperarInformacoes: function() {
		if (doLMSGetValue('cmi.core.lesson_location').length > 0) {
			var lesson_location = JSON.parse(doLMSGetValue('cmi.core.lesson_location'));
			this.qtdTelasVistas = lesson_location.telasVistas.length;
			this.telasVistas = lesson_location.telasVistas;
			this.ultimaTelaVista = lesson_location.ultimaTelaVista;

			for (var i = 0; i < this.telasVistas.length; i++) {
				var telaAtual = this.telasVistas[i];
				$('#'+telaAtual).addClass('visto').addClass('podePassar');
				$('#menuLateral a[data-target="'+telaAtual+'"]').removeClass('disabled');
			}

			this.irPara(this.ultimaTelaVista);
		}
		// if (doLMSGetValue('cmi.comments').length == 0) {
		// 	var comments = JSON.parse(doLMSGetValue('cmi.comments'));
		// 	this.blocodenotas = comments.blocodenotas;
		// 	this.excel = comments.excel;
		// }
		if (doLMSGetValue('cmi.suspend_data').length > 0) {
			var total = doLMSGetValue('cmi.suspend_data');
			var exercicios_data = JSON.parse(total);
			var exerciciosObject = exercicios_data.exercicios;
			for (var i = 0; i < Object.keys(exerciciosObject).length; i++) {
				var tela = Object.keys(exerciciosObject)[i];

				if (tela == 'tela6' || tela == 'tela10' || tela == 'tela11' || tela == 'tela13') {

					$('#'+tela).find('textarea').each(function(index, el) {
						if (index == 0 && exerciciosObject[tela][index] != '') {
							$(this).closest('.estrutura').find('.avancarTomenota').removeClass('disabled');
						}
						$(this).val(exerciciosObject[tela][index]);
						$(this).trigger('input');
					});

				}
				else if (tela == 'tela12') {
					for (var i = 0; i < exerciciosObject[tela][0].length; i++) {
						for (var j = 0; j < exerciciosObject[tela][0][i].length; j++) {
							if (i == 0) {
								$('#'+tela).find('.conteudo-escondido.estudo').find('.opcoesCurto').find('.opcao').eq(exerciciosObject[tela][0][i][j]).find('input').trigger('change');
							}
							else if (i == 1) {
								$('#'+tela).find('.conteudo-escondido.estudo').find('.opcoesMedio').find('.opcao').eq(exerciciosObject[tela][0][i][j]).find('input').trigger('click');
								$('#'+tela).find('.conteudo-escondido.estudo').find('.opcoesMedio').find('.opcao').eq(exerciciosObject[tela][0][i][j]).find('input').trigger('change');
							}
							else if (i == 2) {
								// $('#'+tela).find('.conteudo-escondido.estudo').find('.opcoesLongo').find('.opcao').eq(exerciciosObject[tela][0][i][j]).find('input').prop('checked', true);
								$('#'+tela).find('.conteudo-escondido.estudo').find('.opcoesLongo').find('.opcao').eq(exerciciosObject[tela][0][i][j]).find('input').trigger('click').trigger('change');
							}
						}
					}

					for (var i = 0; i < exerciciosObject[tela][1].length; i++) {
						for (var j = 0; j < exerciciosObject[tela][1][i].length; j++) {
							if (i == 0) {
								$('#'+tela).find('.conteudo-escondido.trabalho').find('.opcoesCurto').find('.opcao').eq(exerciciosObject[tela][1][i][j]).find('input').trigger('click');
							}
							else if (i == 1) {
								$('#'+tela).find('.conteudo-escondido.trabalho').find('.opcoesMedio').find('.opcao').eq(exerciciosObject[tela][1][i][j]).find('input').trigger('click');
							}
							else if (i == 2) {
								$('#'+tela).find('.conteudo-escondido.trabalho').find('.opcoesLongo').find('.opcao').eq(exerciciosObject[tela][1][i][j]).find('input').trigger('click');
							}
						}
					}

					for (var i = 0; i < exerciciosObject[tela][2].length; i++) {
						for (var j = 0; j < exerciciosObject[tela][2][i].length; j++) {
							if (i == 0) {
								$('#'+tela).find('.conteudo-escondido.empreendedorismo').find('.opcoesCurto').find('.opcao').eq(exerciciosObject[tela][2][i][j]).find('input').trigger('click');
							}
							else if (i == 1) {
								$('#'+tela).find('.conteudo-escondido.empreendedorismo').find('.opcoesMedio').find('.opcao').eq(exerciciosObject[tela][2][i][j]).find('input').trigger('click');
							}
							else if (i == 2) {
								$('#'+tela).find('.conteudo-escondido.empreendedorismo').find('.opcoesLongo').find('.opcao').eq(exerciciosObject[tela][2][i][j]).find('input').trigger('click');
							}
						}
					}
				}
			}

		}

		// $('#blocodenotas').html(this.blocodenotas);
		// $('#excel').html(this.excel);

	},
	sair: function() {
		console.log('saindo');
		console.log(this.qtdTelasVistas);
		console.log(this.qtdTelas);
		this.guardarInformacoes();
		if (this.qtdTelasVistas == this.qtdTelas) {
			console.log('completei');
			doQuit('complete');
		}
		else {
			console.log('não completei');
			doQuit('incomplete');
		}
	},
	atualizarProgresso: function() {
		if (!$('.tela.slick-active').hasClass('visto')) {
			$('.tela.slick-active').addClass('visto');
			$('#menuLateral a[data-target="'+$('.tela.slick-active').attr('id')+'"]').addClass('visto');
			this.telasVistas.push($('.tela.slick-active').attr('id'));
			this.ultimaTelaVista = $('.tela.slick-active').attr('id');
			this.qtdTelasVistas++;

			$('#barraProgressoCompleta').width(this.progresso());
			$('#barraContagem').text(this.progresso());
		}
	},
	permissaoAvancar: function() {
		if ($('#slick').slick('slickCurrentSlide') != this.qtdTelas - 1 && !$('.tela.slick-active').hasClass('subtelas') && !$('.tela.slick-active').hasClass('subtela') && $('.tela.slick-active').hasClass('podePassar')) {
			return true;
		}
		else if ($('.tela.slick-active').hasClass('subtelas')) {
			var contador = 0;
			$('.tela.slick-active').closest('.modulo').find('div[id*="'+$('.tela.slick-active').attr('id')+'"]').each(function() {
				if (!$(this).hasClass('subtela')) {
					contador++;
				}
			});
			if ($('.tela.slick-active').closest('.modulo').find('div[id*="'+$('.tela.slick-active').attr('id')+'"]').length == contador) {

				var telaNumber = $('.tela.slick-active').attr('id').replace('tela', '');
				var number = (parseInt(telaNumber)) + 1;
				$('.tela.slick-active').removeClass('subtelas');
				$('#menuLateral').find('a[data-target="tela' + number + '"]').removeClass('disabled');
				this.irPara('tela'+number);
			}
			else {

				var subtelaId = $('.tela.slick-active').attr('data-target');
				if (subtelaId) {
					$('.tela.slick-active').find('.selected').addClass('visto');
					this.irPara(subtelaId);
				}

			}
		}
		else if ($('.tela.slick-active').hasClass('subtela')) {
			var subtelaId = $('.tela.slick-active').attr('data-target');
			if (subtelaId && $('.tela.slick-active').hasClass('podePassar')) {
				$('.tela.slick-active').removeClass('subtela');
				this.qtdTelasVistas++;
				this.irPara(subtelaId);
			}
		}
		else {
			player.darFeedback($('.tela.slick-active').attr('id'), false);
		}
	},
	permissaoVoltar: function() {
		if ($('#slick').slick('slickCurrentSlide') != 0 && !$('.tela.slick-active').hasClass('subtela')) {
			return true;
		}
		else if ($('.tela.slick-active').hasClass('subtela')) {
			var subtelaId = $('.tela.slick-active').attr('data-target');
				this.irPara(subtelaId);
		}
		else {
			player.darFeedback($('.tela.slick-active').attr('id'), false);
		}
	},
	permissaoIrPara: function(alvo) {
		if ($('#'+alvo)) {
			return true;
		}
		else {
			player.darFeedback($('.tela.slick-active').attr('id'), false);
		}
	},
	atualizarMenu: function() {

		var id = $('#slick').find('.tela.slick-active').attr('id');

			$('#menuLateral').find('a').removeClass('ativo');
			$('#menuLateral').find('a[data-target="' + id + '"]').addClass('ativo');

			$('#menuLateral').find('a[data-target="' + id + '"]').removeClass('disabled');
			$('#menuLateral').find('a[data-target="' + id + '"]').bind('click', function() {
			});

	},
	avancar: function() {
		if (this.permissaoAvancar()) {
			this.fecharTooltip();
			$('#slick').slick('slickNext');
			this.atualizarProgresso();
			this.atualizarMenu();

			if ($('.tela.slick-active').attr('data-slick-index') == player.qtdTelas - 1) {
				$('#navAvancar').addClass('exit');
				$('#navAvancar').html('Sair');
			}
			else if ($('.tela.slick-active').attr('data-slick-index') == 1) {
				$('#navVoltar').removeClass('disabled');
			}

			if (!$('.tela.slick-active').hasClass('podePassar')) {
				$('#navAvancar').addClass('disabled');
			}
		}
	},
	forcarAvancar: function() {
		this.fecharTooltip();
		this.fecharModal();
		$('#slick').slick('slickNext');
		this.atualizarProgresso();
		this.atualizarMenu();

		if ($('.tela.slick-active').attr('data-slick-index') == player.qtdTelas - 1) {
			$('#navAvancar').addClass('exit');
			$('#navAvancar').html('Sair');
		}
		else if ($('.tela.slick-active').attr('data-slick-index') == 1) {
			$('#navVoltar').removeClass('disabled');
		}

		if (!$('.tela.slick-active').hasClass('podePassar')) {
			$('#navAvancar').addClass('disabled');
		}

	},
	voltar: function() {
		if (this.permissaoVoltar()) {
			this.fecharTooltip();
			$('#slick').slick('slickPrev');
			this.atualizarProgresso();
			this.atualizarMenu();

			if ($('.tela.slick-active').attr('data-slick-index') == player.qtdTelas - 1) {
				$('#navAvancar').removeClass('exit');
				$('#navAvancar').html('Avançar<span class="seta seta-direita"><span class="barra1"></span><span class="barra2"></span></span>');
			}

			$('#navAvancar').removeClass('disabled');

			if ($('.tela.slick-active').attr('data-slick-index') == 0) {
				$('#navVoltar').addClass('disabled');
			}
		}
	},
	irPara: function(alvo) {
		if (this.permissaoIrPara(alvo)) {
			$('#blocodenotas').hide('slide');
			$('#menuLateral').hide('slide');

			this.fecharTooltip();
			$('#slick').slick('slickGoTo', $('#'+alvo).attr('data-slick-index'));
			this.atualizarProgresso();
			this.atualizarMenu();

			if ($('.tela.slick-active').attr('id').replace(/\D/g, '') == player.qtdTelas) {
				$('#navAvancar').addClass('exit');
				$('#navAvancar').html('Sair');

			}
			else {
				$('#navAvancar').removeClass('exit');
				$('#navAvancar').html('Avançar<span class="seta seta-direita"><span class="barra1"></span><span class="barra2"></span></span>');
			}

			if ($('.tela.slick-active').attr('id').replace(/\D/g, '') == 1) {
				$('#navVoltar').addClass('disabled');

			}
			else {
				$('#navVoltar').removeClass('disabled');
			}

			if ($('#'+ $('.tela.slick-active').attr('id')).hasClass('podePassar')) {
				console.log('haha1')
				$('#navAvancar').removeClass('disabled');
			}
			else {
				console.log('haha2')
				$('#navAvancar').addClass('disabled');
			}
		}
	},
	toggleMenu: function() {
		$('#menuLateral').toggle('slide');
	},
	fecharMenu: function() {
		$('#menuLateral').hide('slide');
	},
	toggleBlocodenotas: function() {

		if ($('#blocodenotas').hasClass('ativo')) {
			$('#fecharBlocodenotas').css('display', 'none');
		}

		$('#blocodenotas').toggle('slide', function() {
			if ($(this).css('display') == 'block') {
				$('#fecharBlocodenotas').css('display', 'flex');

				var left = $('#blocodenotas').offset().left;
				var top = $('#blocodenotas').offset().top;
				var width = $('#blocodenotas').outerWidth();

				var w = window,
			    d = document,
			    e = d.documentElement,
			    g = d.getElementsByTagName('body')[0],
			    windowWidth = w.innerWidth || e.clientWidth || g.clientWidth,
			    windowHeight = w.innerHeight|| e.clientHeight|| g.clientHeight;

				var newRight = windowWidth - width - left - 23;
				var newTop = top /2 ;

				$('#fecharBlocodenotas').css('right', newRight);
				$('#fecharBlocodenotas').css('top', newTop);

				$(this).addClass('ativo');
			}
		});

		this.fecharMenu();
	},
	toggleExcel: function() {

		if ($('#excel').hasClass('ativo')) {
			$('#fecharExcel').css('display', 'none');
		}

		$('#excel').toggle('slide', function() {
			if ($(this).css('display') == 'block') {
				$('#fecharExcel').css('display', 'flex');

				var left = $('#excel').offset().left;
				var top = $('#excel').offset().top;
				var width = $('#excel').outerWidth();

				var w = window,
			    d = document,
			    e = d.documentElement,
			    g = d.getElementsByTagName('body')[0],
			    windowWidth = w.innerWidth || e.clientWidth || g.clientWidth,
			    windowHeight = w.innerHeight|| e.clientHeight|| g.clientHeight;

				var newRight = windowWidth - width - left - 23;
				var newTop = top /2 ;

				$('#fecharExcel').css('right', newRight);
				$('#fecharExcel').css('top', newTop);


				$(this).addClass('ativo');
			}
		});
		this.fecharMenu();
	},
	darFeedback: function(tela, assunto) {
		var mensagem = '';

		// if (assunto == 'navegar') {
		// 	mensagem = 'Você precisa acessar todo o conteúdo antes de navegar';
		// }
		// else {
		// 	mensagem = assunto;
		// }

		if (!assunto) {

			if (tela == 'tela2') {
				mensagem = 'Você deve inserir a imagem antes de continuar.';
			}
			else if (tela == 'tela3') {
				mensagem = 'Você deve clicar ou tocar no icone antes de continuar.';
			}
			else if (tela == 'tela5' || tela == 'tela8') {
				mensagem = 'Você deve clicar ou tocar em todas as fotos antes de continuar.';
			}
			else if (tela == 'tela6') {
				mensagem = 'Você deve fazer a anotação antes de continuar.';
			}
			else if (tela == 'tela9') {
				mensagem = 'Você deve clicar ou tocar em todos os tópicos antes de continuar.'
			}
			else if (tela == 'tela10' || tela == 'tela11') {
				mensagem = 'Você deve fazer todas as anotações antes de continuar.'
			}
			else if (tela == 'tela12') {
				mensagem = 'Você deve passar pelas três rotas antes de continuar. É importante lembrar que você precisa marcar pelo menos uma ação em cada prazo.'
			}
			else if (tela == 'tela13') {
				mensagem = 'Você deve clicar ou tocar nos ícones e fazer todas as anotações antes de continuar.'
			}

		}

		$('#feedback').find('p').html(mensagem);

		$('#overlay').css({
			'transform': 'scale(1)',
		});

		$('#feedback').css('display', 'flex');

	},
	inserirConteudoBlocodenotas: function(id, titulo, subtitulo, conteudo) {
		if ($('#blocodenotas').find('.'+id).length == 0) {
			$('#blocodenotas').append('<div class=' + id +'><h4>' + titulo + '</h4>' + (subtitulo ? '<h5>' + subtitulo +'</h5>' : '') + conteudo + '</div>');
		}
		else if ($('#blocodenotas').find('.'+id).find('.' + $(conteudo).attr('alt') + '').length == 0) {
			if ($('#blocodenotas').find('.'+id).find('.imageAdded').length == 0) {
				$('#blocodenotas').find('.'+id).append((subtitulo ? '<h5>' + subtitulo +'</h5>' : '') + conteudo + '</div>');
			}
			else {
				$('#blocodenotas').find('.'+id).find('.conteudo').replaceWith(conteudo);
			}
		}
		else if ($('#blocodenotas').find('.'+id).find('.' + $(conteudo).attr('alt') + '').length != 0) {
			$('#blocodenotas').find('.'+id).find('.'+$(conteudo).attr('alt')).replaceWith(conteudo);
		}
		else {
			$('#blocodenotas').find('.'+id).find('.conteudo').replaceWith(conteudo);
		}
		this.blocodenotas = $('#blocodenotas').html();
	},
	inserirConteudoExcel: function(empreendedorismo, trabalhe, estude) {
		var empreCurto = empreendedorismo[0];
		var empreMedio = empreendedorismo[1];
		var empreLongo = empreendedorismo[2];

		var trabCurto = trabalhe[0];
		var trabMedio = trabalhe[1];
		var trabLongo = trabalhe[2];

		var estudeCurto = estude[0];
		var estudeMedio = estude[1];
		var estudeLongo = estude[2];

		var resultado = '<table><tr><td rowspan=3>Empreendedorismo</td><td>Longo</td><td><li>' + (empreLongo ? empreLongo.join("</li><li>") : '') + '</li></td></tr><tr><td>Médio</td><td><li>' + (empreMedio ? empreMedio.join("</li><li>") : '') + '</li></td></tr><tr><td>Curto</td><td><li>' + (empreCurto ? empreCurto.join("</li><li>") : '') + '</li></td></tr><tr><td rowspan=3>Trabalhe</td><td>Longo</td><td><li>' + (trabLongo ? trabLongo.join("</li><li>") : '') + '</li></td></tr><tr><td>Médio</td><td><li>' + (trabMedio ? trabMedio.join("</li><li>") : '') + '</li></td></tr><tr><td>Curto</td><td><li>' + (trabCurto ? trabCurto.join("</li><li>") : '') + '</li></td></tr><tr><td rowspan=3>Estude</td><td>Longo</td><td><li>' + (estudeLongo ? estudeLongo.join("</li><li>") : '') + '</li></td></tr><tr><td>Médio</td><td><li>' + (estudeMedio ? estudeMedio.join("</li><li>") : '') + '</li></td></tr><tr><td>Curto</td><td><li>' + (estudeCurto ? estudeCurto.join("</li><li>") : '') + '</li></td></tr></table>';

		$('#excel').find('table').remove();
		$('#excel').append(resultado);

		this.excel = $('#excel').html();
	},
	abrirModal: function(tela, modal) {
		$('.modal').css('display', 'none');
		$('.subModal').css('display', 'none');
		$('.subModal').removeClass('ativo');
		$('#overlay').css({
			'transform': 'scale(1)',
		});

		$('.'+modal+'[alt="'+tela+'"]').css('display', 'flex');
	},
	fecharModal: function() {
		$('#overlay').css({
			'transform': 'scale(0)',
		});
		$('.modal').css('display', 'none');
		$('.subModal').css('display', 'none');
	},
	abrirTooltip: function(tela, elemento, tooltip) {
		$('.tooltip').css('display', 'none');
		$('#tooltip').css({
			'transform': 'scale(1)',
		});

		var element = elemento;

		var elementWidth = element[0].naturalWidth;
		var elementTrueWidth = element[0].width;
		var elementTrueHeight = element[0].height;
		var elementx = element.offset().left;
		var elementy = element.offset().top;

		var tooltipWidth = $('.'+tooltip+'[alt="'+tela+'"]').outerWidth();
		var tooltipHeight = $('.'+tooltip+'[alt="'+tela+'"]').outerHeight();

		var w = window,
	    d = document,
	    e = d.documentElement,
	    g = d.getElementsByTagName('body')[0],
	    windowWidth = w.innerWidth || e.clientWidth || g.clientWidth,
	    windowHeight = w.innerHeight|| e.clientHeight|| g.clientHeight;

	    var left = 0;
	    var top = 0;

	    if (elementx >= tooltipWidth) {
	    	left = elementx - tooltipWidth + 13;
	    }
	    else {
	    	left = elementx;
	    }

	    if (elementy >= tooltipHeight) {
	    	top = elementy - tooltipHeight + 13;
	    }
	    else {
	    	top = elementy;
	    }

		$('.'+tooltip+'[alt="'+tela+'"]').css({left: left, top: top});
		$('.'+tooltip+'[alt="'+tela+'"]').addClass('aberto');
		$('.'+tooltip+'[alt="'+tela+'"]').show('fade', 200);

	},
	fecharTooltip: function(tooltip) {
		if (!tooltip) {
			$(tooltip).hide('fade', 200, function() {
				if ($('#tooltip').find('.aberto').length == 0) {
					$('#tooltip').css({
						'transform': 'scale(0)',
					});
				}
			});
		}
		else {
			$(tooltip).removeClass('aberto');
			$(tooltip).hide('fade', 200, function() {
				if ($('#tooltip').find('.aberto').length == 0) {
					$('#tooltip').css({
						'transform': 'scale(0)',
					});
				}
			});
		}
	}
}

$('#slick').slick({
	arrows: false,
	dots: false,
	infinite: false,
	draggable: false,
	touchMove: false,
	swipe: false,
	accessibility: false,
	speed: 800,
	slide: '.tela'
});

$('.slick').slick({
	arrows: false,
	dots: false,
	infinite: false,
	draggable: false,
	touchMove: false,
	swipe: false,
	accessibility: false,
	speed: 600
});

// EVENTOS DE CLICK

$('.arrow-left').on('click', function() {
	$(this).closest('.setas').prev('.slick').slick('slickPrev');
});

$('.arrow-right').on('click', function() {
	$(this).closest('.setas').prev('.slick').slick('slickNext');
});

$('.voltarTomenota:not(.disabled)').on('click', function() {
	if ($(this).closest('.tela').find('.tomeNota.ativo').prev('.tomeNota').length > 0) {
		$(this).closest('.tela').find('.tomeNota.ativo').find('.mao-direita').removeClass('slideRightIn2');
		$(this).closest('.tela').find('.tomeNota.ativo').find('.mao-direita').removeClass('slideRightIn');
		$(this).closest('.tela').find('.tomeNota.ativo').removeClass('ativo').prev('.tomeNota').addClass('ativo').find('.mao-direita').addClass('slideRightIn');
	}

	if ($(this).closest('.tela').find('.tomeNota.ativo').prev('.tomeNota').length == 0) {
		$(this).hide('fade');
	}

	if ($(this).closest('.tela').find('.tomeNota.ativo').next('.tomeNota').length > 0) {
		$(this).closest('.tela').find('.avancarTomenota').css('display', 'flex');
	}
	if ($(this).closest('.tela').find('.tomeNota.ativo').find('.anotacao').val().length > 0) {
		$(this).closest('.tela').find('.avancarTomenota').removeClass('disabled');
	}
	else {
		$(this).closest('.tela').find('.avancarTomenota').addClass('disabled');
	}

});
$(document).on('click', '.avancarTomenota:not(.disabled)', function() {
	if ($(this).closest('.tela').find('.tomeNota.ativo').next('.tomeNota').length > 0) {
		$(this).closest('.tela').find('.tomeNota.ativo').find('.mao-direita').removeClass('slideRightIn2');
		$(this).closest('.tela').find('.tomeNota.ativo').find('.mao-direita').removeClass('slideRightIn');
		$(this).closest('.tela').find('.tomeNota.ativo').removeClass('ativo').next('.tomeNota').addClass('ativo').find('.mao-direita').addClass('slideRightIn');
	}

	if ($(this).closest('.tela').find('.tomeNota.ativo').next('.tomeNota').length == 0) {
		$(this).hide('fade');
	}

	if ($(this).closest('.tela').find('.tomeNota.ativo').prev('.tomeNota').length > 0) {
		$(this).closest('.tela').find('.voltarTomenota').css('display', 'flex');
	}

	if ($(this).closest('.tela').find('.tomeNota.ativo').find('.anotacao').val().length > 0) {

	}
	else {
		$(this).addClass('disabled');
	}


})

$('#tela17 .arrow-left2').on('click', function() {
	$(this).closest('.estrutura').find('.slick').slick('slickPrev');
});

$('#tela17 .arrow-right2').on('click', function() {
	$(this).closest('.estrutura').find('.slick').slick('slickNext');
});

//CLIQUE NO BOTAO DE VOLTAR NO MENU INFERIOR
$('#navVoltar').on('click', function() {

	player.voltar();
});

//CLIQUE NO BOTAO DE AVANÇAR NO MENU INFERIOR
$('#navAvancar').on('click', function() {

	if ($(this).hasClass('exit')) {
		// FAZER FUNÇÂO DE SAIR
	}
	else {

		if ($('.tela.slick-active').attr('id') == 'tela5') {
			var telaId = $('.tela.slick-active').attr('id');
			var totalTooltips = $('#'+telaId).find('*[data-target*="tooltip"]').length;
			var tooltipVistos = $('#'+telaId).find('.visto[data-target*="tooltip"]').length;

			if (totalTooltips == tooltipVistos) {
				player.abrirModal('tela5', 'modal1');
			}
			else {
				player.darFeedback($('.tela.slick-active').attr('id'), false);
			}
		}
		else if ($('.tela.slick-active').attr('id') == 'tela12') {
			var telaId = $('.tela.slick-active').attr('id');
			var totalTooltips = $('#'+telaId).find('*[data-target*="tooltip"]').length;
			var tooltipVistos = $('#'+telaId).find('.visto[data-target*="tooltip"]').length;

			if ($('.tela.slick-active').hasClass('podePassar')) {
				player.abrirModal('tela12', 'modal1');


				$('#tela12 .estudo .opcoesCurto').find('.opcao:not(.marcado)').each(function() {
					if ($(this).find('input:checked').next('label').html()) {
							_ESTUDE[0].push($(this).find('input:checked').next('label').text());
					}
				});

				$('#tela12 .estudo .opcoesMedio').find('.opcao:not(.marcado)').each(function() {
					if ($(this).find('input:checked').next('label').html()) {
							_ESTUDE[1].push($(this).find('input:checked').next('label').text());
					}
				});

				$('#tela12 .estudo .opcoesLongo').find('.opcao:not(.marcado)').each(function() {
					if ($(this).find('input:checked').next('label').html()) {
							_ESTUDE[2].push($(this).find('input:checked').next('label').text());
					}
				});

				$('#tela12 .trabalho .opcoesCurto').find('.opcao:not(.marcado)').each(function() {
					if ($(this).find('input:checked').next('label').html()) {
							_TRAB[0].push($(this).find('input:checked').next('label').text());
					}
				});

				$('#tela12 .trabalho .opcoesMedio').find('.opcao:not(.marcado)').each(function() {
					if ($(this).find('input:checked').next('label').html()) {
							_TRAB[1].push($(this).find('input:checked').next('label').text());
					}
				});

				$('#tela12 .trabalho .opcoesLongo').find('.opcao:not(.marcado)').each(function() {
					if ($(this).find('input:checked').next('label').html()) {
							_TRAB[2].push($(this).find('input:checked').next('label').text());
					}
				});

				$('#tela12 .empreendedorismo .opcoesCurto').find('.opcao:not(.marcado)').each(function() {
					if ($(this).find('input:checked').next('label').html()) {
							_EMPRE[0].push($(this).find('input:checked').next('label').text());
					}
				});

				$('#tela12 .empreendedorismo .opcoesMedio').find('.opcao:not(.marcado)').each(function() {
					if ($(this).find('input:checked').next('label').html()) {
							_EMPRE[1].push($(this).find('input:checked').next('label').text());
					}
				});

				$('#tela12 .empreendedorismo .opcoesLongo').find('.opcao:not(.marcado)').each(function() {
					if ($(this).find('input:checked').next('label').html()) {
							_EMPRE[2].push($(this).find('input:checked').next('label').text());
					}
				});
			player.inserirConteudoExcel(_EMPRE, _TRAB, _ESTUDE);

			}
			else {
				player.darFeedback($('.tela.slick-active').attr('id'), false);
			}
		}
		else {
			player.avancar();
		}

	}
});

//CLIQUE NOS ITENS DO MENU LATERAL
$('#menuLateral a').on('click', function() {
	var alvo = $(this).attr('data-target');
	if (!$(this).hasClass('disabled') && alvo != 'blocodenotas' && alvo != 'excel' && alvo != 'sair') {
		player.irPara(alvo);
	}
});

//CLIQUE NO MENU HAMBURGUER
$('#menuHamburguer').on('click', function() {
	player.toggleMenu();
});

//CLIQUE NO X PARA FECHAR O MENU RETRATIL
$('#fecharMenu').on('click', function() {
	player.toggleMenu();
});

//CLIQUE NO BLOCO DE NOTAS
$('*[data-target="blocodenotas"]').on('click', function() {
	player.toggleBlocodenotas();
});

$('*[data-target="forcarAvancar"]').on('click', function() {
	player.forcarAvancar();

	if (!$('.tela.slick-active').hasClass('podePassar')) {
		$('#navAvancar').addClass('disabled');
	}
});

$('*[data-target="excel"]').on('click', function() {
	player.toggleExcel();
});

$('*[data-target="sair"]').on('click', function() {
	player.sair();
});

$('#fecharBlocodenotas').on('click', function() {
	player.toggleBlocodenotas();
});

$('#fecharExcel').on('click', function() {
	player.toggleExcel();
});

$('input[type="file"]').on('change', function(evt) {
	var _this = this;
	var imageFile = evt.target.files[0];
	var imageCompressor = new ImageCompressor();
	imageCompressor.compress(imageFile, {quality: 0.4}).then((result) => {
		readFile(result, function(evt) {
			var dataURI = evt.target.result;
			var newImage = document.createElement('img');

			if ($(_this).closest('div').find('.imageAdded').length == 0) {

				newImage.setAttribute('src', dataURI);
				newImage.setAttribute('class', 'imageAdded');

				$(_this).prev('label').find('img').css('width', '50px');
				$(_this).prev('label').css({
					'right': '10px',
					'bottom': '10px'
				});

				$(_this).closest('div').append(newImage);
			}
			else {
				$(_this).closest('div').find('.imageAdded').attr('src', dataURI);
			}

			$(_this).closest('.tela').addClass('podePassar');
			$('#navAvancar').removeClass('disabled');

			// ATUALIZAR BLOCO DE NOTAS
			var tituloTela = $(_this).closest('.tela').find('h3').html();
			var idTela = $(_this).closest('.tela').attr('id');
			var conteudo = '<div class="conteudo">' + $(_this).closest('div').find('label')[0].outerHTML + $(_this).closest('div').find('input')[0].outerHTML + $(_this).closest('div').find('.imageAdded')[0].outerHTML + '</div>';
			player.inserirConteudoBlocodenotas(idTela, tituloTela, false, conteudo);
			// player.exercicios[idTela] = newImage;
		});
	});
});

$('*[data-target*="subModal"]').on('click', function() {
	var submodalAlvo = $(this).attr('data-target');
	var tela = $(this).closest('.modal').attr('alt');
	var modalAtualNumero = $(this).closest('.modal').attr('class').replace(/\D/g, '');

	var subModal = $('.subModais').find('.' + submodalAlvo + '[alt="' + tela + ' modal' + modalAtualNumero +'"]');

	$(this).closest('.modal').css('display', 'none');
	subModal.find('.like').addClass('animated bounceIn');
	subModal.show('slide');
});

$('*[data-target*="modal"]').on('click', function() {
	var modalAlvo = $(this).attr('data-target');
	var tela = $(this).closest('.tela').attr('id');

	player.abrirModal(tela, modalAlvo);
});

$('*[data-target*="tooltip"]').on('click', function() {
	var tooltipAlvo = $(this).attr('data-target');
	$(this).closest('.tela').find('*[data-target*="tooltip"]').removeClass('ativo');
	$(this).closest('ul').addClass('ativo');
	$(this).addClass('ativo');

	if ($(this).closest('.tela').length != 0) {
		var tela = $(this).closest('.tela').attr('id');
	}
	else {
		var tela = $(this).closest('.tooltip').attr('alt');
	}

	$(this).addClass('visto');

	if ($(this).closest('.tela').find('*[data-target]').length == $(this).closest('.tela').find('.visto').length) {
		$(this).closest('.tela').addClass('podePassar');
		$('#navAvancar').removeClass('disabled');
	}

	player.abrirTooltip(tela, $(this), tooltipAlvo);
});

$('*[data-target*="blocoDown"]').on('click', function() {
	var blocoAlvo = $(this).attr('data-target');
	$(this).closest('.tela').css('overflow', 'hidden');

	if ($(this).hasClass('ativo')) {
		$(this).removeClass('ativo');
	}
	else {
		$(this).addClass('ativo')
	}
	// $(this).closest('ul').addClass('ativo');

	var tela = $(this).closest('.tela').attr('id');
	$(this).closest('.tela').find('.'+blocoAlvo).toggle('slide', { direction: 'down', mode: 'show' }, 500, function() {
		$(this).closest('.tela').css('overflow', 'auto');
	});
});

$('*[data-target*="blocoShow"]').on('click', function() {
	var blocoAlvo = $(this).attr('data-target');
	var tela = $(this).closest('.tela').attr('id');

	$(this).closest('.tela').find('*[data-target*="blocoShow"]').removeClass('selected');
	$(this).addClass('selected');

	// $(this).closest('.tela').find('.blocoShow').removeClass('ativo');
	// $(this).closest('.tela').find('.'+blocoAlvo).addClass('ativo');
	// $(this).closest('.tela').find('.blocoShow:not(.ativo)').hide();
	$(this).closest('.tela').find('.'+blocoAlvo).toggle('fade');
});

$('*[data-target*="blocoUp"]').on('click', function() {
	var blocoAlvo = $(this).attr('data-target');
	var tela = $(this).closest('.tela').attr('id');
	$(this).closest('.tela').css('overflow', 'hidden');

	$(this).closest('.tela').find('*[data-target*="blocoUp"]').removeClass('selected');
	$(this).addClass('selected');

	$(this).closest('.tela').find('.blocoUp').removeClass('ativo');
	$(this).closest('.tela').find('.'+blocoAlvo).addClass('ativo');
	$(this).closest('.tela').find('.blocoUp:not(.ativo)').hide();
	$(this).closest('.tela').find('.'+blocoAlvo).toggle('slide', { direction: 'down', mode: 'show' }, 500, function() {
		$(this).closest('.tela').css('overflow', 'auto');
	});
});

$('*[data-target*="tomeNota"]').on('click', function() {
	var alvo = $(this).attr('data-target');
	$(this).closest('.estrutura').find('li').removeClass('ativo');
	$(this).closest('li').addClass('ativo');
	$(this).closest('.tela').find('.imagemFundo').hide('fade', function() {
		$(this).closest('.estrutura').css('padding-bottom', '50px');
	});

	$(this).closest('.tela').find('.tomeNota').css({
		'display': 'flex',
		'transform': 'translateY(130%)'
	});

	$(this).closest('.tela').find('.tomeNota').find('.mao-direita').removeClass('slideRightIn');

	$(this).closest('.tela').find('.'+alvo).css({
		'display': 'flex',
		'transform': 'translateY(0%)'
	});
	$(this).closest('.tela').find('.'+alvo).find('.mao-direita').addClass('slideRightIn');
});

$('#tela12 .btnPrincipal[data-target]').on('click', function() {
	var dataTarget = $(this).attr('data-target');
	$(this).closest('.tela').find('.conteudo').hide();
	$(this).removeClass('disabled');
	$(this).addClass('ativo');
	$(this).closest('.tela').find('.btnPrincipal:not([data-target="'+dataTarget+'"])').removeClass('ativo');
	$(this).closest('.tela').find('.btnPrincipal:not([data-target="'+dataTarget+'"])').addClass('disabled');
	$(this).closest('.tela').find('.conteudo-escondido:not(.'+dataTarget+')').hide();
	$(this).closest('.tela').find('.'+dataTarget+'').show('fade');
});

$('#tela12 .btnSecundario[data-target]').on('click', function() {
	var categoria = $(this).closest('.conteudo-escondido').attr('class').replace('conteudo-escondido ', '');
	var alvo = $(this).attr('data-target');

	$(this).closest('.tela').find('.btnSecundario').removeClass('ativo');
	$(this).addClass('ativo');

	$(this).closest('.tela').find('.'+categoria).find('.opcoes').hide();
	$(this).closest('.tela').find('.'+categoria).find('.'+alvo).show();
});


$('.removerSequencia').on('change', function() {
	var numeroOpcao = $(this).closest('.opcao').attr('class').replace('opcao ', '');
	var prazo = $(this).closest('.tela').find('.btnSecundario.ativo').attr('data-target');
	var prazo2 = $(this).closest('.tela').find('.btnSecundario.ativo').attr('data-target').replace('opcoes', '').toLowerCase();

	if ($(this).is(':checked')) {
		$(this).closest('.conteudo-escondido').find('.opcoes:not(.'+prazo+') .'+numeroOpcao).addClass('marcado').addClass('marcado-'+prazo2);
	}
	else {
		$(this).closest('.conteudo-escondido').find('.opcoes:not(.'+prazo+') .'+numeroOpcao).removeClass('marcado').removeClass('marcado-'+prazo2);
	}

	if ($(this).closest('.opcoes').find('input:checked').length > 0) {
		$(this).closest('.tela').find('.btnSecundario.ativo').addClass('visto');

		var srcAtual = $(this).closest('.tela').find('.btnSecundario.ativo').attr('src').replace('.png', '');
		if (srcAtual.indexOf('-aberto') == -1) {
			$(this).closest('.tela').find('.btnSecundario.ativo').attr('src', srcAtual + '-aberto.png');
		}
	}
	else {
		$(this).closest('.tela').find('.btnSecundario.ativo').removeClass('visto');

		var srcAtual = $(this).closest('.tela').find('.btnSecundario.ativo').attr('src').replace('.png', '');
		if (srcAtual.indexOf('-aberto') != -1) {
			var newSrc = srcAtual.replace('-aberto', '');
			$(this).closest('.tela').find('.btnSecundario.ativo').attr('src', newSrc + '.png');
		}
	}

	// VALIDAÇÃO NIVEL TOPICO
	var qtdPorLevel = $(this).closest('.conteudo-escondido').find('.opcoes').length;
	var classLevel = $(this).closest('.conteudo-escondido').attr('class').replace('conteudo-escondido ', '');
	var contadorPorLevel = 0;

	$(this).closest('.conteudo-escondido').find('.opcoes').each(function(index, el) {
		if ($(this).find('input:checked').length > 0) {
			contadorPorLevel++;
		}
	});

	if (qtdPorLevel == contadorPorLevel) {
		var srcAtual = $(this).closest('.tela').find('*[data-target="' + classLevel + '"]').attr('src').replace('.png', '');
		if (srcAtual.indexOf('-aberto') == -1) {
			$(this).closest('.tela').find('*[data-target="' + classLevel + '"]').attr('src', srcAtual + '-aberto.png');
		}
	}


	// VALIDAÇÃO NIVEL TELA
	var qtd = $(this).closest('.tela').find('.opcoes').length
	var contador = 0;
	$(this).closest('.tela').find('.opcoes').each(function() {
		if ($(this).find('input:checked').length > 0) {
			contador++;
		}
	});

	if (qtd == contador) {
		$(this).closest('.tela').addClass('podePassar');
		$('#navAvancar').removeClass('disabled');
	}

	var tela = $(this).closest('.tela').attr('id');

	if (!player.exercicios[tela]) {
		player.exercicios[tela] = [[[],[],[]],[[],[],[]],[[],[],[]]];
	}

	if ($(this).closest('.conteudo-escondido').hasClass('estudo')) {
		var array = [[],[],[]];
		$(this).closest('.conteudo-escondido').find('.opcoesCurto').find('input:checked').each(function(index, el) {
			var opcao = $(this).closest('.opcao');
			var indexOpcao = $(this).closest('.conteudo-escondido').find('.opcoesCurto').find('.opcao').index(opcao);
			array[0].push(indexOpcao);
		});

		$(this).closest('.conteudo-escondido').find('.opcoesMedio').find('input:checked').each(function(index, el) {
			var opcao = $(this).closest('.opcao');
			var indexOpcao = $(this).closest('.conteudo-escondido').find('.opcoesMedio').find('.opcao').index(opcao);
			array[1].push(indexOpcao);
		});

		$(this).closest('.conteudo-escondido').find('.opcoesLongo').find('input:checked').each(function(index, el) {
			var opcao = $(this).closest('.opcao');
			var indexOpcao = $(this).closest('.conteudo-escondido').find('.opcoesLongo').find('.opcao').index(opcao);
			array[2].push(indexOpcao);
		});
		player.exercicios[tela][0] = array;
	}
	else if ($(this).closest('.conteudo-escondido').hasClass('trabalho')) {
		var array = [[],[],[]];
		$(this).closest('.conteudo-escondido').find('.opcoesCurto').find('input:checked').each(function(index, el) {
			var opcao = $(this).closest('.opcao');
			var indexOpcao = $(this).closest('.conteudo-escondido').find('.opcoesCurto').find('.opcao').index(opcao);
			array[0].push(indexOpcao);
		});

		$(this).closest('.conteudo-escondido').find('.opcoesMedio').find('input:checked').each(function(index, el) {
			var opcao = $(this).closest('.opcao');
			var indexOpcao = $(this).closest('.conteudo-escondido').find('.opcoesMedio').find('.opcao').index(opcao);
			array[1].push(indexOpcao);
		});

		$(this).closest('.conteudo-escondido').find('.opcoesLongo').find('input:checked').each(function(index, el) {
			var opcao = $(this).closest('.opcao');
			var indexOpcao = $(this).closest('.conteudo-escondido').find('.opcoesLongo').find('.opcao').index(opcao);
			array[2].push(indexOpcao);
		});
		player.exercicios[tela][1] = array;
	}
	else if ($(this).closest('.conteudo-escondido').hasClass('empreendedorismo')) {
		var array = [[],[],[]];
		$(this).closest('.conteudo-escondido').find('.opcoesCurto').find('input:checked').each(function(index, el) {
			var opcao = $(this).closest('.opcao');
			var indexOpcao = $(this).closest('.conteudo-escondido').find('.opcoesCurto').find('.opcao').index(opcao);
			array[0].push(indexOpcao);
		});

		$(this).closest('.conteudo-escondido').find('.opcoesMedio').find('input:checked').each(function(index, el) {
			var opcao = $(this).closest('.opcao');
			var indexOpcao = $(this).closest('.conteudo-escondido').find('.opcoesMedio').find('.opcao').index(opcao);
			array[1].push(indexOpcao);
		});

		$(this).closest('.conteudo-escondido').find('.opcoesLongo').find('input:checked').each(function(index, el) {
			var opcao = $(this).closest('.opcao');
			var indexOpcao = $(this).closest('.conteudo-escondido').find('.opcoesLongo').find('.opcao').index(opcao);
			array[2].push(indexOpcao);
		});
		player.exercicios[tela][2] = array;
	}
	

});

$('#tela11 *[data-target*="blocoUp"]').on('click', function() {
	var alvo = $(this).attr('data-target');

	if (alvo == 'blocoUp1') {
		$(this).closest('.tela').removeClass('tela12b');
		$(this).closest('.tela').removeClass('tela12c');

		$(this).closest('.tela').addClass('tela12a');
	}
	else if (alvo == 'blocoUp2') {
		$(this).closest('.tela').removeClass('tela12a');
		$(this).closest('.tela').removeClass('tela12c');

		$(this).closest('.tela').addClass('tela12b');
	}
	else {
		$(this).closest('.tela').removeClass('tela12b');
		$(this).closest('.tela').removeClass('tela12a');

		$(this).closest('.tela').addClass('tela12c');
	}
});

$('div[alt="tela12"] *[data-target*="blocoUp"]').on('click', function() {
	var alvo = $(this).attr('data-target');

	if (alvo == 'blocoUp1') {

		var curto = [];
		var medio = [];
		var longo = [];

		$('#tela12 .estudo .opcoesCurto').find('.opcao:not(.marcado)').each(function() {
			if ($(this).find('input:checked').next('label').html()) {
					curto.push($(this).find('input:checked').next('label').text());
			}
		});

		$('#tela12 .estudo .opcoesMedio').find('.opcao:not(.marcado)').each(function() {
			if ($(this).find('input:checked').next('label').html()) {
					medio.push($(this).find('input:checked').next('label').text());
			}
		});

		$('#tela12 .estudo .opcoesLongo').find('.opcao:not(.marcado)').each(function() {
			if ($(this).find('input:checked').next('label').html()) {
					longo.push($(this).find('input:checked').next('label').text());
			}
		});

		$(this).closest('.modal').find('.conteudo1').find('.longoPrazo').html(function() {
			var resultado = '';

			if (longo.length == 0) {
				resultado = 'Você não selecionou nada para longo prazo';
			}
			else {
				for (var i = 0; i < longo.length; i++) {
					resultado = resultado + '<li class="lista">' + longo[i] + '</li>';
				}
			}
			return resultado;
		});

		$(this).closest('.modal').find('.conteudo1').find('.medioPrazo').html(function() {
			var resultado = '';

			if (medio.length == 0) {
				resultado = 'Você não selecionou nada para médio prazo.';
			}
			else {
				for (var i = 0; i < medio.length; i++) {
					resultado = resultado + '<li class="lista">' + medio[i] + '</li>';
				}
			}
			return resultado;
		});
		$(this).closest('.modal').find('.conteudo1').find('.curtoPrazo').html(function() {
			var resultado = '';

			if (curto.length == 0) {
				resultado = 'Você não selecionou nada para curto prazo.';
			}
			else {
				for (var i = 0; i < curto.length; i++) {
					resultado = resultado + '<li class="lista">' + curto[i] + '</li>';
				}
			}
			return resultado;
		});

		$(this).closest('.modal').find('.conteudo3').hide();
		$(this).closest('.modal').find('.conteudo2').hide();
		$(this).closest('.modal').find('.conteudo1').show('fade');
	}
	else if (alvo == 'blocoUp2') {

		var curto = [];
		var medio = [];
		var longo = [];

		$('#tela12 .trabalho .opcoesCurto').find('.opcao:not(.marcado)').each(function() {
			if ($(this).find('input:checked').next('label').html()) {
					curto.push($(this).find('input:checked').next('label').text());
			}
		});

		$('#tela12 .trabalho .opcoesMedio').find('.opcao:not(.marcado)').each(function() {
			if ($(this).find('input:checked').next('label').html()) {
					medio.push($(this).find('input:checked').next('label').text());
			}
		});

		$('#tela12 .trabalho .opcoesLongo').find('.opcao:not(.marcado)').each(function() {
			if ($(this).find('input:checked').next('label').html()) {
					longo.push($(this).find('input:checked').next('label').text());
			}
		});

		$(this).closest('.modal').find('.conteudo2').find('.longoPrazo').html(function() {
			var resultado = '';

			if (longo.length == 0) {
				resultado = 'Você não selecionou nada para longo prazo';
			}
			else {
				for (var i = 0; i < longo.length; i++) {
					resultado = resultado + '<li class="lista">' + longo[i] + '</li>';
				}
			}
			return resultado;
		});

		$(this).closest('.modal').find('.conteudo2').find('.medioPrazo').html(function() {
			var resultado = '';

			if (medio.length == 0) {
				resultado = 'Você não selecionou nada para médio prazo.';
			}
			else {
				for (var i = 0; i < medio.length; i++) {
					resultado = resultado + '<li class="lista">' + medio[i] + '</li>';
				}
			}
			return resultado;
		});
		$(this).closest('.modal').find('.conteudo2').find('.curtoPrazo').html(function() {
			var resultado = '';

			if (curto.length == 0) {
				resultado = 'Você não selecionou nada para curto prazo.';
			}
			else {
				for (var i = 0; i < curto.length; i++) {
					resultado = resultado + '<li class="lista">' + curto[i] + '</li>';
				}
			}
			return resultado;
		});

		$(this).closest('.modal').find('.conteudo1').hide();
		$(this).closest('.modal').find('.conteudo3').hide();
		$(this).closest('.modal').find('.conteudo2').show('fade');
	}
	else {

		var curto = [];
		var medio = [];
		var longo = [];

		$('#tela12 .empreendedorismo .opcoesCurto').find('.opcao:not(.marcado)').each(function() {
			if ($(this).find('input:checked').next('label').html()) {
					curto.push($(this).find('input:checked').next('label').text());
			}
		});

		$('#tela12 .empreendedorismo .opcoesMedio').find('.opcao:not(.marcado)').each(function() {
			if ($(this).find('input:checked').next('label').html()) {
					medio.push($(this).find('input:checked').next('label').text());
			}
		});

		$('#tela12 .empreendedorismo .opcoesLongo').find('.opcao:not(.marcado)').each(function() {
			if ($(this).find('input:checked').next('label').html()) {
					longo.push($(this).find('input:checked').next('label').text());
			}
		});

		if (curto.length == 0 && medio.length == 0 && longo.length == 0) {
			$(this).closest('.modal').find('.conteudo3').html('<div><p>No momento, eu não pretendo empreender.</p></div>');
		}

		$(this).closest('.modal').find('.conteudo3').find('.longoPrazo').html(function() {
			var resultado = '';

			if (longo.length == 0) {
				resultado = 'Você não selecionou nada para longo prazo';
			}
			else {
				for (var i = 0; i < longo.length; i++) {
					resultado = resultado + '<li class="lista">' + longo[i] + '</li>';
				}
			}

			return resultado;
		});

		$(this).closest('.modal').find('.conteudo3').find('.medioPrazo').html(function() {
			var resultado = '';

			if (medio.length == 0) {
				resultado = 'Você não selecionou nada para médio prazo.';
			}
			else {
				for (var i = 0; i < medio.length; i++) {
					resultado = resultado + '<li class="lista">' + medio[i] + '</li>';
				}
			}


			return resultado;
		});

		$(this).closest('.modal').find('.conteudo3').find('.curtoPrazo').html(function() {
			var resultado = '';

			if (curto.length == 0) {
				resultado = 'Você não selecionou nada para curto prazo.';
			}
			else {
				for (var i = 0; i < curto.length; i++) {
					resultado = resultado + '<li class="lista">' + curto[i] + '</li>';
				}
			}


			return resultado;
		});

		$(this).closest('.modal').find('.conteudo1').hide();
		$(this).closest('.modal').find('.conteudo2').hide();
		$(this).closest('.modal').find('.conteudo3').show('fade');
	}
});

$('*[data-target*="anotacao"]').on('click', function() {
	var anotacaoAlvo = $(this).attr('data-target');
	var tela = $(this).closest('.tela').attr('id');
	$(this).closest('.tela').find('.anotacao').removeClass('ativo');
	$(this).closest('.tela').find('.'+anotacaoAlvo).addClass('ativo');
	$(this).closest('.tela').find('.'+anotacaoAlvo).focus();
});

$('*[data-target*="fecharModal"]').on('click', function() {
	player.fecharModal();
});

$('*[data-target*="forcarAvancar"]').on('click', function() {
	player.forcarAvancar();
});

$('.anotacao').on('input', function() {
	var tela = $(this).closest('.tela').attr('id');
	var tituloTela = $(this).closest('.tela').find('h3').html();
	var subtitulo = $(this).prev('.enunciado').html();
	var conteudo = $(this).val();
	var anotacaoId = $(this).attr('class').replace('anotacao ', '').replace(' ativo', '').replace(' preenchido', '');
	var textarea = '<textarea alt="' + anotacaoId + '" class="conteudo ' + anotacaoId + ' anotacaoBloco">' + conteudo + '</textarea>';

	if ($(this).val().length > 0) {
		$(this).closest('.estrutura').find('.avancarTomenota').removeClass('disabled');
	}

	player.inserirConteudoBlocodenotas(tela, tituloTela, subtitulo, textarea);

	if (!player.exercicios[tela]) {
		player.exercicios[tela] = [];
	}
	var array = [];
	$(this).closest('.estrutura').find('.anotacao').each(function(index, el) {
		var texto = $(this).val();
		if (!texto) {
			texto = '';
		}
		array[index] = texto;
	});
	player.exercicios[tela] = array;
});

$(document).on('input', '.anotacaoBloco', function() {
	var telaId = $(this).closest('div').attr('class');
	var anotacao = $(this).attr('class').replace('conteudo ', '').replace(' anotacaoBloco', '');
	var texto = $(this).val();
	$('#'+telaId).find('.'+anotacao).val(texto);
});

$('*[data-target*="fecharTooltip"]').on('click', function() {
	player.fecharTooltip($(this).closest('.tooltip'));
});

$('textarea').on('input', function() {
	var telaId = $(this).closest('.tela').attr('id');
	var modalTela = $('#overlay').find('div[alt="'+telaId+'"]');
	var tooltipTela = $('#tooltip').find('div[alt="'+telaId+'"]');
	var modalnVistos = 0;
	var modalnPreenchidos = 0;
	var modaltotalTarget = 0;
	var modaltotalTextarea = 0;
	var tooltipnVistos = 0;
	var tooltipnPreenchidos = 0;
	var tooltiptotalTarget = 0;
	var tooltiptotalTextarea = 0;

	if (modalTela) {

		for (var i = 0; i < modalTela.length; i++) {
			var modalAtual = $(modalTela[i]);
			modaltotalTarget = modaltotalTarget + modalAtual.find('*:not(.naoContar):not(.guardarAnotacao):not(.fecharModal):not(.fecharTooltip):not(.iconetomenota):not(input)[data-target]').length;
			modaltotalTextarea = modaltotalTextarea + modalAtual.find('textarea').length;
			modalnVistos = modalnVistos + modalAtual.find('*:not(.naoContar):not(.guardarAnotacao):not(.fecharModal):not(.fecharTooltip):not(.iconetomenota):not(input)[data-target]').length;
			modalnPreenchidos = modalnPreenchidos + modalAtual.find('.preenchido').length;
		}
	}

	if (tooltipTela) {
		for (var i = 0; i < tooltipTela.length; i++) {
			var tooltipAtual = $(tooltipTela[i]);
			tooltiptotalTarget = modaltotalTarget + tooltipAtual.find('*:not(.naoContar):not(.guardarAnotacao):not(.fecharModal):not(.fecharTooltip):not(.iconetomenota):not(input)[data-target]').length;
			tooltiptotalTextarea = modaltotalTextarea + tooltipAtual.find('textarea').length;
			tooltipnVistos = modalnVistos + tooltipAtual.find('*:not(.naoContar):not(.guardarAnotacao):not(.fecharModal):not(.fecharTooltip):not(.iconetomenota):not(input)[data-target]').length;
			tooltipnPreenchidos = modalnPreenchidos + tooltipAtual.find('.preenchido').length;
		}
	}

	$(this).addClass('preenchido');

	if ($(this).closest('.tela').find('*:not(.naoContar):not(.guardarAnotacao):not(.fecharModal):not(.fecharTooltip):not(.iconetomenota):not(input)[data-target]').length == $(this).closest('.tela').find('.visto').length && $(this).closest('.tela').find('textarea').length == $(this).closest('.tela').find('.preenchido').length && modalnVistos == modaltotalTarget && modalnPreenchidos == modaltotalTextarea && tooltipnVistos == tooltiptotalTarget && tooltipnPreenchidos == tooltiptotalTextarea) {
		$(this).closest('.tela').addClass('podePassar');
		$('#navAvancar').removeClass('disabled');
	}
});

$('*:not(.naoContar):not(.guardarAnotacao):not(.fecharModal):not(.fecharTooltip):not(.iconetomenota):not(input)[data-target]').on('click', function() {
	var telaId = $(this).closest('.tela').attr('id');
	var modalTela = $('#overlay').find('div[alt*="'+telaId+'"]');
	var tooltipTela = $('#tooltip').find('div[alt*="'+telaId+'"]');
	var modalnVistos = 0;
	var modalnPreenchidos = 0;
	var modaltotalTarget = 0;
	var modaltotalTextarea = 0;
	var tooltipnVistos = 0;
	var tooltipnPreenchidos = 0;
	var tooltiptotalTarget = 0;
	var tooltiptotalTextarea = 0;

	if (modalTela) {

		for (var i = 0; i < modalTela.length; i++) {
			var modalAtual = $(modalTela[i]);
			modaltotalTarget = modaltotalTarget + modalAtual.find('*:not(.naoContar):not(.guardarAnotacao):not(.fecharModal):not(.fecharTooltip):not(.iconetomenota):not(input)[data-target]').length;
			modaltotalTextarea = modaltotalTextarea + modalAtual.find('textarea').length;
			modalnVistos = modalnVistos + modalAtual.find('.visto').length;
			modalnPreenchidos = modalnPreenchidos + modalAtual.find('.preenchido').length;
		}
	}

	if (tooltipTela) {
		for (var i = 0; i < tooltipTela.length; i++) {
			var tooltipAtual = $(tooltipTela[i]);
			tooltiptotalTarget = tooltiptotalTarget + tooltipAtual.find('*:not(.naoContar):not(.guardarAnotacao):not(.fecharModal):not(.fecharTooltip):not(.iconetomenota):not(input)[data-target]').length;
			tooltiptotalTextarea = tooltiptotalTextarea + tooltipAtual.find('textarea').length;
			tooltipnVistos = tooltipnVistos + tooltipAtual.find('*:not(.naoContar):not(.guardarAnotacao):not(.fecharModal):not(.fecharTooltip):not(.iconetomenota):not(input)[data-target]').length;
			tooltipnPreenchidos = tooltipnPreenchidos + tooltipAtual.find('.preenchido').length;
		}
	}


	$(this).addClass('visto');


	if ($(this).closest('.tela').find('*:not(.naoContar):not(.guardarAnotacao):not(.fecharModal):not(.fecharTooltip):not(.iconetomenota):not(input)[data-target]').length == $(this).closest('.tela').find('.visto').length && $(this).closest('.tela').find('textarea').length == $(this).closest('.tela').find('.preenchido').length && modalnVistos == modaltotalTarget && modalnPreenchidos == modaltotalTextarea && tooltipnVistos == tooltiptotalTarget && tooltipnPreenchidos == tooltiptotalTextarea) {
		$(this).closest('.tela').addClass('podePassar');
		$('#navAvancar').removeClass('disabled');
	}
	else if ($(this).closest('.tela').attr('id') == 'tela12') {

	}
});

$('.guardarAnotacao').on('change', function() {
	var alvo = $(this).attr('data-target');
	$('.'+alvo).html($(this).val());

	if ($(this).closest('.tela').attr('id') == 'tela13') {
		var procurar = $(this).closest('.tomeNota').attr('class').replace('tomeNota ', '');
		$(this).closest('.tela').find('img[data-target="'+procurar+'"]').closest('li').addClass('visitado');
	}

	var tela = $(this).closest('.tela').attr('id');

	if (!player.exercicios[tela]) {
		player.exercicios[tela] = [];
	}

	$(this).closest('.estrutura').find('.guardarAnotacao').each(function() {
		var texto = $(this).val();
		if (!texto) {
			texto = '';
		}
		player.exercicios[tela].push(texto);
	});

});

$('#start').on('click', function() {
	$(this).closest('#tela-abertura').hide('slide', 800);
});

$('*[data-target="salvarExcel"]').on('click', function() {
	if ($('#excel').find('table')) {
		$('#excel').find('table').table2excel({
		    exclude: ".noExl",
		    name: "Planilha de consulta do aluno"
	    });
	}
});

/* ANIMATE.CSS */

$('#slick').on('beforeChange', function(e, slick, currentSlide, nextSlide) {
    var $animatingElements = $('div.tela[data-slick-index="' + nextSlide + '"]').find('[data-animation]');
    doAnimations($animatingElements);
});

function doAnimations(elements) {
        var animationEndEvents = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
        elements.each(function() {
            var $this = $(this);
            var $animationDelay = $this.data('delay');
            var $animationType = 'animated ' + $this.data('animation');
            $this.css({
                'animation-delay': $animationDelay,
                '-webkit-animation-delay': $animationDelay
            });
            $this.addClass($animationType).one(animationEndEvents, function() {
                $this.removeClass($animationType);
            });
        });
   }

$('.iconetomenota').on('click', function() {
	player.abrirModal($(this).attr('data-target'), 'modal1');
});

$('#tela17').find('.slide').find('.excel').elevateZoom({constrainType:"height", constrainSize:500, zoomType: "lens", containLensZoom: true, cursor: 'crosshair'});

var players = {};
var videosConfig = [];
var tooltipNumber = 0;
var modalNumber = 0;
var gravarFoco = '';
var input = 0;
var caretPosition = 1;
var aba1 = '';
var aba2 = '';
var loaded = false;
var loading = false;
var layout = '';
var editorial = '';

var objetos = {
    numeroCapitulo: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira o número do capítulo</span>'
    },
    nomeCapitulo: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira o nome do capítulo</span>'
    },
    disciplinaCapitulo: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira o nome da disciplina</span>'
    },
    titulo: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample">Título</span>'
    },
    subtitulo1: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample">Subtítulo 1</span>'
    },
    subtitulo2: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample">Subtítulo 2</span>'
    },
    subtitulo3: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample">Subtítulo 3</span>'
    },
    paragrafo: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed luctus massa ac tellus iaculis varius. Curabitur ac consectetur diam, consectetur ultricies ipsum. Phasellus posuere neque id ipsum euismod molestie. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed luctus massa ac tellus iaculis varius. Curabitur ac consectetur diam, consectetur ultricies ipsum. Phasellus posuere neque id ipsum euismod molestie. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed luctus massa ac tellus iaculis varius. Curabitur ac consectetur diam, consectetur ultricies ipsum. Phasellus posuere neque id ipsum euismod molestie. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed luctus massa ac tellus iaculis varius. Curabitur ac consectetur diam, consectetur ultricies ipsum. Phasellus posuere neque id ipsum euismod molestie.</span>'
    },
    blockquoteText: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample">Citação</span>'
    },
    blockquoteAuthor: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample">Autor</span>'
    },
    abaTitle: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample">Título da aba</span>'
    },
    listaOrdenada: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample"><ol><li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li><li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li><li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li></ol></span>'
    },
    lista: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample"><ul><li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li><li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li><li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li></ul></span>'
    },
    botao: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
    },
    videoLink: {
        placeholder: '&lt;iframe width="560" height="315" src="https://www&shy;.youtube.com/&shy;embed/Tux_&shy;D_vQP98" frameborder="0" allowfullscreen&gt;&lt;/iframe&gt;'
    },
    videoTitulo: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample">Inserir título do vídeo</span>'
    },
    videoDescricao: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample">Inserir descrição do vídeo</span>'
    },
    video: {
      placeholder: ['&nbsp;<span contentEditable="false" class="sample">Duração do vídeo</span>', '&nbsp;<span contentEditable="false" class="sample">Path do vídeo</span>', '&nbsp;<span contentEditable="false" class="sample">Id do vídeo</span>']
    },
    videoDuracao: {
      placeholder: '&nbsp;<span contentEditable="false" class="sample">Duração do vídeo</span>'
    },
    videoPath: {
      placeholder: '&nbsp;<span contentEditable="false" class="sample">Path do vídeo</span>'
    },
    videoId: {
      placeholder: '&nbsp;<span contentEditable="false" class="sample">Id do vídeo</span>'
    },
    tabela: {
        placeholder: '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span></div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>',
        titulo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira um título</span>'
        },
        subtitulo1: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira um subtítulo 1</span>'
        },
        subtitulo2: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira um subtítulo 2</span>'
        },
        subtitulo3: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira um subtítulo 3</span>'
        },
        paragrafo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira um parágrafo.</span>'
        },
        blockquote: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira uma citação</span>'
        },
        listaOrdenada: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira uma lista ordenada</span>'
        },
        lista: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira uma lista não ordenada</span>'
        },
        botao: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        videoLink: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">&lt;iframe width="560" height="315" src="https://www&shy;.youtube.com/&shy;embed/Tux_&shy;D_vQP98" frameborder="0" allowfullscreen&gt;&lt;/iframe&gt;</span>'
        },
        videoTitulo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Inserir título do vídeo</span>'
        },
        videoDescricao: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Inserir descrição do vídeo</span>'
        },
        video: {
            placeholder: ['&nbsp;<span contentEditable="false" class="sample">Duração do vídeo</span>', '&nbsp;<span contentEditable="false" class="sample">Path do vídeo</span>', '&nbsp;<span contentEditable="false" class="sample">Id do vídeo</span>']
        },
        videoDuracao: {
          placeholder: '&nbsp;<span contentEditable="false" class="sample">Duração do vídeo</span>'
        },
        videoPath: {
          placeholder: '&nbsp;<span contentEditable="false" class="sample">Path do vídeo</span>'
        },
        videoId: {
          placeholder: '&nbsp;<span contentEditable="false" class="sample">Id do vídeo</span>'
        }
    },
    colunas: {
        placeholder: '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">&nbsp;<span contentEditable="false" class="sample">Lorem ipsum dolor sit amet, con sec tetur adipiscing elit. Pha sellus mollis tortor vel nulla feugiat, vitae fringilla tellus maximus. Donec ut augue augue. Vestibu lum nunc odio, finibus id est ac, interdum porta neque.</span></div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>',
        titulo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        subtitulo1: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        subtitulo2: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        subtitulo3: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        paragrafo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Lorem ipsum dolor sit amet, con sec tetur adipiscing elit. Pha sellus mollis tortor vel nulla feugiat, vitae fringilla tellus maximus. Donec ut augue augue. Vestibu lum nunc odio, finibus id est ac, interdum porta neque.</span>'
        },
        blockquote: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        listaOrdenada: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        lista: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        botao: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        videoLink: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">&lt;iframe width="560" height="315" src="https://www&shy;.youtube.com/&shy;embed/Tux_&shy;D_vQP98" frameborder="0" allowfullscreen&gt;&lt;/iframe&gt;</span>'
        },
        videoTitulo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Inserir título do vídeo</span>'
        },
        videoDescricao: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Inserir descrição do vídeo</span>'
        },
        video: {
            placeholder: ['&nbsp;<span contentEditable="false" class="sample">Duração do vídeo</span>', '&nbsp;<span contentEditable="false" class="sample">Path do vídeo</span>', '&nbsp;<span contentEditable="false" class="sample">Id do vídeo</span>']
        },
        videoDuracao: {
          placeholder: '&nbsp;<span contentEditable="false" class="sample">Duração do vídeo</span>'
        },
        videoPath: {
          placeholder: '&nbsp;<span contentEditable="false" class="sample">Path do vídeo</span>'
        },
        videoId: {
          placeholder: '&nbsp;<span contentEditable="false" class="sample">Id do vídeo</span>'
        }
    },
    slider: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>',
        titulo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        subtitulo1: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        subtitulo2: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        subtitulo3: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        paragrafo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        blockquote: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        listaOrdenada: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        lista: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        botao: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        videoLink: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">&lt;iframe width="560" height="315" src="https://www&shy;.youtube.com/&shy;embed/Tux_&shy;D_vQP98" frameborder="0" allowfullscreen&gt;&lt;/iframe&gt;</span>'
        },
        videoTitulo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Inserir título do vídeo</span>'
        },
        videoDescricao: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Inserir descrição do vídeo</span>'
        },
        video: {
            placeholder: ['&nbsp;<span contentEditable="false" class="sample">Duração do vídeo</span>', '&nbsp;<span contentEditable="false" class="sample">Path do vídeo</span>', '&nbsp;<span contentEditable="false" class="sample">Id do vídeo</span>']
        },
        videoDuracao: {
          placeholder: '&nbsp;<span contentEditable="false" class="sample">Duração do vídeo</span>'
        },
        videoPath: {
          placeholder: '&nbsp;<span contentEditable="false" class="sample">Path do vídeo</span>'
        },
        videoId: {
          placeholder: '&nbsp;<span contentEditable="false" class="sample">Id do vídeo</span>'
        }
    },
    tooltipElement: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira um parágrafo</span>',
        titulo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        subtitulo1: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        subtitulo2: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        subtitulo3: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        paragrafo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        blockquote: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        listaOrdenada: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        lista: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        botao: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        videoLink: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">&lt;iframe width="560" height="315" src="https://www&shy;.youtube.com/&shy;embed/Tux_&shy;D_vQP98" frameborder="0" allowfullscreen&gt;&lt;/iframe&gt;</span>'
        },
        videoTitulo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Inserir título do vídeo</span>'
        },
        videoDescricao: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Inserir descrição do vídeo</span>'
        },
        video: {
            placeholder: ['&nbsp;<span contentEditable="false" class="sample">Duração do vídeo</span>', '&nbsp;<span contentEditable="false" class="sample">Path do vídeo</span>', '&nbsp;<span contentEditable="false" class="sample">Id do vídeo</span>']
        },
        videoDuracao: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Duração do vídeo</span>'
        },
        videoPath: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Path do vídeo</span>'
        },
        videoId: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Id do vídeo</span>'
        }
    },
    flipcard: {

        placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>',

        titulo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        subtitulo1: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        subtitulo2: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        subtitulo3: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        paragrafo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        blockquote: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        listaOrdenada: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        lista: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        botao: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        videoLink: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">&lt;iframe width="560" height="315" src="https://www&shy;.youtube.com/&shy;embed/Tux_&shy;D_vQP98" frameborder="0" allowfullscreen&gt;&lt;/iframe&gt;</span>'
        },
        videoTitulo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Inserir título do vídeo</span>'
        },
        videoDescricao: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Inserir descrição do vídeo</span>'
        },
        video: {
            placeholder: ['&nbsp;<span contentEditable="false" class="sample">Duração do vídeo</span>', '&nbsp;<span contentEditable="false" class="sample">Path do vídeo</span>', '&nbsp;<span contentEditable="false" class="sample">Id do vídeo</span>']
        },
        videoDuracao: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Duração do vídeo</span>'
        },
        videoPath: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Path do vídeo</span>'
        },
        videoId: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Id do vídeo</span>'
        }
    },
    accordion: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>',

        titulo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        subtitulo1: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        subtitulo2: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        subtitulo3: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        paragrafo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        blockquote: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        listaOrdenada: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        lista: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        botao: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        videoLink: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">&lt;iframe width="560" height="315" src="https://www&shy;.youtube.com/&shy;embed/Tux_&shy;D_vQP98" frameborder="0" allowfullscreen&gt;&lt;/iframe&gt;</span>'
        },
        videoTitulo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Inserir título do vídeo</span>'
        },
        videoDescricao: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Inserir descrição do vídeo</span>'
        },
        video: {
            placeholder: ['&nbsp;<span contentEditable="false" class="sample">Duração do vídeo</span>', '&nbsp;<span contentEditable="false" class="sample">Path do vídeo</span>', '&nbsp;<span contentEditable="false" class="sample">Id do vídeo</span>']
        },
        videoDuracao: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Duração do vídeo</span>'
        },
        videoPath: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Path do vídeo</span>'
        },
        videoId: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Id do vídeo</span>'
        }
    },
    abas: {
        placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>',

        titulo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        subtitulo1: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        subtitulo2: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        subtitulo3: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        paragrafo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        blockquote: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        listaOrdenada: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        lista: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        botao: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Insira seu texto</span>'
        },
        videoLink: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">&lt;iframe width="560" height="315" src="https://www&shy;.youtube.com/&shy;embed/Tux_&shy;D_vQP98" frameborder="0" allowfullscreen&gt;&lt;/iframe&gt;</span>'
        },
        videoTitulo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Inserir título do vídeo</span>'
        },
        videoDescricao: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Inserir descrição do vídeo</span>'
        },
        video: {
            placeholder: ['&nbsp;<span contentEditable="false" class="sample">Duração do vídeo</span>', '&nbsp;<span contentEditable="false" class="sample">Path do vídeo</span>', '&nbsp;<span contentEditable="false" class="sample">Id do vídeo</span>']
        },
        videoDuracao: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Duração do vídeo</span>'
        },
        videoPath: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Path do vídeo</span>'
        },
        videoId: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Id do vídeo</span>'
        }
    },
    banner: {

        placeholder: '&nbsp;<span contentEditable="false" class="sample">Pellentesque accumsan non mauris nec bibendum. Vestibulum sit amet nunc eget nisi scelerisque sagittis sit amet at ante. Donec pharetra elit aliquet sapien fringilla consequat. Suspendisse quis semper eros, scelerisque auctor felis. Phasellus fermentum pulvinar sapien eu bibendum. Praesent at rutrum massa. Nullam ut interdum dolor, sed scelerisque augue. Phasellus eget lacinia velit. Nulla at odio tincidunt, accumsan odio sit amet, ultricies est. Phasellus venenatis varius ex, ut iaculis nulla molestie dictum. Ut condimentum varius laoreet. Suspendisse eleifend, leo et tristique ultricies, sapien velit placerat nulla, ac scelerisque purus erat in tellus.</span>',

        titulo: {
            placeholder: '&nbsp;<span contentEditable="false" class="sample">Pellentesque accumsan non mauris nec bibendum. Vestibulum sit amet nunc eget nisi scelerisque sagittis sit amet at ante. Donec pharetra elit aliquet sapien fringilla consequat. Suspendisse quis semper eros, scelerisque auctor felis. Phasellus fermentum pulvinar sapien eu bibendum. Praesent at rutrum massa. Nullam ut interdum dolor, sed scelerisque augue. Phasellus eget lacinia velit. Nulla at odio tincidunt, accumsan odio sit amet, ultricies est. Phasellus venenatis varius ex, ut iaculis nulla molestie dictum. Ut condimentum varius laoreet. Suspendisse eleifend, leo et tristique ultricies, sapien velit placerat nulla, ac scelerisque purus erat in tellus.</span>'
        }
    }
};

var overlay = {
    status: 'fechado',
    abrir: function(overlay) {
        $(overlay).css({'visibility': 'visible', 'opacity': 1});
        $('body').css({'overflow': 'hidden'});
        this.status = 'aberto';
        $("#conteudo").sortable( "disable" );
        $("#conteudo2").sortable( "disable" );
    },
    fechar: function() {
        $('.overlay').css({'visibility': 'hidden', 'opacity': 0});
        $('body').css({'overflow': 'auto'});
        this.status = 'fechado';
        $("#conteudo").sortable( "enable" );
        $("#conteudo2").sortable( "enable" );
    }
}

$.createEventCapturing = (function () {
  var special = $.event.special;
  return function (names) {
    if (!document.addEventListener) {
      return;
    }
    if (typeof names == 'string') {
      names = [names];
    }
    $.each(names, function (i, name) {
      var handler = function (e) {
        e = $.event.fix(e);
        return $.event.dispatch.call(this, e);
      };
      special[name] = special[name] || {};
      if (special[name].setup || special[name].teardown) {
        return;
      }
      $.extend(special[name], {
        setup: function () {
          this.addEventListener(name, handler, true);
        },
        teardown: function () {
          this.removeEventListener(name, handler, true);
        }
      });
    });
  };})();

$.createEventCapturing(['timeupdate', 'ended', 'loadstart', 'durationchange', 'loadedmetadata', 'loadeddata', 'canplay', 'canplaythrough']);

function getActiveView() {
    // var id = $('.menuEdicao').find('.active').attr('id');
    // if (id == 'texto') {
    //     return 'conteudo';
    // }
    // else {
    //     return 'conteudo2';
    // }
    return 'conteudo';
}

function stopSortable(event, ui) {
        var abaActive = getActiveView();
        var view = '';

        if(overlay.status == 'aberto') {
            view = '#overlayEdicao .modalArea:visible .open_modal'
        }
        else {
            view = '#' + abaActive;
        }

        var placeholder = '';
        var tipo = ui.item.attr('class').replace(/inserirElemento/g, '').replace(/ui-draggable-handle/g, '').replace(/ui-draggable-dragging/g, '').replace(/ui-draggable/g, '').replace(/sendoArrastado/g, '').replace(/\s/g, '');
         if (event.target.classList.contains('celula')) {
            if (objetos['tabela'][tipo]) {
                placeholder = objetos['tabela'][tipo].placeholder;
            }
         }
         else if (event.target.classList.contains('open_tooltip')) {
            if (objetos['tooltipElement'][tipo]) {
                placeholder = objetos['tooltipElement'][tipo].placeholder;
            }
         }
         else if (event.target.classList.contains('coluna')) {
            if (objetos['slider'][tipo]) {
                placeholder = objetos['colunas'][tipo].placeholder;
            }
         }
         else if (event.target.classList.contains('slide')) {
            if (objetos['slider'][tipo]) {
                placeholder = objetos['slider'][tipo].placeholder;
            }
         }
         else if (event.target.classList.contains('accordionArea')) {
            if (objetos['accordion'][tipo]) {
                placeholder = objetos['accordion'][tipo].placeholder;
            }
         }
         else if (event.target.classList.contains('abaContent')) {
            if (objetos['abas'][tipo]) {
                placeholder = objetos['abas'][tipo].placeholder;
            }
         }
         else {
            if (objetos[tipo]) {
                placeholder = objetos[tipo].placeholder;
            }
         }
        var elemento = '';
        if (ui.item.attr('class').indexOf('subtitulo1') != -1) {

          elemento = inserirElemento('subtitulo1', false, false, placeholder);


        }
        else if (ui.item.attr('class').indexOf('subtitulo2') != -1) {

          elemento = inserirElemento('subtitulo2', false, false, placeholder);

        }
        else if (ui.item.attr('class').indexOf('subtitulo3') != -1) {

          elemento = inserirElemento('subtitulo3', false, false, placeholder);

        }
        else if (ui.item.attr('class').indexOf('titulo') != -1) {

          elemento = inserirElemento('titulo', false, false, placeholder);

        }
        else if (ui.item.attr('class').indexOf('paragrafo') != -1) {
          elemento = inserirElemento('paragrafo', false, false, placeholder);

        }
        else if (ui.item.attr('class').indexOf('listaOrdenada') != -1) {

          elemento = inserirElemento('listaOrdenada', false, false, placeholder);

        }
        else if (ui.item.attr('class').indexOf('lista') != -1) {

          elemento = inserirElemento('lista', false, false, placeholder);

        }
        else if (ui.item.attr('class').indexOf('blockquote') != -1) {

          elemento = inserirElemento('blockquote', false, false, placeholder);

        }
        else if (ui.item.attr('class').indexOf('videoLink') != -1) {

          elemento = inserirElemento('videoLink', false, false, placeholder);

        }
        else if (ui.item.attr('class').indexOf('video') != -1) {

          elemento = inserirElemento('video', false, false, placeholder);

        }
        else if (ui.item.attr('class').indexOf('colunas') != -1) {
          elemento = inserirElemento('colunas', false, false, placeholder);

        }
        else if (ui.item.attr('class').indexOf('tabela') != -1) {
          elemento = inserirElemento('tabela', false, false, placeholder);

        }
        else if (ui.item.attr('class').indexOf('imagem') != -1) {

          elemento = inserirElemento('imagem', false, false, placeholder);

        }
        else if (ui.item.attr('class').indexOf('galeria') != -1) {

          elemento = inserirElemento('galeria', false, false, placeholder);

        }
        else if (ui.item.attr('class').indexOf('botao') != -1) {

          elemento = inserirElemento('botao', false, false, placeholder);

        }
        else if (ui.item.attr('class').indexOf('audio') != -1) {

          elemento = inserirElemento('audio', false, false, placeholder);

        }
        else if (ui.item.attr('class').indexOf('slider') != -1) {
            elemento = inserirElemento('slider', false, false, placeholder);
        }
        else if (ui.item.attr('class').indexOf('flipcard') != -1) {
          elemento = inserirElemento('flipcard', false, false, placeholder);

        }
        else if (ui.item.attr('class').indexOf('banner') != -1) {
          elemento = inserirElemento('banner', false, false, placeholder);
        }
        else if (ui.item.attr('class').indexOf('accordion') != -1) {
          elemento = inserirElemento('accordion', false, false, placeholder);
        }

        if (tipo.indexOf('drag') == -1) {
          $(ui.item).replaceWith(elemento);
        }

        $(view).find('.sliderpersonalizado').each(function() {
            if(!$(this).hasClass('slick-initialized')) {
                $(this).slick({
                    dots: false,
                    arrows: false,
                    draggable: false,
                    speed: 500,
                    accessibility: false,
                    infinite: false,
                    adaptiveHeight: true,
                    zIndex: 1,
                    touchMove: false,
                    onInit: function() {
                        if (!$(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).hasClass('aceitaElementos')) {
                            $(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).addClass('aceitaElementos');
                            $(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).addClass('elemento');
                        }
                    }
                });
            }
        });

        createSortables();
}

function disableSortables(array) {
    $('.' + array).each(function(index, el) {
        $(el).sortable('disable');
    });
}

function createSortables() {
    $('.elemento').each(function() {
        if (!$(this).hasClass('aceitaElementos')) {
            $(this).sortable({
                connectWith: ".aceitaElementos",
                handle: ".mover",
                cancel: ".remover",
                tolerance: 'pointer',
                placeholder: "sortable-placeholder",
                forcePlaceholderSize: true,
                forceHelperSize: true,
                revert: 0
            });
        }
    });

    $('.coluna').sortable({
        connectWith: ".coluna",
        handle: ".mover",
        cancel: ".remover",
        placeholder: "sortable-placeholder",
        tolerance: 'pointer',
        forcePlaceholderSize: true,
        forceHelperSize: true,
        revert: 0,
        stop: function(e,ui) {
            stopSortable(e,ui);
        }
    });

    $('.celula').sortable({
        connectWith: ".celula",
        handle: ".mover",
        cancel: ".remover",
        items: "> div",
        placeholder: "sortable-placeholder",
        tolerance: 'pointer',
        forcePlaceholderSize: true,
        forceHelperSize: true,
        revert: 0,
        stop: function(e,ui) {
            stopSortable(e,ui);
        }
    });

    $('.open_tooltip').sortable({
        connectWith: ".open_tooltip",
        handle: ".mover",
        cancel: ".remover",
        items: "> div",
        placeholder: "sortable-placeholder",
        tolerance: 'pointer',
        forcePlaceholderSize: true,
        forceHelperSize: true,
        revert: 0,
        stop: function(e,ui) {
            stopSortable(e,ui);
        }
    });

    $('.open_modal').sortable({
        connectWith: ".open_modal",
        handle: ".mover",
        cancel: ".remover",
        items: "> div",
        placeholder: "sortable-placeholder",
        tolerance: 'pointer',
        forcePlaceholderSize: true,
        forceHelperSize: true,
        revert: 0,
        stop: function(e,ui) {
            stopSortable(e,ui);
        }
    });

    $('.slide').sortable({
        connectWith: ".aceitaElementos",
        handle: ".mover",
        cancel: ".remover",
        items: "> div:not(.sortable-disable)",
        placeholder: "sortable-placeholder",
        tolerance: 'pointer',
        forcePlaceholderSize: true,
        forceHelperSize: true,
        revert: 0,
        start: function(e,ui) {
            var slick = $(e.target).closest('.sliderpersonalizado');
            updateSlick(slick);
        },
        stop: function(e,ui) {
            stopSortable(e,ui);
            var slick = $(e.target).closest('.sliderpersonalizado');
            updateSlick(slick);
        }
    });

    $('.accordionArea').sortable({
        connectWith: ".accordionArea",
        handle: ".mover",
        cancel: ".remover",
        items: "> div:not(.sortable-disable)",
        placeholder: "sortable-placeholder",
        tolerance: 'pointer',
        forcePlaceholderSize: true,
        forceHelperSize: true,
        revert: 0,
        stop: function(e,ui) {
            stopSortable(e,ui);
        }
    });

    $('.abaContent').sortable({
        connectWith: ".abaContent",
        handle: ".mover",
        cancel: ".remover",
        items: "> div:not(.sortable-disable)",
        placeholder: "sortable-placeholder",
        tolerance: 'pointer',
        forcePlaceholderSize: true,
        forceHelperSize: true,
        revert: 0,
        stop: function(e,ui) {
            stopSortable(e,ui);
        }
    });
}

function updateSlick(slick) {
    slick.slickGoTo(slick.slickCurrentSlide());
    slick.find('.slick-list').height('auto');
}

function updateSlickSlide(el) {
        $(el).closest('li').closest('.slick-nav').find('a').each(function() {
            $(this).removeClass('active');
        });

        $(el).closest('.galeriapersonalizadanav').next('.slick').slickGoTo($(el).attr('data-slide'));
        $(el).addClass('active');

        $(el).closest('li').closest('.slick-nav').closest('.galeriapersonalizadanav').next('.sliderpersonalizado').find('.slide').each(function() {
            if (!$(this).closest('.slick_slide').hasClass('slick-active')) {
                $(this).removeClass('aceitaElementos');
                $(this).removeClass('elemento');
            }
        });

        var novoTitulo = $(el).closest('.galeriapersonalizadanav').next('.sliderpersonalizadoResultado').find('.slick-active').find('h1').eq(0).html();
        $(el).closest('.galeriapersonalizadanav').find('h1').eq(0).html(novoTitulo);

        $(el).closest('.galeriapersonalizadanav').next('.sliderpersonalizado').find('.slick-active').find('.slide').addClass('aceitaElementos');
        $(el).closest('.galeriapersonalizadanav').next('.sliderpersonalizado').find('.slick-active').find('.slide').addClass('elemento');
}

function getSelectionText() {
    var text = "";
    if (window.getSelection) {
        text = window.getSelection().toString();
    } else if (document.selection && document.selection.type != "Control") {
        text = document.selection.createRange().text;
    }
    return text;
}

function replaceSelectedText(replacementText) {
    var sel, range;
    if (window.getSelection) {
        sel = window.getSelection();
        if (sel.rangeCount) {
            range = sel.getRangeAt(0);
            range.deleteContents();
            range.insertNode(document.createTextNode(replacementText));
        }
    } else if (document.selection && document.selection.createRange) {
        range = document.selection.createRange();
        range.text = replacementText;
    }
}

function setCaret(el, position) {
    var el = el;
    var range = document.createRange();
    var sel = window.getSelection();
    range.setStart(el.childNodes[0], position);
    range.collapse(true);
    sel.removeAllRanges();
    sel.addRange(range);
}

function getCaretPosition(editableDiv) {
  var caretPos = 0,
    sel, range;
  if (window.getSelection) {
    sel = window.getSelection();
    if (sel.rangeCount) {
      range = sel.getRangeAt(0);
      if (range.commonAncestorContainer.parentNode == editableDiv) {
        caretPos = range.endOffset;
      }
    }
  } else if (document.selection && document.selection.createRange) {
    range = document.selection.createRange();
    if (range.parentElement() == editableDiv) {
      var tempEl = document.createElement("span");
      editableDiv.insertBefore(tempEl, editableDiv.firstChild);
      var tempRange = range.duplicate();
      tempRange.moveToElementText(tempEl);
      tempRange.setEndPoint("EndToEnd", range);
      caretPos = tempRange.text.length;
    }
  }
  return caretPos;
}

function showResultElement(elemento, tag, tipo, conteudo) {
    var newString = '';
    if(conteudo != '' && conteudo != '&nbsp;') {
        if (tipo.indexOf('subtitulo1') != -1) {
            newString = '<h2>' + conteudo + '</h2>';
            newString = newString.replaceAll('<div>', '');
            newString = newString.replaceAll('</div>', '<br />');
        }
        else if (tipo.indexOf('subtitulo2') != -1) {
            newString = '<h3>' + conteudo + '</h3>';
            newString = newString.replaceAll('<div>', '');
            newString = newString.replaceAll('</div>', '<br />');
        }
        else if (tipo.indexOf('subtitulo3') != -1) {
            newString = '<h4>' + conteudo + '</h4>';
            newString = newString.replaceAll('<div>', '');
            newString = newString.replaceAll('</div>', '<br />');
        }
        else if (tipo.indexOf('titulo') != -1) {
            newString = '<h1>' + conteudo + '</h1>';
            newString = newString.replaceAll('<div>', '');
            newString = newString.replaceAll('</div>', '<br />');
        }
        else if (tipo.indexOf('paragrafo') != -1) {
            newString = '<p>' + conteudo + '</p>';
            newString = newString.replaceAll('<div>', '');
            newString = newString.replaceAll('</div>', '<br />');
        }
        else if (tipo.indexOf('botao') != -1) {
            newString = '<button class="botao">' + conteudo + '</button>';
            newString = newString.replaceAll('<div>', '');
            newString = newString.replaceAll('</div>', '<br />');
        }
        else if (tipo.indexOf('listaOrdenada') != -1) {
            array = conteudo.replaceAll('</div>', '').split('<br>');
            for (var j = 0, novoConteudo = ''; j < array.length; j++) {
                if (array[j].indexOf('<li>') != -1) {
                  novoConteudo = novoConteudo + array[j];
                }
                else {
                  if (array[j].indexOf('<ol>') != -1) {
                      novoConteudo = novoConteudo + array[j];
                    }
                    else if (array[j]) {
                      novoConteudo = novoConteudo + '<li>' + array[j] + '</li>';
                    }
                }
            }
            newString = '<ol>' + novoConteudo + '</ol>';
        }
        else if (tipo.indexOf('lista') != -1) {
            array = conteudo.replaceAll('</div>', '').split('<br>');
            for (var j = 0, novoConteudo = ''; j < array.length; j++) {
                if (array[j].indexOf('<li>') != -1) {
                  novoConteudo = novoConteudo + array[j];
                }
                else {
                  if (array[j].indexOf('<ul>') != -1) {
                      novoConteudo = novoConteudo + array[j];
                    }
                    else if (array[j]) {
                      novoConteudo = novoConteudo + '<li>' + array[j] + '</li>';
                    }
                }
            }
            newString = '<ul>' + novoConteudo + '</ul>';
        }
        else if (tipo.indexOf('blockquoteText') != -1) {
            newString = '<p class="blockquoteText">' + conteudo + '</p>';
            newString = newString.replaceAll('<div>', '');
            newString = newString.replaceAll('</div>', '<br />');
        }
        else if (tipo.indexOf('blockquoteAuthor') != -1) {
            newString = '<p class="blockquoteAuthor">' + conteudo + '</p>';
            newString = newString.replaceAll('<div>', '');
            newString = newString.replaceAll('</div>', '<br />');
        }
        else if (tipo.indexOf('blockquote') != -1) {
            newString = '<div class="blockquote">' + conteudo + '</div>';
        }

        else if (tipo.indexOf('imagemFundo') != -1) {
            var array = conteudo.split('data:image');
            newString = '<div class="imagemFundo" style="background-image: url(data:image' + array[1] + ')"></div>';
        }
        else if (tipo.indexOf('imagem') != -1) {
            var array = conteudo.split('data:image');
            newString = '<img src="data:image' + array[1] + '">';
        }
        else if (tipo.indexOf('galeria') != -1) {
            var array = conteudo.split('data:image');
            if (array.length == 2) {
                newString = '<img src="data:image' + array[1] + '">'
            }
            else {
                for (var j = 1, novoConteudo = ''; j < array.length; j++) {
                    novoConteudo = novoConteudo + '<div class="slick_slide"><img src="data:image' + array[j] + '"></div>';
                }
                newString = '<div class="galeriaImagens">' + novoConteudo + '</div>';
            }
        }
        else if (tipo.indexOf('audio') != -1) {

            var array = conteudo.split('data:audio');
            newString = '<div class="audioPlayer"><button class="playButton play"><span class="play-icon"></span></button><div class="timeline"><div class="timeline_completed"></div><div class="playhead"></div></div><p class="audio_duration"></p><audio src="data:audio' + array[1] + '">Player not available on this device.</audio></div>'
        }
        else if (tipo.indexOf('videoLink') != -1) {
            conteudo = conteudo.replace(/&lt;/g, '<').replace(/&gt;/g, '>');
            newString = '<div class="videoDiv"><div>' + conteudo + '</div></div>';
        }
        else if (tipo.indexOf('video') != -1) {
            var playerIndex = videosConfig.length + 1;
            var playerNumber = 'player' + playerIndex;
            var videoConfig = {
                width: 640,
                height: 360,
                ph: "",
                m: "",
                playerParams: {
                  wideScreen: true,
                  html5: true
                }
            };
            var duracao = elemento.find('.video-duracao').html();
            var path = elemento.find('.video-path').html();
            var id = elemento.find('.video-id').html();

            videoConfig["ph"] = path;
            videoConfig["m"] = id;

            videosConfig.push(videoConfig);
            newString = '<div class="teste3" alt="' + duracao + '"><div id="' + playerNumber + '" class="teste2"></div></div>';
        }
        else if (tipo.indexOf('slider') != -1) {
            newString = '<div class="slider">' + conteudo + '</div>';
            newString = newString.replace(/sliderpersonalizado/g, 'sliderpersonalizadoResultado')
        }
        else if (tipo.indexOf('slide') != -1) {
            newString = conteudo;
        }
        else if (tipo.indexOf('open_tooltip') != -1) {
            newString = '<div class="' + tipo.replace('aceitaElementos elemento ui-sortable', '') +'">' + conteudo + '</div>';
        }
        else if (tipo.indexOf('open_modal') != -1) {
            newString = '<div class="' + tipo.replace('aceitaElementos elemento ui-sortable', '') +'">' + conteudo + '</div>';
        }
        else if (tipo.indexOf('tooltip') != -1) {
            newString = '<div class="botao">' + conteudo + '</div>';
        }
        else if (tipo.indexOf('tooltip') != -1) {
            newString = conteudo;
        }
        else if (tipo.indexOf('modal') != -1) {
            newString = conteudo;
        }
        else if (tipo.indexOf('flipcards') != -1) {
            newString = '<div class="flipcards">' + conteudo + '</div>';
        }
        else if (tipo.indexOf('front') != -1) {
            newString = '<div class="front"><div class="flip-content">' + conteudo + '</div></div>';
        }
        else if (tipo.indexOf('back') != -1) {
            newString = '<div class="back"><div class="flip-content">' + conteudo + '</div></div>';
        }
        else if (tipo.indexOf('banner') != -1) {
            newString = '<div class="banner">' + conteudo + '</div>';
        }
        else if (tipo.indexOf('accordionArea') != -1) {
            newString = '<div class="accordionArea">' + conteudo + '</div>';
        }
        else if (tipo.indexOf('accordion') != -1) {
            newString = '<div class="accordion">' + conteudo + '</div>';
        }
        else if (tipo.indexOf('abaTitle') != -1) {
            newString = '<p class="abaTitle">' + conteudo + '</p>';
        }
        else if (tipo.indexOf('abaContent') != -1) {
            newString = '<div class="abaContent">' + conteudo + '</div>';
        }
        else if (tipo.indexOf('abasElement') != -1) {
            newString = '<div class="abasElement">' + conteudo + '</div>';
        }
    }

    if (tipo.indexOf('colunas') != -1) {
            newString = '<div class="colunas">' + conteudo + '</div>';
        }
    else if (tipo.indexOf('coluna') != -1) {
            // var tamanho = $(elemento).closest('.colunas').children().length;
            // newString = '<div class="coluna" style="width: ' + ((100/tamanho) - 2)  + '%">' + conteudo + '</div>';
            newString = '<div class="coluna">' + conteudo + '</div>';
        }
    else if (tipo.indexOf('celula') != -1) {
      if (tag == 'TH') {
        newString = '<th>' + conteudo + '</th>';
      }
      else {
        newString = '<td>' + conteudo + '</td>';
      }
    }

    return newString
}


function showTooltip(className) {
    $('.open_tooltip').closest('.tooltipArea').hide();

    var abaActive = getActiveView();
    var view = '';

    if(overlay.status == 'aberto') {
        view = '#overlayEdicao'
    }
    else {
        view = '#' + abaActive;
    }

    var tooltip = $(view).find('.' + className);
    var openTooltip = $('#' + abaActive).find('.open_tooltip' + className.replace('tooltip', '')).eq(0).closest('.tooltipArea');

    var abaPositionX = $(view).offset().left;
    var abaPositionY = $(view).offset().top;
    var aba_width = $(view).width();
    var tooltipPositionX = tooltip.offset().left - abaPositionX;
    var tooltipPositionY = tooltip.offset().top - abaPositionY;
    var openTooltipHeight = openTooltip.height();
    var openTooltipWidth = openTooltip.width();
    var pop_position_right = aba_width - tooltipPositionX;
    var finalPositionY = tooltipPositionY + tooltip.outerHeight() - 20;
    var top = 0;
    var left = 0;

    if (pop_position_right < openTooltipWidth) {
        left = tooltipPositionX - openTooltipWidth/2 + 40 + tooltip.width();
    }
    else {
        left = tooltipPositionX + abaPositionX;
    }

    if (tooltipPositionY < openTooltipHeight) {
        top = tooltipPositionY + abaPositionY + 30;
    }
    else {
        top = tooltipPositionY + abaPositionY - openTooltipHeight - 5;
        left = left - 54;
    }
    openTooltip.show();
    openTooltip.offset({top: top, left: left});
}

function showTooltipResultado(className) {
    $('.open_tooltip').closest('.tooltipArea').hide();

    var abaActive = getActiveView();
    var view = '';

    if(overlay.status == 'aberto') {
        view = '#overlayEdicao'
    }
    else {
        view = '#' + abaActive;
    }

    var tooltip = $('#resultado').find('.' + className);
    var openTooltip = $('#resultado').find('.open_tooltip' + className.replace('tooltip', '')).closest('.tooltipArea');

    /*var abaPositionX = $(view).offset().left;
    var abaPositionY = $(view).offset().top;
    var aba_width = $(view).width();
    var tooltipPositionX = tooltip.offset().left - abaPositionX;
    var tooltipPositionY = tooltip.offset().top - abaPositionY;
    var openTooltipHeight = openTooltip.height();
    var openTooltipWidth = openTooltip.width();
    var pop_position_right = aba_width - tooltipPositionX;
    var finalPositionY = tooltipPositionY + tooltip.outerHeight() - 20;
    var top = 0;
    var left = 0;

    if (pop_position_right < openTooltipWidth) {
        left = tooltipPositionX - openTooltipWidth/2 + 40 + tooltip.width();
    }
    else {
        left = tooltipPositionX + abaPositionX;
    }

    if (tooltipPositionY < openTooltipHeight) {
        top = tooltipPositionY + abaPositionY + 30;
    }
    else {
        top = tooltipPositionY + abaPositionY - openTooltipHeight - 5;
        left = left - 54;
    }
    openTooltip.show();
    openTooltip.offset({top: top, left: left});*/

    var tooltipPositionX = tooltip.offset().left;
    var tooltipPositionY = tooltip.offset().top;
    var openTooltipHeight = openTooltip.height();
    var openTooltipWidth = openTooltip.width();
    var doc_width = $(window).width();
    var pop_position_right = doc_width - tooltip.offset().left;
    var finalPositionY = tooltipPositionY + tooltip.outerHeight() - 20;

    if (tooltipPositionY < openTooltipHeight) {
        tooltipPositionY = tooltipPositionY + 30;
        openTooltip.offset({top: tooltipPositionY});
    }
    else {
        tooltipPositionY = tooltipPositionY - openTooltipHeight - 5;
        openTooltip.offset({top: tooltipPositionY});
    }

    if (pop_position_right > tooltipPositionX) {
        openTooltip.offset({left: tooltipPositionX});
    }
    else {
        openTooltip.offset({left: pop_position_right});
    }
    openTooltip.show();
    openTooltip.offset({top: tooltipPositionY, left: tooltipPositionX});
}

function showModal(className) {
    $('.open_modal').closest('.modalArea').hide();
    var modal = $('.' + className);
    var openModal = $('.open_modal' + className.replace('modal', '')).closest('.modalArea');
    overlay.abrir($('#overlayEdicao'));
    openModal.show();
}

function showModalResultado(className) {
    $('.open_modal').closest('.modalArea').hide();
    var modal = $('.' + className);
    var openModal = $('.open_modal' + className.replace('modal', '')).closest('.modalArea');
    overlay.abrir($('#overlayResultado'));
    openModal.show();
}

function inserirElemento(tipo, cl, content, placeholder) {
    if ($('#edicao').hasClass('ui-state-active') || loading) {

        var elemento = '';
        var conteudo = '';

        if (tipo == 'DIV') {
          tipo == cl;
        }

        if (!content) {
          conteudo = placeholder;
        }
        else {
          conteudo = content;
        }
        if (tipo == 'subtitulo1' || tipo == 'H2') {
          elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon-texto">h2</span></p><p>Subtítulo 1</p></div><div tabindex="0" contenteditable="true" class="subtitulo1 textarea elemento ui-sortable">' + conteudo + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
        }
        else if (tipo == 'subtitulo2' || tipo == 'H3') {
          elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon-texto">h3</span></p><p>Subtítulo 2</p></div><div tabindex="0" contenteditable="true" class="subtitulo2 textarea elemento ui-sortable">' + conteudo + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
        }
        else if (tipo == 'subtitulo3' || tipo == 'H4') {
          elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon-texto">h4</span></p><p>Subtítulo 3</p></div><div tabindex="0" contenteditable="true" class="subtitulo3 textarea elemento ui-sortable">' + conteudo + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
        }
        else if (tipo == 'titulo' || tipo == 'H1') {
          elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon-texto">h1</span></p><p>Título</p></div><div tabindex="0" contenteditable="true" class="titulo textarea elemento ui-sortable">' + conteudo + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
        }
        else if (tipo == 'paragrafo' || tipo == 'P') {
          elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + conteudo + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
        }
        else if (tipo == 'listaOrdenada' || tipo == 'OL') {
          elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon-texto"><span class="icon"><img src="img/icones/lista-ordenada.png" /></span></span></p><p>Lista<br /6>ordenada</p></div><div tabindex="0" contenteditable="true" class="listaOrdenada textarea elemento ui-sortable">' + conteudo + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
        }
        else if (tipo == 'lista' || tipo == 'UL') {
          elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon-texto"><span class="icon"><img src="img/icones/lista.png" /></span></span></p><p>Lista não ordenada</p></div><div tabindex="0" contenteditable="true" class="lista textarea elemento ui-sortable">' + conteudo + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
        }
        else if (tipo == 'botao' || (cl && cl.indexOf('botao') != -1)) {
          elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/botao.png" /></span></p><p>Botão</p></div><div tabindex="0" contenteditable="true" class="botao textarea elemento ui-sortable">' + conteudo + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
        }
        // else if (tipo == 'blockquote' || tipo == 'BLOCKQUOTE') {
        //   elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/citacao.png" /></span></p><p>Citação</p></div><div tabindex="0" contenteditable="true" class="blockquote textarea elemento ui-sortable">' + conteudo + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
        // }
        else if (tipo == 'blockquote' || (cl && cl.indexOf('blockquote') != -1)) {
            if (!content) {
                elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/citacao.png" /></span></p><p>Citação</p></div><div tabindex="0" class="blockquote elemento"><div tabindex="0" contenteditable="true" class="blockquoteText textarea elemento ui-sortable">' + objetos.blockquoteText.placeholder + '</div><div tabindex="0" contenteditable="true" class="blockquoteAuthor textarea elemento ui-sortable">' + objetos.blockquoteAuthor.placeholder + '</div></div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
            }
            else {
                elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/citacao.png" /></span></p><p>Citação</p></div><div tabindex="0" class="blockquote elemento"><div tabindex="0" contenteditable="true" class="blockquoteText textarea elemento ui-sortable">' + conteudo[0] + '</div><div tabindex="0" contenteditable="true" class="blockquoteAuthor textarea elemento ui-sortable">' + conteudo[1] + '</div></div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
            }
        }
        else if (tipo == 'abasElement' || (cl && cl.indexOf('abasElement') != -1)) {
            if (!content) {
                elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/abas.png" /></span></p><p>Abas</p></div><div class="area area2"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div><div class="abasElement elemento"><nav class="menuAbas"><li class="openaba1 active"><div class="removerAba"><i class="fa fa-times-circle" aria-hidden="true"></i> Remover aba</div><div class="abaTitleArea"><div tabindex="0" contenteditable="true" class="abaTitle textarea elemento ui-sortable">' + objetos.abaTitle.placeholder + '</div></div></li><li class="openaba2"><div class="removerAba"><i class="fa fa-times-circle" aria-hidden="true"></i> Remover aba</div><div class="abaTitleArea"><div tabindex="0" contenteditable="true" class="abaTitle textarea elemento ui-sortable">' + objetos.abaTitle.placeholder + '</div></div></li><li class="adicionarAba"><div><i class="fa fa-plus-circle" aria-hidden="true"></i> Adicionar aba</div></li></nav><div class="abaArea aba1 active"><div class="abaContent aceitaElementos"><div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.abas.paragrafo.placeholder + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div></div></div><div class="abaArea aba2"><div class="abaContent aceitaElementos"><div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.abas.paragrafo.placeholder + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div></div></div></div></div>';
            }
            else {

                var abas = '';
                var abasConteudo = '';

                for (var i = 0; i < content.length; i++) {
                    var index = i+1;
                    var abaAtual = content[i][0];
                    var abaAtualConteudo = content[i][1];

                    if (i == 0) {
                        abas = abas + '<li class="openaba' + index +' active"><div class="removerAba"><i class="fa fa-times-circle" aria-hidden="true"></i> Remover aba</div><div class="abaTitleArea"><div tabindex="0" contenteditable="true" class="abaTitle textarea elemento ui-sortable">' + abaAtual + '</div></div></li>'

                        abasConteudo = abasConteudo + '<div class="abaArea aba' + index + ' active"><div class="abaContent aceitaElementos">' + abaAtualConteudo.join('') + '</div></div>'
                    }
                    else {
                        abas = abas + '<li class="openaba' + index +'"><div class="removerAba"><i class="fa fa-times-circle" aria-hidden="true"></i> Remover aba</div><div class="abaTitleArea"><div tabindex="0" contenteditable="true" class="abaTitle textarea elemento ui-sortable">' + abaAtual + '</div></div></li>'

                        abasConteudo = abasConteudo + '<div class="abaArea aba' + index + '"><div class="abaContent aceitaElementos">' + abaAtualConteudo.join('') + '</div></div>'
                    }
                }

                elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/abas.png" /></span></p><p>Abas</p></div><div class="area area2"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div><div class="abasElement elemento"><nav class="menuAbas">' + abas + '<li class="adicionarAba"><div><i class="fa fa-plus-circle" aria-hidden="true"></i> Adicionar aba</div></li></nav>' + abasConteudo + '</div></div>';
            }
        }
        else if (tipo == 'videoLink' || (cl && cl.indexOf('embedContainer') != -1)) {
            if (!content) {
                elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon-texto"><span class="icon"><img src="img/icones/video-link.png" /></span></span></p><p>Vídeo (Youtube)</p></div><div class="embedContainer"><div tabindex="0" contenteditable="true" class="videoLink textarea elemento">&nbsp;<span contentEditable="false" class="sample">' + conteudo.replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</span></div><div tabindex="0" contenteditable="true" class="titulo textarea elemento">' + objetos.videoTitulo.placeholder + '</div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento">' + objetos.videoDescricao.placeholder + '</div></div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
            }
            else {
                elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon-texto"><span class="icon"><img src="img/icones/video-link.png" /></span></span></p><p>Vídeo (Youtube)</p></div><div class="embedContainer"><div tabindex="0" contenteditable="true" class="videoLink elemento textarea">' + conteudo[0].replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</div><div tabindex="0" contenteditable="true" class="titulo textarea elemento ui-sortable">' + conteudo[1] + '</div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + conteudo[2] + '</div></div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
            }
        }
        else if (tipo == 'video' || (cl && cl.indexOf('teste3') != -1)) {
          elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon-texto"><span class="icon"><img src="img/icones/video.png" /></span></span></p><p>Vídeo (Sambatech)</p></div><div class="video elemento"><div tabindex="0" contenteditable="true" class="video-duracao textarea">' + conteudo[0] + '</div><div tabindex="0" contenteditable="true" class="video-path textarea">' + conteudo[1] + '</div><div tabindex="0" contenteditable="true" class="video-id textarea">' + conteudo[2] + '</div></div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
        }
        else if (tipo == 'colunas' || (cl && cl.indexOf('colunas') != -1)) {
            if (!content) {
                var colunas = 2;
                if (colunas && parseInt(colunas) && colunas != 0) {
                    var linhas = '';
                    for (var i = 0; i < colunas; i++) {
                        linhas = linhas + '<div class="drag"><div class="removerBloco"><i class="fa fa-times-circle" aria-hidden="true"></i><br>Remover coluna</div><div class="coluna aceitaElementos elemento" tabindex="0"><div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.colunas.paragrafo.placeholder + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div></div></div>';
                    }
                    elemento = '<div class="drag drag2"><div class="descricaoObjeto mover"><p><span class="icon-texto"><span class="icon"><img src="img/icones/colunas.png" /></span></span></p><p>Colunas</p></div><div class="area area2"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div><div class="colunas aceitaElementos elemento" tabindex="0">' + linhas + '<ul class="control"><li class="adicionar"><span><i class="fa fa-plus-circle" aria-hidden="true"></i><br />Adicionar coluna</span></li></ul></div></div>';
                }
            }
            else {
                var colunas = conteudo.length;
                if (colunas && parseInt(colunas) && colunas != 0) {
                    var linhas = '';
                    for (var i = 0; i < colunas; i++) {
                        linhas = linhas + '<div class="drag"><div class="removerBloco"><i class="fa fa-times-circle" aria-hidden="true"></i><br>Remover coluna</div><div class="coluna aceitaElementos elemento" tabindex="0">' + (conteudo[i] != '' ? conteudo[i].join('') : ('<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.colunas.paragrafo.placeholder + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>')) +'</div></div>';
                    }
                    elemento = '<div class="drag drag2"><div class="descricaoObjeto mover"><p><span class="icon-texto"><span class="icon"><img src="img/icones/colunas.png" /></span></span></p><p>Colunas</p></div><div class="area area2"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div><div class="colunas elemento" tabindex="0">' + linhas + '<ul class="control"><li class="adicionar"><span><i class="fa fa-plus-circle" aria-hidden="true"></i><br />Adicionar coluna</span></li></ul></div></div>';
                }
            }
        }
        else if (tipo == 'coluna') {
          elemento = '<div class="drag"><div class="removerBloco"><i class="fa fa-times-circle" aria-hidden="true"></i><br>Remover coluna</div><div class="coluna aceitaElementos elemento" tabindex="0"><div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.colunas.paragrafo.placeholder + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div></div></div>';
        }
        else if (tipo == 'tabela' || tipo == 'TABLE') {
            if (!content) {
                var colunas = prompt('Insira o número de colunas');
                if (colunas && parseInt(colunas) && colunas != 0) {
                    var linhas = prompt('Insira o número de linhas');
                    if (linhas && parseInt(linhas) && linhas != 0) {
                        var tableLinha = '<tr class="noBorder"><td style="border:none"></td>';
                        for (var i = 0; i < colunas; i++) {
                           tableLinha = tableLinha + '<td class="removerColuna"><i class="fa fa-times-circle" aria-hidden="true"></i><br>Remover coluna</td>';
                        }
                        tableLinha = tableLinha + '</tr>'
                        for (var i = 0; i < linhas; i++) {
                            var tableColuna = '<td class="removerLinha"><i class="fa fa-times-circle" aria-hidden="true"></i><br>Remover linha</td>';
                            var colGroup = '<col />';
                            for (var j = 0; j < colunas; j++) {
                                colGroup = colGroup + '<col style="width:' + 100/colunas + '%" />'
                                if (i == 0) {
                                    tableColuna = tableColuna + '<th class="celula aceitaElementos elemento" tabindex="0">' + conteudo + '</th>';
                                }
                                else {
                                    tableColuna = tableColuna + '<td class="celula aceitaElementos elemento" tabindex="0">' + conteudo + '</td>';
                                }
                            }
                            colGroup = '<colgroup>' + colGroup + '</colgroup>';
                            if (i == 0) {
                                tableLinha = tableLinha + '<tr>' + tableColuna + '<td class="adicionarColuna" rowspan="' + linhas + '"><i class="fa fa-plus-circle" aria-hidden="true"></i> Adicionar coluna</td>' + '</tr>';
                            }
                            else {
                               tableLinha = tableLinha + '<tr>' + tableColuna + '</tr>';
                            }
                        }
                        tableLinha = tableLinha + '<tr class="noBorder"><td style="border:none"></td><td class="adicionarLinha" colspan="' + colunas + '"><i class="fa fa-plus-circle" aria-hidden="true"></i> Adicionar linha</td></tr>';
                        elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/tabela.png" /></span></p><p>Tabela</p></div><div class="area area2"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div><table>' + colGroup + tableLinha + '</table></div>';
                    }
                }
            }
            else {
                var colunas = content[0].length;
                var linhas = content.length;
                var tableLinha = '<tr class="noBorder"><td style="border:none"></td>';
                for (var i = 0; i < colunas; i++) {
                    tableLinha = tableLinha + '<td class="removerColuna"><i class="fa fa-times" aria-hidden="true"></i><br>Remover coluna</td>';
                }
                tableLinha = tableLinha + '</tr>'
                for (var i = 0; i < linhas; i++) {
                    var tableColuna = '<td class="removerLinha"><i class="fa fa-times" aria-hidden="true"></i><br>Remover linha</td>';
                    var colGroup = '<col />';
                    for (var j = 0; j < colunas; j++) {
                        colGroup = colGroup + '<col style="width:' + 100/colunas + '%" />'
                        if (i == 0) {
                            tableColuna = tableColuna + '<th class="celula aceitaElementos elemento" tabindex="0">' + conteudo[i][j].join('') + '</th>';
                        }
                        else {
                            tableColuna = tableColuna + '<td class="celula aceitaElementos elemento" tabindex="0">' + conteudo[i][j].join('') + '</td>';
                        }
                    }
                    colGroup = '<colgroup>' + colGroup + '</colgroup>';
                    if (i == 0) {
                        tableLinha = tableLinha + '<tr>' + tableColuna + '<td class="adicionarColuna" rowspan="' + linhas + '"><i class="fa fa-plus-circle" aria-hidden="true"></i> Adicionar coluna</td>' + '</tr>';
                    }
                    else {
                        tableLinha = tableLinha + '<tr>' + tableColuna + '</tr>';
                    }
                }
                tableLinha = tableLinha + '<tr class="noBorder"><td style="border:none"></td><td class="adicionarLinha" colspan="' + colunas + '"><i class="fa fa-plus-circle" aria-hidden="true"></i> Adicionar linha</td></tr>';
                elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/tabela.png" /></span></p><p>Tabela</p></div><div class="area area2"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div><table>' + colGroup + tableLinha + '</table></div>';
            }
        }
        else if (tipo == 'imagem' || tipo == 'IMG') {
          elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/imagem.png" /></span></p><p>Imagem</p></div><label class="input-label" for="input' + input + '">Selecionar imagem</label><input class="input-file" id="input' + input + '" accept=".jpg, .jpeg, .png" type="file" /><span class="file-base64 imagem elemento">' + (!content ? '' : conteudo) + '</span><span class="file-name"><span>' + (!content ? '' : '1 arquivos') + '</span><span class="file-eraser"><i class="fa fa-times-circle" aria-hidden="true"></i></span></span><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
          input++;
        }
        else if (tipo == 'imagemFundo' || (cl && cl.indexOf('imagemFundo') != -1)) {
            elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/imagem.png" /></span></p><p>Imagem de fundo</p></div><label class="input-label" for="input' + input + '">Selecionar imagem</label><input class="input-file" id="input' + input + '" accept=".jpg, .jpeg, .png" type="file" /><span class="file-base64 imagemFundo elemento">' + (!content ? '' : conteudo) + '</span><span class="file-name"><span>' + (!content ? '' : '1 arquivos') + '</span><span class="file-eraser"><i class="fa fa-times-circle" aria-hidden="true"></i></span></span></div>';
            input++;
        }
        else if (tipo == 'galeria' || (cl && cl.indexOf('galeriaImagens') != -1)) {
          elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/galeria.png" /></span></p><p>Galeria</p></div><label class="input-label" for="input' + input + '">Selecionar imagens</label><input class="input-file" multiple id="input' + input + '" accept=".jpg, .jpeg, .png" type="file" /><span class="file-base64 galeria elemento">' + (!content ? '' : conteudo) + '</span><span class="file-name"><span>' + (!content ? '' : '3 arquivos') + '</span><span class="file-eraser"><i class="fa fa-times-circle" aria-hidden="true"></i></span></span><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
          input++;
        }
        else if (tipo == 'audio' || (cl && cl.indexOf('audioPlayer') != -1)) {
          elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/audio.png" /></span></p><p>Áudio</p></div><label class="input-label" for="input' + input + '">Selecionar áudio</label><input class="input-file" id="input' + input + '" accept=".mp3" type="file" /><span class="file-base64 audio elemento">' + (!content ? '' : conteudo) + '</span><span class="file-name"><span class="file-eraser"><i class="fa fa-times-circle" aria-hidden="true"></i></span></span><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
          input++;
        }
        else if (tipo == 'slider' || (cl && cl.indexOf('slider') != -1)) {

            if (!content) {

                elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon-texto"><img src="img/icones/slider-de-texto.png" /></span></p><p>Slider de texto</p></div><div class="area area2"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div><div class="slider aceitaElementos elemento"><div class="galeriapersonalizadanav"><ul class="slick-nav"><li><a class="nav-item active" href="javascript:void(0)" data-slide="0">1</a></li><li><a class="addSlide" href="javascript:void(0)"><i class="fa fa-plus-circle" aria-hidden="true"></i></a></li><li><a class="removeSlide" href="javascript:void(0)"><i class="fa fa-times" aria-hidden="true"></i></a></li></ul></div><div class="sliderpersonalizado slick"><div class="slick_slide"><div class="descricaoObjeto"><p><span class="icon-texto"><img src="img/icones/slider-de-texto.png" /></span></p><p>Slide</p></div><div tabindex="0" class="slide aceitaElementos elemento"><div class="drag sortable-disable"><div class="descricaoObjeto"><p><span class="icon-texto">h1</span></p><p>Título</p></div><div tabindex="0" contenteditable="true" class="titulo textarea elemento ui-sortable">' + objetos.slider.titulo.placeholder + '</div></div><div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.slider.paragrafo.placeholder + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div></div></div></div></div></div>';
            }
            else {
                elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon-texto"><img src="img/icones/slider-de-texto.png" /></span></p><p>Slider de texto</p></div><div class="area area2"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div><div class="slider aceitaElementos elemento"><div class="galeriapersonalizadanav"><ul class="slick-nav">';

                var slides = '';
                var navigation = '';

                for (var i = 1; i < content.length; i++) {

                    var conteudoSlideAtual = content[i];
                    var slideAtual = '';

                    if (i == 0) {
                        navigation = navigation + '<li><a class="nav-item active" href="javascript:void(0)" data-slide="' + (i - 1) + '">' + i + '</a></li>'
                    }
                    else {
                        navigation = navigation + '<li><a class="nav-item" href="javascript:void(0)" data-slide="' + (i - 1) + '">' + i + '</a></li>'
                    }

                    for (var j = 0; j < conteudoSlideAtual.length; j++) {
                        slideAtual = slideAtual + conteudoSlideAtual[j];
                    }

                    slides = slides + '<div class="slick_slide"><div class="descricaoObjeto"><p><span class="icon-texto"><img src="img/icones/slider-de-texto.png" /></span></p><p>Slide</p></div><div tabindex="0" class="slide aceitaElementos elemento">' + slideAtual + '</div></div>';
                }

                elemento = elemento + navigation + '<li><a class="addSlide" href="javascript:void(0)"><i class="fa fa-plus-circle" aria-hidden="true"></i></a></li><li><a class="removeSlide" href="javascript:void(0)"><i class="fa fa-times" aria-hidden="true"></i></a></li></ul></div><div class="sliderpersonalizado slick">' + slides + '</div></div></div>';

            }
        }
        else if (tipo == 'flipcard' || (cl && cl.indexOf('flipcards') != -1)) {
            if (content) {
                var flipcontainers = '';

                for (var i = 0; i < conteudo.length; i++) {

                    var flipContainerAtual = conteudo[i];

                    if (flipContainerAtual[0].length == 2) {
                        var front = flipContainerAtual[0].reverse().join('');
                    }
                    else {
                        if (flipContainerAtual[0][0] && flipContainerAtual[0][0].indexOf('imagemFundo') == -1) {
                            var front = flipContainerAtual[0].join('') + inserirElemento('imagemFundo', false, false, placeholder);
                        }
                        else {
                            var front = inserirElemento('paragrafo', false, false, objetos['flipcard'].placeholder) + flipContainerAtual[0].join('');
                        }
                    }
                    var back = flipContainerAtual[1].reverse().join('');

                    flipcontainers = flipcontainers + '<div class="flip-container"><div class="removerFlip"><i class="fa fa-times-circle" aria-hidden="true"></i><br>Remover flipcard</div><div class="flip-info">Frente</div><div class="flip"><i class="fa fa-refresh" aria-hidden="true"></i></div><div class="flipper"><div class="front aceitaElementos elemento">' + front + '</div><div class="back aceitaElementos elemento">' + back + '</div></div></div>'
                }

                elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon-texto"><img src="img/icones/flipcard.png" /></span></p><p>Flipcard</p></div><div class="area area2"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div><div class="flipcards">' + flipcontainers +'</div><ul class="control"><li class="adicionar"><span><i class="fa fa-plus-circle" aria-hidden="true"></i><br />Adicionar flipcard</span></li></ul></div></div>';
            }
            else {
                var newInput = input;
                var newInput2 = input + 1;
                elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon-texto"><img src="img/icones/flipcard.png" /></span></p><p>Flipcard</p></div><div class="area area2"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div><div class="flipcards"><div class="flip-container"><div class="removerFlip"><i class="fa fa-times-circle" aria-hidden="true"></i><br>Remover flipcard</div><div class="flip-info">Frente</div><div class="flip"><i class="fa fa-refresh" aria-hidden="true"></i></div><div class="flipper"><div class="front aceitaElementos elemento"><div class="drag"><div class="descricaoObjeto"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.flipcard.paragrafo.placeholder + '</div></div><div class="drag"><div class="descricaoObjeto"><p><span class="icon"><img src="img/icones/imagem.png"></span></p><p>Imagem de fundo</p></div><label class="input-label" for="input' + newInput + '">Selecionar imagem</label><input class="input-file" id="input' + newInput + '" accept=".jpg, .jpeg, .png" type="file"><span class="file-base64 imagemFundo elemento ui-sortable"></span><span class="file-name"><span class="file-eraser"><i class="fa fa-times-circle" aria-hidden="true"></i></span></span></div></div><div class="back aceitaElementos elemento"><div class="drag"><div class="descricaoObjeto"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.flipcard.paragrafo.placeholder + '</div></div><div class="drag"><div class="descricaoObjeto"><p><span class="icon"><img src="img/icones/imagem.png"></span></p><p>Imagem de fundo</p></div><label class="input-label" for="input' + newInput2 + '">Selecionar imagem</label><input class="input-file" id="input' + newInput2 + '" accept=".jpg, .jpeg, .png" type="file"><span class="file-base64 imagemFundo elemento ui-sortable"></span><span class="file-name"><span class="file-eraser"><i class="fa fa-times-circle" aria-hidden="true"></i></span></span></div></div></div></div></div><ul class="control"><li class="adicionar"><span><i class="fa fa-plus-circle" aria-hidden="true"></i><br />Adicionar flipcard</span></li></ul></div></div></div>';
                input = input + 2;
            }
        }
        else if (tipo == 'flip') {

            if (content) {
            }
            else {

                var newInput = input;
                var newInput2 = input + 1;
                elemento = '<div class="flip-container"><div class="removerFlip"><i class="fa fa-times-circle" aria-hidden="true"></i><br>Remover flipcard</div><div class="flip-info">Frente</div><div class="flip"><i class="fa fa-refresh" aria-hidden="true"></i></div><div class="flipper"><div class="front aceitaElementos elemento"><div class="drag"><div class="descricaoObjeto"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.flipcard.paragrafo.placeholder + '</div></div><div class="drag"><div class="descricaoObjeto"><p><span class="icon"><img src="img/icones/imagem.png"></span></p><p>Imagem de fundo</p></div><label class="input-label" for="input' + newInput + '">Selecionar imagem</label><input class="input-file" id="input' + newInput + '" accept=".jpg, .jpeg, .png" type="file"><span class="file-base64 imagemFundo elemento ui-sortable"></span><span class="file-name"><span class="file-eraser"><i class="fa fa-times-circle" aria-hidden="true"></i></span></span></div></div><div class="back aceitaElementos elemento"><div class="drag"><div class="descricaoObjeto"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.flipcard.paragrafo.placeholder + '</div></div><div class="drag"><div class="descricaoObjeto"><p><span class="icon"><img src="img/icones/imagem.png"></span></p><p>Imagem de fundo</p></div><label class="input-label" for="input' + newInput2 + '">Selecionar imagem</label><input class="input-file" id="input' + newInput2 + '" accept=".jpg, .jpeg, .png" type="file"><span class="file-base64 imagemFundo elemento ui-sortable"></span><span class="file-name"><span class="file-eraser"><i class="fa fa-times-circle" aria-hidden="true"></i></span></span></div></div></div></div></div></div>';
                input = input + 2;

            }
        }
        else if (tipo == 'tooltip' || (cl && cl.indexOf('open_tooltip') != -1)) {
            if(!content) {

            elemento = '<div class="tooltipArea"><div class="descricaoObjeto"><p><span class="icon-texto"><i class="fa fa-window-restore" aria-hidden="true"></i></span></p><p>Tooltip</p></div><div class="area"><ul class="menu-area"><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div><div tabindex="0" class="open_tooltip open_tooltip' + tooltipNumber + ' aceitaElementos elemento"><div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.tooltipElement.paragrafo.placeholder + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div></div></div>';
            }
            else {
                tooltipNumber = cl.replace(/open_tooltip/g, '').replace('ui-sortable', '').replace(/\s/g, '');
            elemento = '<div class="tooltipArea"><div class="descricaoObjeto"><p><span class="icon-texto"><i class="fa fa-window-restore" aria-hidden="true"></i></span></p><p>Tooltip</p></div><div class="area"><ul class="menu-area"><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div><div tabindex="0" class="open_tooltip open_tooltip' + tooltipNumber + ' aceitaElementos elemento">' + content + '</div></div>';
            }
        }
        else if (tipo == 'modal' || (cl && cl.indexOf('open_modal') != -1)) {
            if(!content) {
            elemento = '<div class="modalArea"><div class="descricaoObjeto"><p><span class="icon-texto"><i class="fa fa-window-restore" aria-hidden="true"></i></span></p><p>Modal</p></div><div tabindex="0" class="open_modal open_modal' + modalNumber + ' aceitaElementos elemento"><div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.paragrafo.placeholder + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div></div><div class="area"><ul class="menu-area"><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
            }
            else {
                modalNumber = cl.replace(/open_modal/g, '').replace('ui-sortable', '').replace(/\s/g, '');
            elemento = '<div class="modalArea"><div class="descricaoObjeto"><p><span class="icon-texto"><i class="fa fa-window-restore" aria-hidden="true"></i></span></p><p>Modal</p></div><div tabindex="0" class="open_modal open_modal' + modalNumber + ' aceitaElementos elemento">' + content + '</div><div class="area"><ul class="menu-area"><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div>';
            }
        }
         else if (tipo == 'accordion' || (cl && cl.indexOf('accordion') != -1)) {
             if (!content) {
                 elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/accordion.png" /></span></p><p>Accordion</p></div><div class="area area2"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div><div class="accordion elemento"><div class="accordionTitle"><div class="accordionSelection"><div tabindex="0" contenteditable="true" class="titulo textarea elemento ui-sortable">' + objetos.accordion.titulo.placeholder +'</div><div class="accordionToggle accordionToggleOn"><i class="fa fa-minus-circle" aria-hidden="true"></i><i class="fa fa-chevron-circle-down" aria-hidden="true"></i></div></div><div class="removerAccordion"><i class="fa fa-times-circle" aria-hidden="true"></i> Remover item</div></div><div class="accordionArea elemento aceitaElementos" style="display: block"><div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.accordion.paragrafo.placeholder + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div></div><div class="accordionTitle"><div class="accordionSelection"><div tabindex="0" contenteditable="true" class="titulo textarea elemento ui-sortable">' + objetos.accordion.titulo.placeholder +'</div><div class="accordionToggle"><i class="fa fa-minus-circle" aria-hidden="true"></i><i class="fa fa-chevron-circle-down" aria-hidden="true"></i></div></div><div class="removerAccordion"><i class="fa fa-times-circle" aria-hidden="true"></i> Remover item</div></div><div class="accordionArea elemento aceitaElementos"><div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.accordion.paragrafo.placeholder + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div></div><div class="accordionTitle"><div class="accordionSelection"><div tabindex="0" contenteditable="true" class="titulo textarea elemento ui-sortable">' + objetos.accordion.titulo.placeholder +'</div><div class="accordionToggle"><i class="fa fa-minus-circle" aria-hidden="true"></i><i class="fa fa-chevron-circle-down" aria-hidden="true"></i></div></div><div class="removerAccordion"><i class="fa fa-times-circle" aria-hidden="true"></i> Remover item</div></div><div class="accordionArea elemento aceitaElementos"><div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.accordion.paragrafo.placeholder + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div></div><div class="adicionarAccordion"><i class="fa fa-plus-circle" aria-hidden="true"></i> Adicionar item</div></div></div>';
             }
             else {
                var accordions = '';
                for (var i = 0; i < content.length; i++) {
                    accordions = accordions + '<div class="accordionTitle"><div class="accordionSelection"><div tabindex="0" contenteditable="true" class="titulo textarea elemento ui-sortable">' + content[i][0] +'</div><div class="accordionToggle"><i class="fa fa-minus-circle" aria-hidden="true"></i><i class="fa fa-chevron-circle-down" aria-hidden="true"></i></div></div><div class="removerAccordion"><i class="fa fa-times-circle" aria-hidden="true"></i> Remover item</div></div><div class="accordionArea elemento aceitaElementos">' + content[i][1].join('') + '</div>';
                }

                elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/accordion.png" /></span></p><p>Accordion</p></div><div class="area area2"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div><div class="accordion elemento">' + accordions +  '<div class="adicionarAccordion"><i class="fa fa-plus-circle" aria-hidden="true"></i> Adicionar item</div></div></div>'
             }
         }
        else if (tipo == 'banner' || (cl && cl.indexOf('banner') != -1)) {
            if (!content) {
                elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/banner.png" /></span></p><p>Banner</p></div><div class="area area2"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div><div class="banner aceitaElementos elemento"><div class="drag"><div class="descricaoObjeto"><p><span class="icon-texto">h1</span></p><p>Título</p></div><div tabindex="0" contenteditable="true" class="titulo textarea elemento ui-sortable">' + objetos.banner.titulo.placeholder + '</div></div><div class="drag"><div class="descricaoObjeto"><p><span class="icon"><img src="img/icones/imagem.png"></span></p><p>Imagem de fundo</p></div><label class="input-label" for="input' + input + '">Selecionar imagem</label><input class="input-file" id="input' + input + '" accept=".jpg, .jpeg, .png" type="file"><span class="file-base64 imagemFundo elemento ui-sortable"></span><span class="file-name"><span></span><span class="file-eraser"><i class="fa fa-times-circle" aria-hidden="true"></i></span></span></div></div></div>';
                input++;
            }
            else {
                if (conteudo.length > 0) {

                    if (conteudo.length == 2) {
                        conteudo = conteudo.reverse().join('');
                    }
                    else {
                        if (conteudo[0].indexOf('imagemFundo') == -1) {
                            conteudo = conteudo + inserirElemento('imagemFundo', false, false, placeholder);
                        }
                        else {
                            conteudo = inserirElemento('titulo', false, false, objetos['banner'].placeholder) + conteudo[0].join('');
                        }
                    }

                    elemento = '<div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/banner.png" /></span></p><p>Banner</p></div><div class="area area2"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div><div class="banner aceitaElementos elemento">' + conteudo + '</div></div>';

                }
            }
        }
        return elemento;
    }
}

function updateResult() {
    $('#resultado').html('');
    players = {};
    videosConfig = [];
    $('.sliderpersonalizado').unslick();
    $('.galeriaImagens').unslick();

    $('#resultado').append('<header>' + $('header').html() + '</header><div class="header-menu"><ul class="nav nav-tabs"><li class="active"><a href="#abaTexto" data-toggle="tab">Texto-base</a></li><li><a href="#abaVideo" data-toggle="tab">Vídeo</a></li></ul></div>');


    var content = '';


    if ($('#edicaoView').find('#conteudo').length == 0) {
      content = content + '<div id="abaTexto" class="tab-pane active">' + aba1 + '</div>';
    }
    else {
      content = content + '<div id="abaTexto" class="tab-pane active">' + $('#conteudo').html() + '</div>'
    }

    if ($('#edicaoView').find('#conteudo2').length == 0) {
      content = content + '<div id="abaVideo" class="tab-pane">' + aba2 + '</div>';
    }
    else {
      content = content + '<div id="abaVideo" class="tab-pane">' + $('#conteudo2').html() + '</div>';
    }

    $('#resultado').append('<div class="tab-content"><div class="container">' + content + '</div></div>' + '<div id="overlayResultado" class="overlay">' + $('#overlayEdicao').html() + '</div>')


    $('#resultado').find('.files').remove();
    $('#resultado').find('.input-file').remove();
    $('#resultado').find('.file-name').remove();
    $('#resultado').find('.file-eraser').remove();
    $('#resultado').find('label').remove();
    $('#resultado').find('.area').remove();
    $('#resultado').find('.control').remove();
    $('#resultado').find('.descricaoObjeto').remove();
    $('#resultado').find('.sample').remove();
    $('#resultado').find('colgroup').remove();
    $('#resultado').find('.noBorder').remove();
    $('#resultado').find('.adicionarColuna').remove();
    $('#resultado').find('.removerColuna').remove();
    $('#resultado').find('.adicionarLinha').remove();
    $('#resultado').find('.removerLinha').remove();
    $('#resultado').find('.removerBloco').remove();
    $('#resultado').find('.addSlide').closest('li').remove();
    $('#resultado').find('.removeSlide').closest('li').remove();
    $('#resultado').find('.removerFlip').remove();
    $('#resultado').find('.flip-info').remove();
    $('#resultado').find('.removerAccordion').remove();
    $('#resultado').find('.adicionarAccordion').remove();
    $('#resultado').find('.removerAba').remove();
    $('#resultado').find('.adicionarAba').remove();

    $('#resultado').find('.accordionToggle').removeClass('accordionToggleOn');
    $('#resultado').find('.nav-item').removeClass('active');
    $('#resultado').find('.menuAbas').children().removeClass('active');
    $('#resultado').find('.abaArea').removeClass('active');
    $('#resultado').find('.flipper').removeClass('flipIt');

    $('#resultado').find('.galeriapersonalizadanav li:first-child a').addClass('active');
    $('#resultado').find('.menuAbas li:first-child').addClass('active');
    $('#resultado').find('.menuAbas li:first-child').addClass('active');
    $('#resultado').find('.abasElement').each(function(index, el) {
        $(this).find('.abaArea').eq(0).addClass('active');
    });

    while($('#resultado').find('.aceitaElementos').length != 0) {
        $('#resultado').find('.aceitaElementos').each(function() {
            $(this).replaceWith(showResultElement($(this), $(this).prop("tagName"), $(this).attr('class'), $(this).html()));
        });
    }

    $('#resultado').find('.elemento').each(function(index, el) {
        $(this).replaceWith(showResultElement($(this), $(this).prop("tagName"), $(this).attr('class'), $(this).html()));
    });

    $('#resultado').find('.elemento').each(function(index, el) {
        $(this).replaceWith(showResultElement($(this), $(this).prop("tagName"), $(this).attr('class'), $(this).html()));
    });

    while($('#resultado').find('.drag').length != 0) {
        $('#resultado').find('.drag').each(function(index, el) {
           el.outerHTML = el.innerHTML;
        });
    }

    $('#resultado').find('.coluna').each(function(index, el) {
        if (el.innerHTML == '' || el.innerHTML == '&nbsp;') {
            $(el).remove();
        }
    });

    $('#resultado').find('.colunas').each(function(index, el) {
        var tamanho = $(el).children('.coluna').length;
       $(el).children('.coluna').each(function(index, el) {
           $(el).css('width', ((100/tamanho) - 2) + '%');
       });
    });

    $('#resultado').find('.sliderpersonalizadoResultado').each(function(index, el) {
        var titulo = $(this).find('.slick_slide').eq(0).find('h1').eq(0).html();
        $(this).closest('.slider').find('.galeriapersonalizadanav').prepend('<h1>' + titulo + '</h1>');
    });

    if (layout == 'layout2') {

        $('#resultado').find('.container').children().each(function(index, el) {
            var qtdTelas = $(el).children('h1').length;
            var telasTitulos = [];

            $(el).children('h1').each(function(index, el) {
                telasTitulos.push(el.innerText);
            });

            var newString = '';
            var contH1 = 0;
            var contTooltip = 0;
            $(el).children().each(function(index, el) {
                if(el.nodeName == 'H1') {
                    if (contH1 == 0) {
                        newString = newString + '<div class="screen active" id="screen' + (contH1 + 1) +'"><h1 class="tituloSlider">' + el.innerHTML + '</h1>';
                    }
                    else {
                        newString = newString + '<a class="screenLink" href="#screen' + (contH1 + 1) + '">' + telasTitulos[contH1] + '</a></div><div class="screen" id="screen' + (contH1 + 1) +'">' + '<a class="screenLink" href="#screen' + (contH1) + '">' + telasTitulos[contH1 - 1] + '</a>' + el.outerHTML;
                    }
                    contH1++;
                }
                else if (el.nodeName == 'DIV' && el.classList.contains('tooltipArea') && contTooltip < 1) {
                    newString = newString + '</div>' + el.outerHTML;
                    $(el).html(newString);
                    contTooltip++;
                }
                else {
                    newString = newString + el.outerHTML;
                }
            });

            if (contTooltip != 1) {
                newString = newString + '</div>'
            }

            $(el).html(newString);
        });

        var menu = criarMenuScreen();
        $('#abaTexto').prepend(menu);

    }

    $('audio').on('loadedmetadata', function() {
        var duracao = segundosParaHTML($(this)[0].duration);
        $(this).prev('.audio_duration').html(duracao);
    });


    $('#resultado').find('.imagemFundo').each(function(index, el) {
        var parentNode = el.parentElement;
        var firstElement = $(parentNode).find('*:first')[0];
        $(parentNode).append(firstElement);
    });

    $('.sliderpersonalizado').slick({
       dots: false,
        arrows: false,
        draggable: false,
        speed: 500,
        accessibility: false,
        infinite: false,
        waitForAnimate: false,
        adaptiveHeight: true,
        zIndex: 1,
        touchMove: false,
        onInit: function() {
            if (!$(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).hasClass('aceitaElementos')) {
                $(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).addClass('aceitaElementos');
                $(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).addClass('elemento');
            }
            createSortables();
        }
    });

    $('.galeriaImagens').slick({
        dots: false,
        draggable: true,
        speed: 500,
        accessibility: false,
        touchMove: true,
        prevArrow:'<p class="arrow-left arrow"><img class="point point-left" src="img/arrow-left.png" alt="arrow" /></p>',
        nextArrow:'<p class="arrow-right arrow"><img class="point point-right" src="img/arrow-right.png" alt="arrow" /></p>',
        slidesToShow: 1,
        adaptiveHeight: true,
        onAfterChange: function(event, slick, currentSlide, nextSlide) {
            if ($(this)[0].$slideTrack.parents('.sliderpersonalizadoResultado').length == 1) {
                updateSlick($(this)[0].$slideTrack.parents('.sliderpersonalizadoResultado'));
            }
        }
    });

    $('.galeriaImagens').init(function() {
      $('.galeriaImagens').each(function() {
        var height = $(this).find('.slick-active').outerHeight();
        $(this).find('.slick-list').outerHeight(height);
      });
    });

    $('.sliderpersonalizadoResultado').slick({
        dots: false,
        infinite: false,
        arrows: false,
        draggable: false,
        speed: 500,
        accessibility: false,
        waitForAnimate: false,
        adaptiveHeight: true,
        touchMove: false,
        onAfterChange: function(event, slick, currentSlide, nextSlide) {
            $('.galeriaImagens').slickSetOption(null, null, true);
        }
    });

    videoInit();
}

function frameworkToResultado(htmlObject) {
    var string = '';
    var _htmlObject = $(htmlObject);

    _htmlObject.find('.files').remove();
    _htmlObject.find('.input-file').remove();
    _htmlObject.find('.file-name').remove();
    _htmlObject.find('.file-eraser').remove();
    _htmlObject.find('label').remove();
    _htmlObject.find('.area').remove();
    _htmlObject.find('.control').remove();
    _htmlObject.find('.descricaoObjeto').remove();
    _htmlObject.find('.sample').remove();
    _htmlObject.find('colgroup').remove();
    _htmlObject.find('.noBorder').remove();
    _htmlObject.find('.adicionarColuna').remove();
    _htmlObject.find('.removerColuna').remove();
    _htmlObject.find('.adicionarLinha').remove();
    _htmlObject.find('.removerLinha').remove();
    _htmlObject.find('.removerBloco').remove();
    _htmlObject.find('.addSlide').closest('li').remove();
    _htmlObject.find('.removeSlide').closest('li').remove();
    _htmlObject.find('.nav-item').removeClass('active');
    _htmlObject.find('.galeriapersonalizadanav li:first-child a').addClass('active');
    _htmlObject.find('.flipper').removeClass('flipIt');
    _htmlObject.find('.removerFlip').remove();
    _htmlObject.find('.flip-info').remove();
    _htmlObject.find('.removerAccordion').remove();
    _htmlObject.find('.adicionarAccordion').remove();
    _htmlObject.find('.accordionToggle').removeClass('accordionToggleOn');

    while(_htmlObject.find('.aceitaElementos').length != 0) {
        $('#resultado').find('.aceitaElementos').each(function() {
            $(this).replaceWith(showResultElement($(this), $(this).prop("tagName"), $(this).attr('class'), $(this).html()));
        });
    }

    _htmlObject.find('.elemento').each(function(index, el) {
        $(this).replaceWith(showResultElement($(this), $(this).prop("tagName"), $(this).attr('class'), $(this).html()));
    });

    _htmlObject.find('.elemento').each(function(index, el) {
        $(this).replaceWith(showResultElement($(this), $(this).prop("tagName"), $(this).attr('class'), $(this).html()));
    });

    _htmlObject.find('.coluna').each(function(index, el) {
        if (el.innerHTML == '' || el.innerHTML == '&nbsp;') {
            $(el).remove();
        }
    });

    _htmlObject.find('.colunas').each(function(index, el) {
        var tamanho = $(el).children('.coluna').length;
       $(el).children('.coluna').each(function(index, el) {
           $(el).css('width', ((100/tamanho) - 2) + '%');
       });
    });

    _htmlObject.find('.sliderpersonalizadoResultado').each(function(index, el) {
        var titulo = $(this).find('.slick_slide').eq(0).find('h1').eq(0).html();
        $(this).closest('.slider').find('.galeriapersonalizadanav').prepend('<h1>' + titulo + '</h1>');
    });

    _htmlObject.find('.imagemFundo').each(function(index, el) {
        var parentNode = el.parentElement;
        var firstElement = $(parentNode).find('*:first')[0];
        $(parentNode).append(firstElement);
    });

    _htmlObject.find('audio').each(function(index, el) {
        $(el).on('loadedmetadata', function() {
            var duracao = segundosParaHTML($(this)[0].duration);
            $(this).prev('.audio_duration').html(duracao);
        });
    });

    _htmlObject.each(function(index, el) {
        string = string + el.innerHTML;
    });

    return string;
}

function readFile(file, onLoadCallback){
    var reader = new FileReader();
    reader.onload = onLoadCallback;
    reader.readAsDataURL(file);
}

function segundosParaHTML(segundos) {
    var string = '';
    var teste = Math.floor(segundos);
    var minutos = Math.floor(teste / 60);
    var segundos = Math.floor(teste % 60);
    if (minutos < 10) {
        string = '0' + minutos + ':';
    }
    else {
        string = minutos + ':';
    }

    if (segundos < 10) {
        string = string + '0' + segundos;
    }
    else {
        string = string + segundos;
    }
    return string;
}

function HTMLParaSegundos(html) {
    var minutos = parseInt(html.substr(0,2));
    var segundos = parseInt(html.substr(3,2));

    var tempoTotal = minutos + segundos;
    return tempoTotal;
}

function readFileText(file, onLoadCallback){
    var reader = new FileReader();
    reader.onload = onLoadCallback;
    reader.readAsText(file, 'UTF-8');
}

function carregarElementos(node, elemento) {
    if (node == 'IMG') {
        elementConteudo = elemento[0].src;
    }
    else if (node == 'DIV' && elemento[0].classList.contains('imagemFundo')) {
        elementConteudo = elemento[0].style.backgroundImage.replace('url(', '');
        elementConteudo = elementConteudo.substr(0, elementConteudo.length - 1);
    }
    else if (node == 'DIV' && elemento[0].classList.contains('audioPlayer')) {
        elementConteudo = elemento.find('audio')[0].src;
    }
    else if (node == 'DIV' && elemento[0].classList.contains('galeriaImagens')) {
        elementConteudo = [];
        $(elemento).find('.slick_slide').each(function(index, el) {
            elementConteudo.push($(el).find('*:first')[0].src);
        });
        elementConteudo = elementConteudo.join('');
    }
    else if (node == 'TABLE') {
        var elementConteudo = [];
          elemento.find('tr').each(function(index, el) {
            var linhaAtual = [];

            $(el).children().each(function(index, el) {
              var celulaAtual = [];

              $(el).children().each(function(index, el) {
                var elementoAtual = $(el);

                celulaAtual.push(carregarElementos(elementoAtual[0].nodeName, elementoAtual));

              });

              linhaAtual.push(celulaAtual);
            });

            elementConteudo.push(linhaAtual);
          });
    }
    else if (node == 'DIV' && elemento[0].classList.contains('colunas')) {
        elementConteudo = [];
        elemento.find('.coluna').each(function(index, el) {
            var linhaAtual = [];
            $(el).children().each(function(index, el) {
                var elementoAtual = $(el);
                linhaAtual.push(carregarElementos(elementoAtual[0].nodeName, elementoAtual));
              });
              elementConteudo.push(linhaAtual);
        });
    }
    else if (node == 'DIV' && elemento[0].classList.contains('teste3')) {
        elementConteudo = [];
        var duracao = elemento.attr('alt');
        var id = elemento.find('iframe')[0].name;
        var path = elemento.find('iframe')[0].src;
        path = path.slice((path.indexOf('/embed/') + 7), (path.indexOf(id) - 1));
        elementConteudo.push(duracao);
        elementConteudo.push(path);
        elementConteudo.push(id);
    }
    else if (node == 'DIV' && elemento[0].classList.contains('embedContainer')) {
        elementConteudo = [];

        elemento.children().each(function(index, el) {
           if (index == 0) {
            elementConteudo.push($(el).find('iframe')[0].outerHTML);
           }
           else {
            elementConteudo.push(el.innerHTML);
           }
        });
    }
    else if (node == 'DIV' && elemento[0].classList.contains('blockquote')) {
        elementConteudo = ['',''];

        elemento.children().each(function(index, el) {
            if ($(el).hasClass('blockquoteText')) {
                elementConteudo[0] = $(el).html();
            }
            else if ($(el).hasClass('blockquoteAuthor')) {
                elementConteudo[1] = $(el).html();
            }
        });
    }
    else if (node == 'DIV' && elemento[0].classList.contains('flipcards')) {
        elementConteudo = [];

        elemento.find('.flip-container').each(function(index, el) {
            var flipConteudo = [[],[]];

            var elementoAtual = $(el);

            elementoAtual.find('.front').children('.flip-content').children().each(function(index, el) {
                var elementoAtual = $(el);
                flipConteudo[0].push(carregarElementos(elementoAtual[0].nodeName, elementoAtual));
            });

            elementoAtual.find('.back').children('.flip-content').children().each(function(index, el) {
                var elementoAtual = $(el);
                flipConteudo[1].push(carregarElementos(elementoAtual[0].nodeName, elementoAtual));
            });

            elementConteudo.push(flipConteudo);
        });
    }
    else if (node == 'DIV' && elemento[0].classList.contains('banner')) {
        elementConteudo = [];

        elemento.children().each(function(index, el) {
            var elementoAtual = $(el);
            elementConteudo.push(carregarElementos(elementoAtual[0].nodeName, elementoAtual));
        });
    }
    else if (node == 'DIV' && elemento[0].classList.contains('accordion')) {
        elementConteudo = [];
        var linhaAtual = [];
        var contentAtual = [];

        elemento.children().each(function(index, el) {
            var elementoAtual = $(el);
            if (elementoAtual.hasClass('accordionTitle')) {
                linhaAtual = [];
                linhaAtual.push(elementoAtual.find('h1').eq(0).html());
            }
            else if (elementoAtual.hasClass('accordionArea')) {
                contentAtual = [];
                $(el).children().each(function(index, el) {
                    contentAtual.push(carregarElementos($(el)[0].nodeName, $(el)));
                });
                linhaAtual.push(contentAtual);
                elementConteudo.push(linhaAtual);
            }
        });
    }
    else if (node == 'DIV' && elemento[0].classList.contains('slider')) {
        elementConteudo = [];

        elementConteudo.push(elemento.find('.galeriapersonalizadanav').find('h1').eq(0).html());
        elemento.find('.sliderpersonalizadoResultado').children().each(function(index, el) {
            var linhaAtual = [];
            $(this).children().each(function(index, el) {
                var elementoAtual = $(this);
                linhaAtual.push(carregarElementos(elementoAtual[0].nodeName, elementoAtual));
              });
              elementConteudo.push(linhaAtual);
        });
    }
    else if (node == 'DIV' && elemento[0].classList.contains('open_modal')) {
        elementConteudo = [];
        elemento.children().each(function(index, el) {
            var elementoAtual = $(el);
            elementConteudo.push(carregarElementos(elementoAtual[0].nodeName, elementoAtual));
        });
    }
    else if (node == 'DIV' && elemento[0].classList.contains('open_tooltip')) {
        elementConteudo = [];
        elemento.children().each(function(index, el) {
            var elementoAtual = $(el);
            elementConteudo.push(carregarElementos(elementoAtual[0].nodeName, elementoAtual));
        });
    }
    else if (node == 'DIV' && elemento[0].classList.contains('abasElement')) {
        elementConteudo = [];
        elemento.find('.abaTitle').each(function(index, el) {
            var linhaConteudo = [];
            var conteudo = [];
            linhaConteudo[0] = el.innerHTML;
            elemento.find('.abaArea').eq(index).find('.abaContent').children().each(function(index, el) {
                conteudo.push(carregarElementos(el.nodeName, $(el)));
            });
            linhaConteudo[1] = conteudo;
            elementConteudo.push(linhaConteudo);
        });
    }
    else {
        elementConteudo = elemento[0].innerHTML;
    }
    return inserirElemento(elemento[0].nodeName, elemento[0].className, elementConteudo, false);
}

function fixSlide() {
    $('.slide').each(function(index, el) {
        if (!$(this).hasClass('elemento')) {
            $(this).addClass('aceitaElementos');
            $(this).addClass('elemento');
        }
    });
}

function progressionBarScreens() {
    var contador = 0;
    var total = $('.screenMenuItem').length;
    $('.screenMenuItem').each(function(index, el) {
        if($(this).hasClass('complete')) {
            contador++;
        }
    });

    var barraCompleta = ((100 * contador) / total);

    $('.completeBar').width(barraCompleta + '%');
}

function navegarParaScreen(href) {

    if (!$('#resultado').hasClass('scrolling')) {

        if (!$('.screenMenuItemLink[href="' + href + '"]').closest('.screenMenuItem').hasClass('active')) {
            if (!$('.screenMenuItemLink[href="' + href + '"]').closest('.screenMenuItem').hasClass('complete')) {
                $('.screenMenuItemLink[href="' + href + '"]').closest('.screenMenuItem').addClass('incomplete');
            }

            $('#resultado').addClass('scrolling');
            $('.screenMenuItem').removeClass('active');
            $('.screenMenuItemLink[href="' + href + '"]').closest('.screenMenuItem').addClass('active');

            var id = href.replace('#', '');
            var scrollAntigo = 0;

            if($('#desktop').hasClass('active')) {
                scrollAntigo = $(window).scrollTop()
            }
            else {
                scrollAntigo = $('#resultado').scrollTop()
            }

            if ($('.screenLink[href="' + href + '"]')) {
                var scrollAntigoClicado = $('.screenLink[href="' + href + '"]').offset().top;
            }

            $('#' + id).addClass('active');
            $('#' + id).children('*:not(h1)').css('opacity', 0);
            $('h1').removeClass('tituloSlider');

            var alturaElementoNovo = $('#' + id).outerHeight();

            if($('#desktop').hasClass('active')) {
                if (scrollAntigoClicado < 100) {
                    $('html, body').scrollTop(scrollAntigo + alturaElementoNovo);
                }

                $('html, body').animate({scrollTop: $('#' + id).children('h1').eq(0).offset().top - 80}, 800, function() {
                    $('.screen:not(#' + id +')').removeClass('active');
                    $('#' + id).children('h1').addClass('tituloSlider');
                    $('#' + id).children('*:not(h1)').css('opacity', 1);
                    $('#resultado').removeClass('scrolling');
                });
            }
            else {
                if (scrollAntigoClicado < 300) {
                    $('#resultado').scrollTop(scrollAntigo + alturaElementoNovo);
                }
                $('#resultado').animate({scrollTop: $('#' + id).children('h1').eq(0).offset().top + $('#resultado').scrollTop() - $('#resultado').offset().top - 40}, 800, function() {
                    $('.screen:not(#' + id +')').removeClass('active');
                    $('#' + id).children('h1').addClass('tituloSlider');
                    $('#' + id).children('*:not(h1)').css('opacity', 1);
                    $('#resultado').removeClass('scrolling');
                });
            }

            $('.sliderpersonalizadoResultado').each(function(index, el) {
                updateSlick($(this));
            });
        }

    }
}

function criarMenuScreen() {
    var telasTitulos = [];
    var menu = '';
    $('#resultado').find('.screen').each(function(index, el) {
        telasTitulos.push($(el).find('h1').eq(0).html());
    });
    for (var i = 0; i < telasTitulos.length; i++) {
        menu = menu + '<li class="screenMenuItem ' + (i == 0 ? 'incomplete active' : '') + '"><i class="fa fa-align-left" aria-hidden="true"></i><a class="screenMenuItemLink" href="#screen' + (i + 1) + '">' + telasTitulos[i] + '</a><div class="status"><div class="block"></div><div class="hold left"><div class="fill"></div></div><div class="hold right"><div class="fill"></div></div></div></li>';
    }

    var header = $('#resultado').find('header').html();

    return '<div class="menuScreen"><a class="toggleMenu hideMenu"><span class="tracos"><span class="traco traco1"></span><span class="traco traco2"></span><span class="traco traco3"></span></span></a><header>' + header + '</header><div class="progressionBar"><div class="completeBar"></div></div><nav><ul>' + menu + '</ul></nav></div>';
}

String.prototype.replaceAll = function(search, replace) {
    if (replace === undefined) {
        return this.toString();
    }
    return this.split(search).join(replace);
}

$(window).scroll(function() {
    //TORNAR MENU FIXO
 if ($(this).scrollTop() > 80){
    $('.menuTopo').addClass("menuTopo-scroll");
  }
  else{
    $('.menuTopo').removeClass("menuTopo-scroll");
  }

  // COMPLETAR SCREEN
  var scroll = $(window).scrollTop();
  var janela = $(window).height();
  var documento = $(document).height();

  if (!$('#resultado').hasClass('scrolling') && (!$('#resultado').hasClass('resultado-tablet') || !$('#resultado').hasClass('resultado-mobile'))) {
    if (scroll + janela + 100 >= documento) {
        $('.screenMenuItem.active').removeClass('incomplete');
        $('.screenMenuItem.active').addClass('complete');
        progressionBarScreens();
    }
  }
});

// EVENTOS DOS ELEMENTOS CRIADOS DINAMICAMENTE

$(document).on('mousedown', '.textarea', function(evt) {
    if ($(evt.target).find('.sample').length > 0) {
        evt.target.innerHTML = '';
    }
    if (evt.target.innerHTML != '') {
        setCaret(evt.target, 0);
    }
});

$(document).on('focus', '.textarea', function(evt) {
    if ($(evt.target).find('.sample').length > 0) {
        $(evt.target).find('.sample').remove();
        evt.target.innerHTML = '';
    }
    $(evt.target).prev('.descricaoObjeto').addClass('objetoAtivo');
});

$(document).on('input', '.textarea', function(evt) {
    if ($(evt.target).find('.sample').length != 0) {
        $(evt.target).find('.sample').remove();
        evt.target.innerHTML = evt.originalEvent.data;
        setCaret(evt.target, 1);
    }
    var teste = evt.target.outerHTML;
    if (getCaretPosition(evt.target) != 0) {
        caretPosition = getCaretPosition(evt.target);
    }
    if ($(teste).find('font').length > 0) {
        evt.target.innerHTML = evt.target.innerText;
        if (evt.target.innerHTML.length == caretPosition + 1) {
            setCaret(evt.target, caretPosition + 1);
        }
        else {
            setCaret(evt.target, caretPosition);
        }
    }
});

document.addEventListener('paste', function (evt) {
    evt.preventDefault();
    // if ($(evt.target).find('.sample').length >= 0) {
    //     evt.target.innerHTML = '';
    // }
    var text = evt.clipboardData.getData("text/plain");
    document.execCommand("insertText", false, text);
});

$(document).on('click', '.duplicar', function(evt) {

    var abaActive = getActiveView();
    var view = '#' + abaActive;

    var element = $(evt.target).closest('.drag')[0].outerHTML;
    element = element.replace(/input(\d+)/g, function(match, p1, p2, p3, offset, strin) {
      return 'input'+input;
    });

    element = element.replace(/tooltip(\d+)/g, function(match, p1, p2, p3, offset, string) {
        var number = parseInt(match.replace('tooltip', ''));
        if (number != 0) {
            var content = $('.open_tooltip'+number)[0].innerHTML;
            tooltipNumber++;
            var node2 = '<div class="tooltipArea"><div class="area"><ul class="menu-area"><li>tooltip</li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div><div tabindex="0" class="open_tooltip open_tooltip' + tooltipNumber + ' aceitaElementos elemento">' + content + '</div></div>';
            $(view).append(node2);
            $('.tooltipArea').hide();
            return 'tooltip'+tooltipNumber;
        }
    });

    element = element.replace(/modal(\d+)/g, function(match, p1, p2, p3, offset, string) {
        var number = parseInt(match.replace('modal', ''));
        if (number != 0) {
            var content = $('.open_modal'+number)[0].innerHTML;
            modalNumber++;
            var node2 = inserirElemento('modal', "open_modal" + modalNumber + "", content, null);
            $('#overlayEdicao').append(node2);
            return 'modal'+modalNumber;
        }
    });

    var novoConteudo = '';

    $(element).find('.slick_slide').each(function() {
        novoConteudo = novoConteudo + '<div class="slick_slide">' + $(this)[0].innerHTML + '</div>';
    });

    var finalElement = $(element);
    $(finalElement).find('.slick').html(novoConteudo);
    $(finalElement).find('.slick').removeClass('slick-initialized').removeClass('slick-slider');

    if ($(evt.target).closest('.drag').closest('.elemento').hasClass('colunas')){
        if ($(evt.target).closest('.drag').closest('.elemento').find('> .drag').length < 6) {
            finalElement.insertAfter($(evt.target).closest('.drag'));
        }
    }
    else {
        finalElement.insertAfter($(evt.target).closest('.drag'));
    }

    finalElement.find('.slick').slick({
       dots: false,
        arrows: false,
        draggable: false,
        speed: 500,
        accessibility: false,
        infinite: false,
        waitForAnimate: false,
        adaptiveHeight: true,
        touchMove: false,
        onInit: function() {
            if (!$(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).hasClass('aceitaElementos')) {
                $(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).addClass('aceitaElementos');
                $(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).addClass('elemento');
            }
        }
    });

    $('.sliderpersonalizado').each(function(index, el) {
        updateSlick($(this));
    });

    createSortables();
});

$(document).on('click', '.addSlide', function(evt) {

    var index = $(evt.target).closest('li').closest('ul').children().length - 1;
    var dataSlide = $(evt.target).closest('li').closest('ul').children().length - 2;

    $(evt.target).closest('li').closest('.slick-nav').find('a').each(function() {
        $(this).removeClass('active');
    });
    $('<li><a class="nav-item active" href="javascript:void(0)" data-slide="' + dataSlide + '">' + index + '</a></li>').insertBefore($(evt.target).closest('li'));


    $(evt.target).closest('.galeriapersonalizadanav').next('.slick').slickAdd('<div class="slick_slide"><div class="descricaoObjeto"><p><span class="icon-texto"><img src="img/icones/slider-de-texto.png" /></span></p><p>Slide</p></div><div tabindex="0" class="slide aceitaElementos elemento"><div class="drag sortable-disable"><div class="descricaoObjeto"><p><span class="icon-texto">h1</span></p><p>Título</p></div><div tabindex="0" contenteditable="true" class="titulo textarea elemento ui-sortable">' + objetos.slider.titulo.placeholder + '</div></div><div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.slider.paragrafo.placeholder + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div></div></div>');

    $(evt.target).closest('.galeriapersonalizadanav').next('.slick').slickGoTo(dataSlide);

    $(evt.target).closest('.galeriapersonalizadanav').next('.sliderpersonalizado').find('.slide').each(function() {
        if (!$(this).closest('.slick_slide').hasClass('slick-active')) {
            $(this).removeClass('aceitaElementos');
            $(this).removeClass('elemento');
        }
    });

    createSortables();
});

$(document).on('click', '.removeSlide', function(evt) {

    if ($(evt.target).closest('ul').find('.nav-item').length == 1) {
        // DO NOTHING
    }

    else {
        var dataSlideTotal = $(evt.target).closest('ul').find('.nav-item').length - 1;
        var dataSlideActive = $(evt.target).closest('ul').find('.active');
        var dataSlide = dataSlideActive.attr('data-slide');


        $(evt.target).closest('ul').closest('.galeriapersonalizadanav').next('.slick').slickRemove(dataSlide);
        dataSlideActive.closest('li').remove();

        $(evt.target).closest('ul').find('.nav-item').each(function(index, el) {
            $(el).attr('data-slide', index);
            $(el).text(index + 1);
        });
        if (dataSlide == dataSlideTotal) {
            $(evt.target).closest('ul').find('.nav-item').eq(dataSlide-1).addClass('active');
            $(evt.target).closest('ul').closest('.galeriapersonalizadanav').next('.slick').slickGoTo(dataSlide-1);
            $(evt.target).closest('.slick-nav').closest('.galeriapersonalizadanav').next('.sliderpersonalizado').find('.slick-slide').eq(dataSlide-1).find('.slide').addClass('aceitaElementos');
            $(evt.target).closest('.slick-nav').closest('.galeriapersonalizadanav').next('.sliderpersonalizado').find('.slick-slide').eq(dataSlide-1).find('.slide').addClass('elemento');
        }
        else {
            $(evt.target).closest('ul').find('.nav-item').eq(dataSlide).addClass('active');
            $(evt.target).closest('ul').closest('.galeriapersonalizadanav').next('.slick').slickGoTo(dataSlide);
            $(evt.target).closest('.slick-nav').closest('.galeriapersonalizadanav').next('.sliderpersonalizado').find('.slick-slide').eq(dataSlide).find('.slide').addClass('aceitaElementos');
            $(evt.target).closest('.slick-nav').closest('.galeriapersonalizadanav').next('.sliderpersonalizado').find('.slick-slide').eq(dataSlide).find('.slide').addClass('elemento');
        }

        createSortables();
    }
});

$(document).on('click', '.nav-item', function(evt) {
    updateSlickSlide(evt.target);
});

$(document).on('click', '.adicionarColuna', function(evt) {

    var table = $(evt.target).closest('table');
    var colgroup = table.find('colgroup');

    colgroup.append('<col />');

    colgroup.find('col').each(function(index, elemento) {
        if (index != 0) {
            $(elemento).css('width', (100 / (colgroup.find('col').length - 1)) + "%");
        }
    });

    table.find('tr').each(function(index, elemento) {

        if (index == 0) {
            $(elemento).append('<td class="removerColuna"><i class="fa fa-times-circle" aria-hidden="true"></i><br>Remover coluna</td>');
        }
        else if (index == 1) {
            $('<th class="celula aceitaElementos elemento" tabindex="0"><div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.tabela.paragrafo.placeholder + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></th>').insertBefore($(elemento).find('td:last-child'));
        }
        else if (index == table.find('tr').length - 1) {
            var colspanAtual = $(elemento).find('td:last-child').prop("colSpan");
            $(elemento).find('td:last-child').prop('colspan', colspanAtual + 1);
        }
        else {
            $(elemento).append('<td class="celula aceitaElementos elemento" tabindex="0"><div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.tabela.paragrafo.placeholder + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></td>')
        }

    });

    createSortables();
});

$(document).on('click', '.removerColuna', function(evt) {

    var table = $(evt.target).closest('tr').closest('table');
    var colgroup = table.find('colgroup');
    if (colgroup.children().length > 3) {

        colgroup.find('col:last-child').remove();

        colgroup.find('col').each(function(index, elemento) {
            if (index != 0) {
                $(elemento).css('width', (100 / (colgroup.find('col').length - 1)) + "%");
            }
        });

        var indexTirar = $('td').index(this);

        table.find('tr').each(function(index, elemento) {

            if (index == 0) {
                $(elemento).find('td:nth-child(' + (indexTirar + 1) + ')').remove();
            }
            else if (index == 1) {
                $(elemento).find('th:nth-child(' + (indexTirar + 1) + ')').remove();
            }
            else if (index == table.find('tr').length - 1) {
                var colspanAtual = table.find('.adicionarLinha').prop("colSpan");
                table.find('.adicionarLinha').prop("colSpan", colspanAtual - 1);
            }
            else {
                $(elemento).find('td:nth-child(' + (indexTirar + 1) + ')').remove();
            }

        });
    }
});

$(document).on('click', '.adicionarLinha', function(evt) {
    var rowspanAtual = $(evt.target).closest('tr').closest('table').find('.adicionarColuna').prop('rowSpan');
    $(evt.target).closest('tr').closest('table').find('.adicionarColuna').prop('rowSpan', rowspanAtual + 1);

    var newLine = '<tr><td class="removerLinha"><i class="fa fa-times-circle" aria-hidden="true"></i><br>Remover linha</td>';

    for (var i = 0; i < $(evt.target).closest('tr').prev('tr').find('.celula').length; i++) {
        newLine = newLine + '<td class="celula aceitaElementos elemento" tabindex="0"><div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.tabela.paragrafo.placeholder + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></td>'
    }

    newLine = newLine + '</tr>';

    $(newLine).insertBefore($(evt.target).closest('tr').closest('table').find('tr:last'));

    // $(evt.target).closest('tr').prev('tr').clone(true).insertBefore($(evt.target).closest('tr').closest('table').find('tr:last'));

    createSortables();
});

$(document).on('click', '.removerLinha', function(evt) {

    if ($(evt.target).closest('tr').closest('table').find('tr').length > 4) {

        var rowspanAtual = $(evt.target).closest('tr').closest('table').find('.adicionarColuna').prop('rowSpan');
        $(evt.target).closest('tr').closest('table').find('.adicionarColuna').prop('rowSpan', rowspanAtual - 1);

        $(evt.target).closest('tr').remove();

    }
});

$(document).on('click', '.removerBloco', function(evt) {
    if ($(evt.target).closest('.colunas').children('.drag').length > 2) {

        $(evt.target).closest('.drag').remove();

    }
});

$(document).on('click', '.removerFlip', function(evt) {
    if ($(evt.target).closest('.flip-container').closest('.drag').find('.flip-container').length > 1) {

        $(evt.target).closest('.flip-container').remove();

    }
});

$(document).on('click', '.adicionar', function(evt) {
    if ($(evt.target).closest('.elemento').hasClass('colunas')) {
        if ($(evt.target).closest('.elemento').find('> .drag').length < 6) {
            $(inserirElemento('coluna', false, false, objetos.colunas.placeholder)).insertAfter($(evt.target).closest('ul').prev('.drag'));
        }
    }
    else if ($(evt.target).closest('ul').prev().hasClass('flipcards')) {
        if ($(evt.target).closest('ul').prev().find('.flip-container').length < 5) {
            $(evt.target).closest('ul').prev().append(inserirElemento('flip', false, false, false));
        }
    }

    createSortables();
});

$(document).on('click', '.remover', function(evt) {
    // RETIRA O ELEMENTO
    if ($(evt.target).closest('.elemento').hasClass('colunas')) {
        if ($(evt.target).closest('.elemento').find('> .drag').length > 2) {
            if ($(evt.target).closest('ul').hasClass('control')) {
                $(evt.target).closest('ul').prev('.drag').remove();
            }
            else if ($(evt.target).closest('ul').hasClass('menu-area')) {
                $(evt.target).closest('ul').closest('.drag').remove();
            }
        }
    }
    else if ($(evt.target).closest('.elemento').hasClass('slide')) {
        var slick = $(evt.target).closest('.elemento').closest('.sliderpersonalizado');
        $(evt.target).closest('ul').closest('.drag').remove();
        updateSlick(slick);
    }
    else {
        $(evt.target).closest('ul').closest('.drag').remove();
    }

    if ($(evt.target).closest('ul').closest('.tooltipArea').length > 0) {
        $(evt.target).closest('ul').closest('.tooltipArea').remove();
        var tooltipNumber = $(evt.target).closest('ul').closest('.tooltipArea').find('.open_tooltip')[0].className.replace(/\D/g, '');

        if ($('.tooltip' + tooltipNumber)[0].nodeName == 'SPAN') {
            var tooltipText = $('.tooltip' + tooltipNumber).html()
            $('.tooltip' + tooltipNumber).replaceWith(tooltipText);
        }
        else {
            var tooltip = $('.tooltip' + tooltipNumber);
            tooltip.prev('.area').find('.tooltip').remove();
            tooltip.removeClass('tooltip' + tooltipNumber);
        }
    }
    if ($(evt.target).closest('ul').closest('.modalArea').length > 0) {
        $(evt.target).closest('ul').closest('.modalArea').remove();
        var modalNumber = $(evt.target).closest('ul').closest('.modalArea').find('.open_modal')[0].className.replace(/\D/g, '');

        if ($('.modal' + modalNumber)[0].nodeName == 'SPAN') {
            var tooltipText = $('.modal' + modalNumber).html()
            $('.modal' + modalNumber).replaceWith(tooltipText);
        }
        else {
            var modal = $('.modal' + modalNumber);
            modal.prev('.area').find('.modal').remove();
            modal.removeClass('modal' + modalNumber);
        }
        overlay.fechar();
    }
});

$(document).on('click', '.flip', function(evt) {
    if ($(evt.target).hasClass('fa')) {
        $(evt.target).closest('div').next('.flipper').toggleClass('flipIt');

        if ($(evt.target).closest('div').prev('.flip-info').html() == 'Frente') {
            $(evt.target).closest('div').prev('.flip-info').html('Verso');
        }
        else {
            $(evt.target).closest('div').prev('.flip-info').html('Frente');
        }
    }
    else {
        $(evt.target).next('.flipper').toggleClass('flipIt');

        if ($(evt.target).prev('.flip-info').html() == 'Frente') {
            $(evt.target).prev('.flip-info').html('Verso');
        }
        else {
            $(evt.target).prev('.flip-info').html('Frente');
        }
    }
});

$(document).on('click', '.front', function(evt) {
    if (!$(this).hasClass('elemento')) {
        $(this).closest('.flipper').toggleClass('flipIt');
    }
});

$(document).on('click', '.back', function(evt) {
    if (!$(this).hasClass('elemento')) {
        $(this).closest('.flipper').toggleClass('flipIt');
    }
});

$(document).on('blur', '.textarea', function(evt) {
    if (evt.target.innerHTML == '&nbsp;' || evt.target.innerHTML == '' || evt.target.innerHTML == '<br>' || evt.target.innerHTML == '<br>') {
        var tipo = '';
        if ($(evt.target).closest('.elemento').hasClass('numeroCapitulo')) {
          tipo = 'numeroCapitulo';
        }
        else if ($(evt.target).closest('.elemento').hasClass('nomeCapitulo')) {
          tipo = 'nomeCapitulo';
        }
         else if ($(evt.target).closest('.elemento').hasClass('disciplinaCapitulo')) {
          tipo = 'disciplinaCapitulo';
        }
        else if ($(evt.target).closest('.elemento').hasClass('titulo')) {
            tipo = 'titulo';
        }
        else if ($(evt.target).closest('.elemento').hasClass('subtitulo1')) {
            tipo = 'subtitulo1';
        }
        else if ($(evt.target).closest('.elemento').hasClass('subtitulo2')) {
            tipo = 'subtitulo2';
        }
        else if ($(evt.target).closest('.elemento').hasClass('subtitulo3')) {
            tipo = 'subtitulo3';
        }
        else if ($(evt.target).closest('.elemento').hasClass('paragrafo')) {
            tipo = 'paragrafo';
        }
        else if ($(evt.target).closest('.elemento').hasClass('listaOrdenada')) {
            tipo = 'listaOrdenada';
        }
        else if ($(evt.target).closest('.elemento').hasClass('lista')) {
            tipo = 'lista';
        }
        else if ($(evt.target).closest('.elemento').hasClass('blockquoteText')) {
            tipo = 'blockquoteText';
        }
        else if ($(evt.target).closest('.elemento').hasClass('blockquoteAuthor')) {
            tipo = 'blockquoteAuthor';
        }
        else if ($(evt.target).closest('.elemento').hasClass('video-duracao')) {
          tipo = 'videoDuracao';
        }
        else if ($(evt.target).closest('.elemento').hasClass('video-path')) {
          tipo = 'videoPath';
        }
        else if ($(evt.target).closest('.elemento').hasClass('video-id')) {
          tipo = 'videoId';
        }
        else if ($(evt.target).hasClass('video-duracao')) {
          tipo = 'videoDuracao';
        }
        else if ($(evt.target).hasClass('video-path')) {
          tipo = 'videoPath';
        }
        else if ($(evt.target).hasClass('video-id')) {
          tipo = 'videoId';
        }
        else if ($(evt.target).hasClass('abaTitle')) {
          tipo = 'abaTitle';
        }

        evt.target.innerHTML = '';

        if ($(evt.target).closest('.elemento').closest('.aceitaElementos').hasClass('celula')) {
            $(evt.target).append(objetos['tabela'][tipo].placeholder);
        }
        else if ($(evt.target).closest('.elemento').closest('.aceitaElementos').hasClass('coluna')) {
          $(evt.target).append(objetos['colunas'][tipo].placeholder);
        }
        else if ($(evt.target).closest('.elemento').closest('.aceitaElementos').hasClass('accordionArea')) {
          $(evt.target).append(objetos['accordion'][tipo].placeholder);
        }
        else if ($(evt.target).closest('.elemento').closest('.aceitaElementos').hasClass('abaContent')) {
          $(evt.target).append(objetos['abas'][tipo].placeholder);
        }
        else if ($(evt.target).closest('.elemento').closest('.aceitaElementos').hasClass('slide')) {
          $(evt.target).append(objetos['slider'][tipo].placeholder);
        }
        else if ($(evt.target).closest('.elemento').closest('.aceitaElementos').hasClass('open_tooltip')) {
          $(evt.target).append(objetos['tooltipElement'][tipo].placeholder);
        }
        else if ($(evt.target).closest('.elemento').closest('.aceitaElementos').hasClass('front') || $(evt.target).closest('.elemento').closest('.aceitaElementos').hasClass('back')) {
          $(evt.target).append(objetos['flipcard'][tipo].placeholder);
        }
        else if ($(evt.target).closest('.elemento').closest('.aceitaElementos').hasClass('banner')) {
          $(evt.target).append(objetos['banner'][tipo].placeholder);
        }
        else if ($(evt.target).closest('.elemento').closest('.embedContainer').length > 0) {
            if (tipo == 'videoLink') {
                $(evt.target).append('&nbsp;<span contentEditable="false" class="sample">' + objetos['videoLink'].placeholder + '</span>');
            }
            else if (tipo == 'titulo') {
                $(evt.target).append(objetos['videoTitulo'].placeholder);
            }
            else {
                $(evt.target).append(objetos['videoDescricao'].placeholder);
            }
        }
        else {
            if (objetos[tipo]) {
                $(evt.target).append(objetos[tipo].placeholder);
            }
        }

    }
    $(evt.target).prev('.descricaoObjeto').removeClass('objetoAtivo');
});

$(document).on('click', '.tooltip', function(evt) {

    if (evt.target.classList.contains('tooltip') || evt.target.parentNode.classList.contains('tooltip')) {
        if (evt.target.nodeName == 'SPAN') {
            var className = evt.target.className.replace('tooltip ', '');

            if ($('#edicao').hasClass('ui-tabs-active')) {
                showTooltip(className);
            }
            else {
                showTooltipResultado(className);
            }

        }
        else if (evt.target.nodeName == 'I') {
            var className = $(evt.target).closest('.area').next('.elemento').attr('class').split(' ').filter(function(value) {
                if (value.indexOf('tooltip') != -1) {
                    return value;
                }
            });

            if ($('#edicao').hasClass('ui-tabs-active')) {
                showTooltip(className[0]);
            }
            else {
                showTooltipResultado(className[0]);
            }

        }
    }
});

$(document).on('click', '.modal', function(evt) {
    if (evt.target.classList.contains('modal') || evt.target.parentNode.classList.contains('modal')) {
        if (evt.target.nodeName == 'SPAN') {
            var className = evt.target.className.replace('modal ', '');
            if ($('#edicao').hasClass('ui-tabs-active')) {
                showModal(className);
            }
            else {
                showModalResultado(className);
            }
        }
        else if (evt.target.nodeName == 'I') {
            var className = $(evt.target).closest('.area').next('.elemento').attr('class').split(' ').filter(function(value) {
                if (value.indexOf('modal') != -1) {
                    return value;
                }
            });
            if ($('#edicao').hasClass('ui-tabs-active')) {
                showModal(className[0]);
            }
            else {
                showModalResultado(className[0]);
            }
        }
    }
});

$(document).on('click', '.screenLink', function(evt) {
    evt.preventDefault();
    evt.stopPropagation();

    navegarParaScreen($(evt.target).attr('href'));

    return false;
});

$(document).on('click', '.screenMenuItem', function(evt) {
    evt.preventDefault();
    evt.stopPropagation();

    navegarParaScreen($(this).find('a').attr('href'));

    return false;
});

$(document).on('click', '.closeModal', function(evt) {
    $('audio').each(function(index, el) {
       el.pause();
    });
    overlay.fechar();
    $('.modalArea').hide();
});

$(document).on('change', '.input-file', function(evt) {
    var finalText = '';
    var finalResult = [];

    for (var i = 0, cont = 0; i < evt.target.files.length; i++) {

        if ($(this).closest('.drag').find('.elemento').hasClass('imagem') || $(this).closest('.drag').find('.elemento').hasClass('imagemFundo') || $(this).closest('.drag').find('.elemento').hasClass('galeria')) {
            var imageCompressor = new ImageCompressor();
            imageCompressor.compress(evt.target.files[i], {quality: 0.4})
              .then((result) => {

                readFile(result, function(e) {
                    finalResult.push(e.target.result);
                    $(evt.target).siblings('.file-base64').html(finalResult);

                    if ($(evt.target).siblings('.file-base64').hasClass('imagem') || $(evt.target).siblings('.file-base64').hasClass('imagemFundo')) {
                        $('#overlayPreview').find('.conteudo').html(showResultElement(false, false, 'imagem', finalResult.join('')));
                    }
                    else if ($(evt.target).siblings('.file-base64').hasClass('galeria')) {
                        $('#overlayPreview').find('.conteudo').html(showResultElement(false, false, $(evt.target).siblings('.file-base64').attr('class'), finalResult.join('')));
                    }

                    overlay.abrir($('#overlayPreview'));

                    $('.galeriaImagens').slick({
                        dots: false,
                        draggable: true,
                        speed: 500,
                        accessibility: false,
                        touchMove: true,
                        prevArrow:'<p class="arrow-left arrow"><img class="point point-left" src="img/arrow-left.png" alt="arrow" /></p>',
                        nextArrow:'<p class="arrow-right arrow"><img class="point point-right" src="img/arrow-right.png" alt="arrow" /></p>',
                        slidesToShow: 1,
                        adaptiveHeight: true
                    });
                });


              })
              .catch((err) => {
              });
        }
        else if ($(this).closest('.drag').find('.elemento').hasClass('audio')) {
            readFile(evt.target.files[i], function(e) {
                finalResult.push(e.target.result);
                $(evt.target).siblings('.file-base64').html(finalResult);

                if ($(evt.target).siblings('.file-base64').hasClass('audio')) {
                    $('#overlayPreview').find('.conteudo').html(showResultElement(false, false, $(evt.target).siblings('.file-base64').attr('class'), finalResult.join('')));

                    $('audio').on('loadedmetadata', function() {
                        var duracao = segundosParaHTML($(this)[0].duration);
                        $(this).prev('.audio_duration').html(duracao);
                    });
                }
                overlay.abrir($('#overlayPreview'));
            });

        }

        // readFile(evt.target.files[i], function(e) {
        //     finalResult.push(e.target.result);
        //     $(evt.target).siblings('.file-base64').html(finalResult);

        //     if ($(evt.target).siblings('.file-base64').hasClass('imagem') || $(evt.target).siblings('.file-base64').hasClass('imagemFundo')) {
        //         $('#overlayPreview').find('.conteudo').html(showResultElement(false, false, 'imagem', finalResult.join('')));
        //     }
        //     else if ($(evt.target).siblings('.file-base64').hasClass('galeria') || $(evt.target).siblings('.file-base64').hasClass('audio')) {
        //         $('#overlayPreview').find('.conteudo').html(showResultElement(false, false, $(evt.target).siblings('.file-base64').attr('class'), finalResult.join('')));

        //         $('audio').on('loadedmetadata', function() {
        //             var duracao = segundosParaHTML($(this)[0].duration);
        //             $(this).prev('.audio_duration').html(duracao);
        //         });
        //     }

        //     overlay.abrir($('#overlayPreview'));

        //     $('.galeriaImagens').slick({
        //         dots: false,
        //         draggable: true,
        //         speed: 500,
        //         accessibility: false,
        //         touchMove: true,
        //         prevArrow:'<p class="arrow-left arrow"><img class="point point-left" src="img/arrow-left.png" alt="arrow" /></p>',
        //         nextArrow:'<p class="arrow-right arrow"><img class="point point-right" src="img/arrow-right.png" alt="arrow" /></p>',
        //         slidesToShow: 1,
        //         adaptiveHeight: true
        //     });
        // });

      var nome = evt.target.files[i].name;
      finalText =  finalText + nome + '\r\n';

      cont++;
    }
    $(evt.target).prev('label').attr('title', finalText);

    if ($(evt.target).siblings('.file-name').find('span').length > 1 && cont != 0) {
        $(evt.target).siblings('.file-name').find('span').eq(0).remove();
    }

    if (cont != 0) {

        $(evt.target).siblings('.file-name').prepend('<span>' + cont + ' arquivos</span>');
        $(evt.target).siblings('.file-name').css('display', 'inline-block');
        $(evt.target).siblings('.file-name').find('.file-eraser').css('display', 'inline-block');

    }
});

$(document).on('click', '.file-eraser', function(evt) {

    $(this).closest('.file-name').prev('.file-base64').html('');
    $(this).closest('.file-name').find('span').eq(0).remove();
    $(this).closest('.file-name').css('display', 'none');
});

document.onmousedown = function(e) {
    if (!$(e.target).hasClass('tooltip') && $(e.target).closest('.tooltipArea').length == 0) {
        $('#resultado').find('.tooltipArea').each(function(index, el) {
         $(this).hide();
        });
    }

    if ($(e.target).attr('class') && $(e.target).parent().attr('class') && $(e.target).attr('class').indexOf('tooltip') == -1 && $(e.target).closest('.tooltipArea').length == 0 && $(e.target).attr('class').indexOf('inserirElemento') == -1 && $(e.target).parent().attr('class').indexOf('inserirElemento') == -1 && $(e.target).attr('class').indexOf('inserirEstilo') == -1 && $(e.target).parent().attr('class').indexOf('inserirEstilo') == -1 ) {
        $('.tooltipArea').hide();
    }
}

// COMPLETAR SCREEN
$('#resultado').on('scroll', function(event) {
    var scroll = $(this).scrollTop();
  var janela = $(this).height();
  var documento = $(this).find('#abaTexto').height();

  if (scroll + janela + 50 >= documento) {
        $('.screenMenuItem.active').removeClass('incomplete');
        $('.screenMenuItem.active').addClass('complete');
        progressionBarScreens();
   }
});

$('.inserirElemento').on('click', function() {

    // if ($('#edicao').hasClass('ui-tabs-active')) {

        var tipo = $(this).attr('class').replace(/inserirElemento/g, '').replace(/ui-draggable-handle/g, '').replace(/ui-draggable/g, '').replace(/\s/g, '');
        var placeholder;
        var element;
        if (objetos[tipo]) {
          placeholder = objetos[tipo].placeholder;
        }
        var abaActive = getActiveView();
        var view = '';

        if(overlay.status == 'aberto') {
            view = '#overlayEdicao .modalArea:visible .open_modal'
        }
        else {
            view = '#' + abaActive;
        }
         if (tipo.indexOf('subtitulo1') != -1) {
          elemento = inserirElemento('subtitulo1', false, false, placeholder);
          $(view).append(elemento);
         }
         else if (tipo.indexOf('subtitulo2') != -1) {
          elemento = inserirElemento('subtitulo2', false, false, placeholder);
          $(view).append(elemento);
         }
         else if (tipo.indexOf('subtitulo3') != -1) {
          elemento = inserirElemento('subtitulo3', false, false, placeholder);
          $(view).append(elemento);
         }
         else if (tipo.indexOf('titulo') != -1) {
          elemento = inserirElemento('titulo', false, false, placeholder);
          $(view).append(elemento);
         }
         else if (tipo.indexOf('paragrafo') != -1) {
          elemento = inserirElemento('paragrafo', false, false, placeholder);
          $(view).append(elemento);
         }
         else if (tipo.indexOf('listaOrdenada') != -1) {
          elemento = inserirElemento('listaOrdenada', false, false, placeholder);
          $(view).append(elemento);
         }
         else if (tipo.indexOf('lista') != -1) {
          elemento = inserirElemento('lista', false, false, placeholder);
          $(view).append(elemento);
         }
         else if (tipo.indexOf('botao') != -1) {
          elemento = inserirElemento('botao', false, false, placeholder);
          $(view).append(elemento);
         }
         else if (tipo.indexOf('blockquote') != -1) {
          elemento = inserirElemento('blockquote', false, false, placeholder);
          $(view).append(elemento);
         }
         else if (tipo.indexOf('videoLink') != -1) {
          elemento = inserirElemento('videoLink', false, false, placeholder);
          $(view).append(elemento);
         }
         else if (tipo.indexOf('video') != -1) {
          elemento = inserirElemento('video', false, false, placeholder);
          $(view).append(elemento);
         }
         else if (tipo.indexOf('tabela') != -1) {
          elemento = inserirElemento('tabela', false, false, placeholder);
          $(view).append(elemento);
         }
         else if (tipo.indexOf('accordion') != -1) {
          elemento = inserirElemento('accordion', false, false, placeholder);
          $(view).append(elemento);
         }
         else if (tipo.indexOf('abasElement') != -1) {
          elemento = inserirElemento('abasElement', false, false, placeholder);
          $(view).append(elemento);
         }
         else if (tipo.indexOf('imagem') != -1) {
          elemento = inserirElemento('imagem', false, false, placeholder);
          $(view).append(elemento);
         }
         else if ((tipo.indexOf('galeria') != -1)) {
          elemento = inserirElemento('galeria', false, false, placeholder);
          $(view).append(elemento);
         }
         else if (tipo.indexOf('audio') != -1) {
          elemento = inserirElemento('audio', false, false, placeholder);
          $(view).append(elemento);
         }
         else if (tipo.indexOf('colunas') != -1) {
          elemento = inserirElemento('colunas', false, false, placeholder);
          $(view).append(elemento);
         }
         else if (tipo.indexOf('slider') != -1) {
          elemento = inserirElemento('slider', false, false, placeholder);
          $(view).append(elemento);
          $(view).find('.sliderpersonalizado').each(function() {
            if(!$(this).hasClass('slick-initialized')) {
                $(this).slick({
                    dots: false,
                    arrows: false,
                    draggable: false,
                    speed: 500,
                    accessibility: false,
                    infinite: false,
                    adaptiveHeight: true,
                    zIndex: 1,
                    touchMove: false,
                    onInit: function() {
                        if (!$(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).hasClass('aceitaElementos')) {
                    $(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).addClass('aceitaElementos');
                    $(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).addClass('elemento');
                }
                    }
                });
            }
          });
         }
         else if (tipo.indexOf('flipcard') != -1) {
          elemento = inserirElemento('flipcard', false, false, placeholder);
          $(view).append(elemento);
         }
         else if (tipo.indexOf('banner') != -1) {
            elemento = inserirElemento('banner', false, false, placeholder);
            $(view).append(elemento);
         }

        createSortables();
    // }
});

function resetFont(){
    $("font[size=1]").removeAttr("size").css("font-size", '0.8' + "em");
  }

$('.inserirEstilo').on('click', function() {

    var tipo = $(this).attr('class').replace(/inserirElemento/g, '').replace(/ui-draggable-handle/g, '').replace(/ui-draggable/g, '').replace(/\s/g, '');
    var placeholder;
    if (objetos[tipo]) {
        placeholder = objetos[tipo].placeholder;
    }

    var view = getActiveView();
    var tipo = $(this).attr('class').replace(/inserirEstilo/g, '');

    if (tipo.indexOf('negrito') != -1) {
        document.execCommand('bold');
    }
    else if (tipo.indexOf('italico') != -1) {
        document.execCommand('italic');
    }
    else if (tipo.indexOf('small') != -1) {
        var content = getSelectionText();

         if (content) {
            tooltipNumber++;
            var node = '<small>' + content + '</small>&nbsp;';
            document.execCommand('insertHtml', false, node);
         }
    }
    else if (tipo.indexOf('underline') != -1) {
        document.execCommand('underline');
    }
    else if (tipo.indexOf('indent') != -1) {
        var content = getSelectionText();

        if (content) {
            content = content.replace(/\n/g, '</li><li>');

            var result = '<li>' + content + '</li>';

            if (window.getSelection) {
                sel = window.getSelection();
                if (sel.rangeCount) {
                    range = sel.getRangeAt(0);
                    range.deleteContents();
                    var newNode = range.createContextualFragment('<ul>' + result + '</ul>')
                    range.insertNode(newNode);
                }
            }

        }
    }
    else if (tipo.indexOf('link') != -1) {
        var val = prompt('Insira o link');
        if (val != '' && val.indexOf('www') != -1) {
            document.execCommand('createLink', false, val);
        }
        else {
            alert('link invalido');
        }
    }
    else if (tipo.indexOf('sobrescrito') != -1) {
        document.execCommand('superscript');
    }
    else if (tipo.indexOf('subscrito') != -1) {
        document.execCommand('subscript');
    }
    else if (tipo.indexOf('tooltipElement') != -1) {
         var content = getSelectionText();

         if (content) {
            tooltipNumber++;
            var node = '<span contenteditable="true" class="tooltip tooltip' + tooltipNumber + '">' + content + '</span>&nbsp;';
            var node2 = inserirElemento('tooltip', false, false, placeholder);
            var className = 'tooltip' + tooltipNumber;

            document.execCommand('insertHtml', false, node);
            $('#' + view +'').append(node2);
            showTooltip(className);
         }
         createSortables();
    }
    else if (tipo.indexOf('modalElement') != -1) {
         var content = getSelectionText();

         if (content) {
            modalNumber++;
            var node = '<span contenteditable="true" class="modal modal' + modalNumber + '">' + content + '</span>&nbsp;';
            var node2 = inserirElemento('modal', false, false, placeholder);
            var className = 'modal' + modalNumber;

            document.execCommand('insertHtml', false, node);
            $('#overlayEdicao').append(node2);
            showModal(className);
         }
         createSortables();
     }
});

$('#conteudo, #conteudo2').sortable({
    handle: ".mover",
    cancel: ".remover",
    placeholder: "sortable-placeholder",
    forcePlaceholderSize: true,
    forceHelperSize: true,
    tolerance: "pointer",
    stop: function(e,ui) {
        stopSortable(e,ui);
    }
});

$('.inserirElemento').each(function(index, el) {
    if ($(el).hasClass('titulo') || $(el).hasClass('subtitulo1') || $(el).hasClass('subtitulo2') || $(el).hasClass('subtitulo3') || $(el).hasClass('botao') || $(el).hasClass('subtitulo2') || $(el).hasClass('paragrafo') || $(el).hasClass('blockquote') || $(el).hasClass('lista') || $(el).hasClass('listaOrdenada') || $(el).hasClass('imagem') || $(el).hasClass('galeria') || $(el).hasClass('audio')) {
        $(el).draggable({
            connectToSortable: ".aceitaElementos",
            helper: 'clone',
            refreshPositions: true,
            scroll: false,
            distance: 10,
            cursorAt: { left: 0, top: 0 },
            start:function(event, ui) {

                $('.sliderpersonalizado').each(function(index, el) {
                    var slick = $(el);
                    updateSlick(slick);
                });
                ui.helper.addClass('sendoArrastado');
                $('#conteudo').sortable('refreshPositions');
                $('#conteudo2').sortable('refreshPositions');
            }
        });
    }
    else if ($(el).hasClass('tabela') || $(el).hasClass('banner') || $(el).hasClass('flipcard') || $(el).hasClass('slider') || $(el).hasClass('accordion')) {
        $(el).draggable({
            connectToSortable: "#conteudo, #conteudo2",
            helper: 'clone',
            refreshPositions: true,
            scroll: false,
            distance: 10,
            cursorAt: { left: 0, top: 0 },
            start:function(event, ui) {

                $('.sliderpersonalizado').each(function(index, el) {
                    var slick = $(el);
                    updateSlick(slick);
                });
                ui.helper.addClass('sendoArrastado');
                $('#conteudo').sortable('refreshPositions');
                $('#conteudo2').sortable('refreshPositions');
            }
        });
    }
    else if ($(el).hasClass('colunas')) {
        $(el).draggable({
            connectToSortable: "#conteudo, #conteudo2, .slide, .accordionArea",
            helper: 'clone',
            refreshPositions: true,
            scroll: false,
            distance: 10,
            cursorAt: { left: 0, top: 0 },
            start:function(event, ui) {

                $('.sliderpersonalizado').each(function(index, el) {
                    var slick = $(el);
                    updateSlick(slick);
                });
                ui.helper.addClass('sendoArrastado');
                $('#conteudo').sortable('refreshPositions');
                $('#conteudo2').sortable('refreshPositions');
            }
        });
    }
    else if ($(el).hasClass('video') || $(el).hasClass('videoLink') || $(el).hasClass('accordionArea')) {
        $(el).draggable({
            connectToSortable: "#conteudo, #conteudo2, .coluna, .slide, .accordionArea",
            helper: 'clone',
            refreshPositions: true,
            scroll: false,
            distance: 10,
            cursorAt: { left: 0, top: 0 },
            start:function(event, ui) {

                $('.sliderpersonalizado').each(function(index, el) {
                    var slick = $(el);
                    updateSlick(slick);
                });
                ui.helper.addClass('sendoArrastado');
                $('#conteudo').sortable('refreshPositions');
                $('#conteudo2').sortable('refreshPositions');
            }
        });
    }
});

$('#exportar').on('click', function() {
  $('.sliderpersonalizadoResultado').unslick();
  $('.galeriaImagens').unslick();

  $('.screen').removeClass('active');
  $('h1').removeClass('tituloSlider');
  $('.menuAbas').children('li').removeClass('active');
  $('.abaArea').removeClass('active');
  $('#resultado').find('.screen').eq(0).addClass('active');
  $('#resultado').find('.screen').eq(0).find('h1').eq(0).addClass('tituloSlider');
  $('.menuAbas li:first-child').addClass('active');
  $('#resultado').find('.abasElement').each(function(index, el) {
      $(el).find('.abaArea').eq(0).addClass('active');
  });

  $('.playhead').css('margin-left', '0px');
  $('.timeline_completed').css('width', '0px');
  $('.flipper').removeClass('flipIt');
  $('.nav-item').removeClass('active');

  $('.slick-nav').each(function(index, el) {
    $(el).find('.nav-item').eq(0).addClass('active');
  });

  $('.audio_duration').each(function(index, el) {
    $(el).html(segundosParaHTML($(el).next('audio')[0].duration));
  });

  $('.menuScreen').removeClass('menuScreenResponsive');
  $('.toggleMenu').removeClass('showMenu');
  $('.toggleMenu').addClass('hideMenu');

  $('#resultado').find('.screenMenuItem').each(function(index, el) {

    $(el).removeClass('active');
    $(el).removeClass('complete');
    $(el).removeClass('incomplete');

    if (index == 0) {
        $(el).addClass('active');
        $(el).addClass('incomplete');
    }
  });

  var tempo = $('#resultado')[0].innerHTML;

  var cursoNomeCapitulo = $('.menuScreen').find('header').find('h3').html();
  var cursoNomeDisciplina = $('.menuScreen').find('header').find('h1').html() + ' | ' + $('.menuScreen').find('header').find('h4').html();

    finalString = '<!doctype html><html lang="en"><head><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta charset="UTF-8"><title>Material</title><link href="https://fonts.googleapis.com/css?family=Bitter" rel="stylesheet"><link href="https://fonts.googleapis.com/css?family=Bitter|Lato" rel="stylesheet"><link rel="stylesheet" href="css/font-awesome.min.css"><link href="css/bootstrap.min.css" rel="stylesheet"><link rel="stylesheet" href="css/slick.css"><link href="css/' + layout + '_estrutura_pagina.css" rel="stylesheet"><link href="css/' + layout + '_estrutura_elementos.css" rel="stylesheet"><link rel="stylesheet" href="css/' + layout + '_estilo_' + editorial +'.css"><script src="js/APIWrapper.js"></script><script src="js/SCOFunctions.js"></script></head><body onunload="return unloadPage()">' + tempo + '<script src="js/main-videos.js"></script><script src="js/jquery-3.2.1.min.js"></script><script src="js/bootstrap.min.js"></script><script src="js/slick.min.js"></script><script src="js/main.js"></script><script src="js/main-audio.js"></script><script type="text/javascript" samba-player-api="player" src="https://player.sambatech.com.br/v3/samba.player.api.js"></script> <script type="text/javascript"> var videosConfig = ' + JSON.stringify(videosConfig) + '</script><script>loadPage();</script></body></html>';

    var manifest = '<?xml version="1.0" standalone="no" ?><manifest identifier="com.scorm.golfsamples.runtime.basicruntime.12" version="1" xmlns="http://www.imsproject.org/xsd/imscp_rootv1p1p2" xmlns:adlcp="http://www.adlnet.org/xsd/adlcp_rootv1p2" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.imsproject.org/xsd/imscp_rootv1p1p2 imscp_rootv1p1p2.xsd http://www.imsglobal.org/xsd/imsmd_rootv1p2p1 imsmd_rootv1p2p1.xsd http://www.adlnet.org/xsd/adlcp_rootv1p2 adlcp_rootv1p2.xsd"><metadata><schema>ADL SCORM</schema><schemaversion>1.2</schemaversion></metadata><organizations default="GEN"><organization identifier="GEN"><title>' + cursoNomeCapitulo + '</title><item identifier="cap_item" identifierref="cap_resource" isvisible="true"><title>' + cursoNomeDisciplina + '</title></item></organization></organizations><resources><resource identifier="cap_resource" type="webcontent" adlcp:scormtype="sco" href="material.html"><file href="material.html"/><dependency identifierref="common_files" /></resource><resource identifier="commom_files" type="webcontent" adlcp:scormtype="asset"><file href="img/arrow-left.png"></file><file href="img/arrow-right.png"></file><file href="img/bg-box-top-juridico.jpg"></file><file href="img/correto.png"></file><file href="css/bootstrap.min.css"></file><file href="css/font-awesome.min.css"></file><file href="css/layout1_estilo_juridico.css"></file><file href="css/layout1_estrutura_elementos.css"></file><file href="css/layout1_estrutura_pagina.css"></file><file href="css/layout2_estilo_juridico.css"></file><file href="css/layout2_estrutura_elementos.css"></file><file href="css/layout2_estrutura_pagina.css"></file><file href="css/slick.css"></file><file href="js/APIWrapper.js"></file><file href="js/bootstrap.min.js"></file><file href="js/image-compressor.min.js"></file><file href="js/jquery-3.2.1.min.js"></file><file href="js/main-audio.js"></file><file href="js/main.js"></file><file href="js/SCOFunctions.js"></file><file href="js/slick.min.js"></file><file href="fonts/fontawesome-webfont.eot"></file><file href="fonts/fontawesome-webfont.svg"></file><file href="fonts/fontawesome-webfont.ttf"></file><file href="fonts/fontawesome-webfont.woff"></file><file href="fonts/fontawesome-webfont.woff2"></file><file href="fonts/FontAwesome.otf"></file><file href="fonts/glyphicons-halflings-regular.eot"></file><file href="fonts/glyphicons-halflings-regular.svg"></file><file href="fonts/glyphicons-halflings-regular.ttf"></file><file href="fonts/glyphicons-halflings-regular.woff"></file><file href="fonts/glyphicons-halflings-regular.woff2"></file></resource></resources></manifest>';

    // var zip = new JSZip();
    // var fs = new FileReader();

    // var folderImg = zip.folder("img");
    // var folderCss = zip.folder("css");
    // var folderJs = zip.folder("js");
    // var folderFonts = zip.folder("fonts");

    // var arquivos = {
    //     img: ['arrow-left.png', 'arrow-right.png', 'correto.png', 'bg-box-top-juridico.jpg'],
    //     css: ['bootstrap.min.css', 'font-awesome.min.css', 'layout1_estilo_juridico.css', 'layout1_estrutura_elementos.css', 'layout1_estrutura_pagina.css', 'layout2_estilo_juridico.css', 'layout2_estrutura_elementos.css', 'layout2_estrutura_pagina.css', 'slick.css'],
    //     js: ['APIWrapper.js','bootstrap.min.js','image-compressor.min.js','jquery-3.2.1.min.js','main.js','main-audio.js','SCOFunctions.js','slick.min.js'],
    //     fonts: ['FontAwesome.otf', 'fontawesome-webfont.eot', 'fontawesome-webfont.svg', 'fontawesome-webfont.ttf', 'fontawesome-webfont.woff', 'fontawesome-webfont.woff2', 'glyphicons-halflings-regular.eot', 'glyphicons-halflings-regular.svg', 'glyphicons-halflings-regular.ttf', 'glyphicons-halflings-regular.woff', 'glyphicons-halflings-regular.woff2']
    // }

    // for (var i = 0; i < Object.keys(arquivos).length; i++) {
    //     var tipoAtual = Object.keys(arquivos)[i];
    //     var arquivosAtuais = arquivos[tipoAtual];
    //     for (var j = 0; j < arquivosAtuais.length; j++) {
    //         if (tipoAtual == 'img') {

    //             var arquivoAtual = '../RESULTADO/img/' + arquivosAtuais[j];

    //             fs.readFile(arquivoAtual, function(err, data) {
    //                 folderImg.file(arquivosAtuais[j], data);
    //             });
    //         }
    //         else if (tipoAtual == 'css') {

    //             var arquivoAtual = '../RESULTADO/css/' + arquivosAtuais[j];

    //             fs.readFile(arquivoAtual, function(err, data) {
    //                 folderCss.file(arquivosAtuais[j], data);
    //             });
    //         }
    //         else if (tipoAtual == 'js') {

    //             var arquivoAtual = '../RESULTADO/js/' + arquivosAtuais[j];

    //             fs.readFile(arquivoAtual, function(err, data) {
    //                 folderJs.file(arquivosAtuais[j], data);
    //             });
    //         }
    //         else if (tipoAtual == 'fonts') {

    //             var arquivoAtual = '../RESULTADO/fonts/' + arquivosAtuais[j];

    //             fs.readFile(arquivoAtual, function(err, data) {
    //                 folderFonts.file(arquivosAtuais[j], data);
    //             });
    //         }
    //     }
    // }

    // zip.file('material.html', finalString);
    // zip.file('imsmanifest.xml', manifest);

    // zip.generateAsync({type:"blob"})
    // .then(function(content) {
    //     // Force down of the Zip file
    //     saveAs(content, "material.zip");
    // });

    var file1 = new File([finalString], "material.html", {type: "text/html;charset=utf-8"});
    var file2 = new File([manifest], "imsmanifest.xml", {type: "text/xml"});
    saveAs(file1);
    saveAs(file2);

    $('.galeriaImagens').slick({
        dots: false,
        draggable: true,
        speed: 500,
        accessibility: false,
        touchMove: true,
        prevArrow:'<p class="arrow-left arrow"><img class="point point-left" src="img/arrow-left.png" alt="arrow" /></p>',
        nextArrow:'<p class="arrow-right arrow"><img class="point point-right" src="img/arrow-right.png" alt="arrow" /></p>',
        slidesToShow: 1,
        adaptiveHeight: true
    });

    $('.galeriaImagens').init(function() {
      $('.galeriaImagens').each(function() {
        var height = $(this).find('.slick-active').outerHeight();
        $(this).find('.slick-list').outerHeight(height);
      });
    });

    $('.sliderpersonalizadoResultado').slick({
        dots: false,
        infinite: false,
        arrows: false,
        draggable: false,
        speed: 500,
        accessibility: false,
        waitForAnimate: false,
        adaptiveHeight: true,
        touchMove: false,
        onInit: function() {
            if (!$(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).hasClass('aceitaElementos')) {
                $(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).addClass('aceitaElementos');
                $(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).addClass('elemento');
            }
        }
    });
});

$('#desktop').on('click', function() {
    $(this).addClass('active');
    $('#tablet').removeClass('active');
    $('#mobile').removeClass('active');

    $('.menuScreen').removeClass('menuScreen-tablet');
    $('.menuScreen').removeClass('menuScreen-mobile');

    $('#tabs').removeClass('tabs-device');
    $('header').removeClass('header-device');
    $('#resultado').removeClass('resultado-tablet');
    $('#resultado').removeClass('resultado-mobile');
});

$('#tablet').on('click', function() {
    $(this).addClass('active');
    $('#desktop').removeClass('active');
    $('#mobile').removeClass('active');

    $('.menuScreen').removeClass('menuScreen-mobile');
    $('.menuScreen').addClass('menuScreen-tablet');

    $('#tabs').addClass('tabs-device');
    $('header').addClass('header-device');
    $('#resultado').removeClass('resultado-mobile');
    $('#resultado').addClass('resultado-tablet');
});

$('#mobile').on('click', function() {
    $(this).addClass('active');
    $('#desktop').removeClass('active');
    $('#tablet').removeClass('active');

    $('.menuScreen').addClass('menuScreen-mobile');
    $('.menuScreen').removeClass('menuScreen-tablet');

    $('#tabs').addClass('tabs-device');
    $('header').addClass('header-device');
    $('#resultado').removeClass('resultado-tablet');
    $('#resultado').addClass('resultado-mobile');
});

$('#previa').on('click', function() {
    fixSlide();
    $('.menuEstilos').hide();
    $('#desktop').show();
    $('#desktop').addClass('active');
    $('#tablet').show();
    $('#tablet').removeClass('active');
    $('#mobile').show();
    $('#mobile').removeClass('active');
    $('.menuScreen').removeClass('menuScreen-tablet');
    $('.menuScreen').removeClass('menuScreen-mobile');
    updateResult();
});

$('#edicao').on('click', function() {
    $('#desktop').hide();
    $('#tablet').hide();
    $('#mobile').hide();
    $('#tabs').removeClass('tabs-device');
    $('header').removeClass('header-device');
    $('#resultado').removeClass('resultado-tablet');
    $('#resultado').removeClass('resultado-mobile');
    $('.menuScreen').removeClass('menuScreen-tablet');
    $('.menuScreen').removeClass('menuScreen-mobile');

  $('.menuEstilos').show();

  $('.sliderpersonalizado').unslick();

  $('.sliderpersonalizado').slick({
       dots: false,
        arrows: false,
        draggable: false,
        speed: 500,
        accessibility: false,
        infinite: false,
        waitForAnimate: false,
        adaptiveHeight: true,
        zIndex: 1,
        touchMove: false,
        onInit: function() {
            if (!$(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).hasClass('aceitaElementos')) {
                $(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).addClass('aceitaElementos');
                $(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).addClass('elemento');
            }
        }
    });
});

$('#tabs').tabs({
    active: 0
});

// $('.menuEdicao li').on('click', function() {
//    $(this).closest('.menuEdicao').find('li').removeClass('active');
//    $(this).addClass('active');

//     if ($(this).attr('id') == 'texto') {
//         if ($('#edicaoView').find('#conteudo2').length > 0) {

//         $('.sliderpersonalizado').unslick();
//         $('.galeriaImagens').unslick();

//         aba2 = $('#conteudo2').html();

//         $('#conteudo2').remove();
//         $('#edicaoView').append('<div id="conteudo" class="aceitaElementos">' + aba1 + '</div>');
//         }
//     }
//     else {
//         if ($('#edicaoView').find('#conteudo').length > 0) {

//             $('.sliderpersonalizado').unslick();
//             $('.galeriaImagens').unslick();

//             aba1 = $('#conteudo').html();
//             $('#conteudo').remove();
//             $('#edicaoView').append('<div id="conteudo2" class="aceitaElementos">' + aba2 + '</div>');
//         }
//     }

//     $('#conteudo, #conteudo2').sortable({
//         handle: ".mover",
//         cancel: ".remover",
//         placeholder: "sortable-placeholder",
//         forcePlaceholderSize: true,
//         forceHelperSize: true,
//         tolerance: "pointer",
//         stop: function(e,ui) {
//             stopSortable(e,ui);
//         }
//     });

//     $('.sliderpersonalizado').slick({
//        dots: false,
//         arrows: false,
//         draggable: false,
//         speed: 500,
//         accessibility: false,
//         infinite: false,
//         waitForAnimate: false,
//         adaptiveHeight: true,
//         zIndex: 1,
//         touchMove: false,
//         onInit: function() {
//             if (!$(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).hasClass('aceitaElementos')) {
//                 $(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).addClass('aceitaElementos');
//                 $(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).addClass('elemento');
//             }
//         }
//     });

//     $('.galeriaImagens').slick({
//         dots: false,
//         draggable: true,
//         speed: 500,
//         accessibility: false,
//         touchMove: true,
//         prevArrow:'<p class="arrow-left arrow"><img class="point point-left" src="img/arrow-left.png" alt="arrow" /></p>',
//         nextArrow:'<p class="arrow-right arrow"><img class="point point-right" src="img/arrow-right.png" alt="arrow" /></p>',
//         slidesToShow: 1,
//         adaptiveHeight: true
//     });

//     $('.galeriaImagens').init(function() {
//       $('.galeriaImagens').each(function() {
//         var height = $(this).find('.slick-active').outerHeight();
//         $(this).find('.slick-list').outerHeight(height);
//       });
//     });

//     createSortables();
// });

$('.duvida').on('mouseenter', function() {
    var tipo = $(this).closest('li').attr('class').replace(/inserirElemento/g, '').replace(/ui-draggable/g, '').replace(/ui-draggable-handle/g, '').replace(/\s/g, '').replace(/-handle/g, '');
  var height = $('.duvidaContent.duvida'+tipo).outerHeight();

  var top = $(this).offset().top - height/2;
  var left = $(this).offset().left + 50;

  $('.duvidaContent.duvida'+tipo).css({top: top, left: left});
  $('.duvidaContent.duvida'+tipo).css({visibility: 'visible', opacity: 1});
}).on('mouseleave', function() {
    var tipo = $(this).closest('li').attr('class').replace(/inserirElemento/g, '').replace(/ui-draggable/g, '').replace(/ui-draggable-handle/g, '').replace(/\s/g, '').replace(/-handle/g, '');
  $('.duvidaContent.duvida'+tipo).css({visibility: 'hidden', opacity: 0});
});

$('#carregar').on('change', function(evt) {
    if (evt.target.files.length > 0) {
        $('#loading').show();
        loading = true;
        $('#conteudo').html('');
        $('#conteudo2').html('');
        aba1 = '';
        aba2 = '';
        var overlayContent = '';
        readFileText(evt.target.files[0], function(e) {
          var resultadoContent = '';

          $(e.target.result).each(function(index, el) {

           if (el.nodeName != '#text' && (el.classList.contains('header-menu') || el.classList.contains('tab-content'))) {
            resultadoContent = resultadoContent + el.outerHTML;
           }
           else if (el.nodeName != '#text' && el.nodeName == 'HEADER') {
            resultadoContent = resultadoContent + el.outerHTML;
            var numCap = $(el).find('h1').html();
            var nomCap = $(el).find('h3').html();
            var disCap = $(el).find('h4').html();
            $('.numeroCapitulo').html(numCap);
            $('.nomeCapitulo').html(nomCap);
            $('.disciplinaCapitulo').html(disCap);
           }
           else if (el.nodeName == 'DIV' && el.classList.contains('overlay')) {
            resultadoContent = resultadoContent + el.outerHTML;
           }
          });

          if (resultadoContent) {

            $('#resultado').html(resultadoContent);

            $('#resultado').find('#abaTexto').children().each(function(index, el) {
                if ($(el).hasClass('screen') || $(el).hasClass('tooltipArea')) {
                    $(el).children().each(function(index, el) {
                        var element = $(el);
                        elemento = carregarElementos(element[0].nodeName, element);
                        aba1 = aba1 + elemento;
                    });
                }
                else {
                    var element = $(el);
                    elemento = carregarElementos(element[0].nodeName, element);
                    aba1 = aba1 + elemento;
                }
            });

            $('#overlayResultado').find('.modalArea').each(function(index, el) {
                var element = $(el).find('*:first');
                elemento = carregarElementos(element[0].nodeName, element);
                overlayContent = overlayContent + elemento;
            });
            $('#conteudo').append(aba1);
            $('#conteudo2').append(aba2);
            $('#overlayEdicao').append(overlayContent);

            $('.banner').find('.area').remove();
            $('.file-name').each(function(index, el) {
                if ($(this).find('span').eq(0).html() != '') {
                    $(this).css('display', 'inline-block');
                    $(this).find('.file-eraser').show();
                }
            });

          }

          $('.galeriaImagens').slick({
                dots: false,
                draggable: true,
                speed: 500,
                accessibility: false,
                touchMove: true,
                prevArrow:'<p class="arrow-left arrow"><img class="point point-left" src="img/arrow-left.png" alt="arrow" /></p>',
                nextArrow:'<p class="arrow-right arrow"><img class="point point-right" src="img/arrow-right.png" alt="arrow" /></p>',
                slidesToShow: 1,
                adaptiveHeight: true,
                onAfterChange: function(event, slick, currentSlide, nextSlide) {
                    if ($(this)[0].$slideTrack.parents('.sliderpersonalizadoResultado').length == 1) {
                        updateSlick($(this)[0].$slideTrack.parents('.sliderpersonalizadoResultado'));
                    }
                }
            });

          $('.galeriaImagens').init(function() {
            $('.galeriaImagens').each(function() {
                var height = $(this).find('.slick-active').outerHeight();
                $(this).find('.slick-list').outerHeight(height);
            });
          });

            $('.sliderpersonalizado').slick({
                dots: false,
                arrows: false,
                draggable: false,
                speed: 500,
                accessibility: false,
                infinite: false,
                adaptiveHeight: true,
                zIndex: 1,
                touchMove: false,
                onInit: function() {
                    if (!$(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).hasClass('aceitaElementos')) {
                        $(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).addClass('aceitaElementos');
                        $(this)[0].$slider.find('.slick-slide').eq(0).find('.slide').eq(0).addClass('elemento');
                    }
                    createSortables();
                }
            });

            $('.sliderpersonalizadoResultado').slick({
                dots: false,
                infinite: false,
                arrows: false,
                draggable: false,
                speed: 500,
                accessibility: false,
                waitForAnimate: false,
                adaptiveHeight: true,
                touchMove: false,
                onAfterChange: function(event, slick, currentSlide, nextSlide) {
                    $('.galeriaImagens').slickSetOption(null, null, true);
                }
            });

            createSortables();
            $('#loading').hide();
            loading = false;
        });
    }
});

$('.menuLayouts li').on('click', function() {
    $(this).closest('.menuLayouts').children('li').removeClass('active');
    $(this).addClass('active');
});

$('.menuEditorial li').on('click', function() {
    $(this).closest('.menuEditorial').children('li').removeClass('active');
    $(this).addClass('active');
});

$('#confirmar').on('click', function() {

    var textoLayout = $('.menuLayouts').find('.active').find('p').html();
    var textoEditorial = $('.menuEditorial').find('.active').find('p').html();

    if (textoLayout.indexOf('Layout 1') != -1) {
        layout = 'layout1';
    }
    else if (textoLayout.indexOf('Layout 2') != -1) {
        layout = 'layout2';
    }
    else {
        alert('Não foi escolhido o Layout');
    }


    if (textoEditorial == 'Jurídico') {
        editorial = 'juridico';
    }
    else if (textoEditorial == 'Saúde') {
        editorial = 'saude';
    }
    else {
        editorial = 'exatas';
    }

    $('<link/>', {
       rel: 'stylesheet',
       type: 'text/css',
       href: 'css/' + layout + '_estrutura_pagina.css'
    }).appendTo('head');

    $('<link/>', {
       rel: 'stylesheet',
       type: 'text/css',
       href: 'css/' + layout + '_estrutura_elementos.css'
    }).appendTo('head');

    $('<link/>', {
       rel: 'stylesheet',
       type: 'text/css',
       href: 'css/' + layout + '_estilo_' + editorial + '.css'
    }).appendTo('head');

    $('body').removeClass('cancel');
    overlay.fechar($('#overlayLayout'));
});

$(document).on('click', '.toggleMenu', function() {

    if ($(this).hasClass('hideMenu')) {
        $(this).closest('.menuScreen').addClass('menuScreenResponsive');
        $(this).removeClass('hideMenu');
        $(this).addClass('showMenu');
    }
    else {
        $(this).closest('.menuScreen').removeClass('menuScreenResponsive');
        $(this).removeClass('showMenu');
        $(this).addClass('hideMenu');
    }
});

$(document).on('click', '.accordionToggle', function() {

    if (!$(this).hasClass('accordionToggleOn')) {
        $(this).closest('.accordionTitle').closest('.accordion').find('.accordionToggleOn').closest('.accordionTitle').next('.accordionArea').slideUp();
        $(this).closest('.accordionTitle').closest('.accordion').find('.accordionToggleOn').removeClass('accordionToggleOn');
    }

    $(this).closest('.accordionTitle').next('.accordionArea').css('min-height', 'auto');
    $(this).closest('.accordionTitle').next('.accordionArea').height('auto');

    $(this).toggleClass('accordionToggleOn');

    if ($(this).closest('.accordionTitle').next('.accordionArea').children().length == 0) {
        $(this).closest('.accordionTitle').next('.accordionArea').height(108);
    }
    else {
        $(this).closest('.accordionTitle').next('.accordionArea').height('auto');
        $(this).closest('.accordionTitle').next('.accordionArea').css('min-height', 'auto');
    }

    $(this).closest('.accordionTitle').next('.accordionArea').slideToggle(400, function() {
        if ($(this).children().length == 0) {
            $(this).css('min-height', '150px');
            $(this).height('auto');
        }
    });
});

$(document).on('click', '.adicionarAccordion', function() {

    var accordionItem = '<div class="accordionTitle"><div class="accordionSelection"><div tabindex="0" contenteditable="true" class="titulo textarea elemento ui-sortable">' + objetos.accordion.titulo.placeholder +'</div><div class="accordionToggle"><i class="fa fa-minus-circle" aria-hidden="true"></i><i class="fa fa-chevron-circle-down" aria-hidden="true"></i></div></div><div class="removerAccordion"><i class="fa fa-times-circle" aria-hidden="true"></i> Remover item</div></div><div class="accordionArea elemento aceitaElementos"><div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.accordion.paragrafo.placeholder + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div></div>';

    $(accordionItem).insertBefore($(this));

    createSortables();

});

$(document).on('click', '.removerAccordion', function() {
    if ($(this).closest('.accordionTitle').closest('.accordion').find('.accordionTitle').length >= 2) {
        $(this).closest('.accordionTitle').next('.accordionArea').remove();
        $(this).closest('.accordionTitle').remove();
    }
});

$(document).on('click', '.menuAbas li:not(".adicionarAba")', function(evt) {
    if (!$(evt.target).hasClass('removerAba')) {

        var aba = $(this).attr('class').replace('open', '');

        if (!$(this).hasClass('active')) {

            $(this).closest('.menuAbas').children().removeClass('active');
            $(this).addClass('active');
            $(this).closest('.abasElement').find('.abaArea').removeClass('active');
            $(this).closest('.abasElement').find('.' + aba + '').addClass('active');

        }
    }
});

$(document).on('click', '.adicionarAba', function() {
    var totalAbas = $(this).closest('.menuAbas').children().length - 1;
    var index = parseInt($(this).closest('.menuAbas li:last-child').prev('li').attr('class').replace(/[^\d]+/g, ''));

    if (totalAbas < 5) {
        $('<li class="openaba' + (index + 1) + '"><div class="removerAba"><i class="fa fa-times-circle" aria-hidden="true"></i> Remover aba</div><div class="abaTitleArea"><div tabindex="0" contenteditable="true" class="abaTitle textarea elemento ui-sortable">' + objetos.abaTitle.placeholder + '</div></div></li>').insertBefore($(this));
        $(this).closest('.abasElement').append('<div class="abaArea aba' + (index + 1) + '"><div class="abaContent aceitaElementos"><div class="drag"><div class="descricaoObjeto mover"><p><span class="icon"><img src="img/icones/paragrafo.png" /></span></p><p>Parágrafo</p></div><div tabindex="0" contenteditable="true" class="paragrafo textarea elemento ui-sortable">' + objetos.accordion.paragrafo.placeholder + '</div><div class="area"><ul class="menu-area"><li class="mover reverse"><i class="fa fa-arrows" aria-hidden="true"></i></li><li class="duplicar reverse"><i class="fa fa-files-o" aria-hidden="true"></i></li><li class="remover reverse"><i class="fa fa-times" aria-hidden="true"></i></li></ul></div></div></div></div>');
    }

    createSortables();
});

$(document).on('click', '.removerAba', function() {
    var totalAbas = $(this).closest('.menuAbas').children().length - 1;
    if (totalAbas > 2) {
        var index = $(this).closest('li').attr('class').replace(/[^\d]+/g, '');

        if ($(this).closest('li').hasClass('active')) {
            if (totalAbas == $(this).closest('li').index() + 1) {
                $(this).closest('li').prev('li').addClass('active');
                var index2 = $(this).closest('li').prev('li').attr('class').replace(/[^\d]+/g, '');
                $(this).closest('.abasElement').find('.aba' + index2 + '').addClass('active');
            }
            else {
                $(this).closest('li').next('li').addClass('active');
                var index2 = $(this).closest('li').next('li').attr('class').replace(/[^\d]+/g, '');
                $(this).closest('.abasElement').find('.aba' + index2 + '').addClass('active');
            }

        }

        $(this).closest('.abasElement').find('.aba' + index +'').remove();
        $(this).closest('li').remove();
    }
});
